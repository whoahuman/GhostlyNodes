from __future__ import annotations

import asyncio
import ipaddress
import json
import re
import socket
from urllib.parse import urlsplit

import httpx

from .config import Config


class RemnawaveError(RuntimeError):
    pass


def normalize_url(url: str, cfg: Config) -> str:
    url = url.strip().rstrip("/")
    parts = urlsplit(url)
    if (
        not parts.hostname
        or parts.username is not None
        or parts.password is not None
        or parts.query
        or parts.fragment
        or parts.path not in {"", "/api"}
    ):
        raise ValueError("URL Remnawave: https://panel.example.com (допустим суффикс /api)")
    if parts.scheme not in {"http", "https"}:
        raise ValueError("Разрешены только HTTP/HTTPS")
    if parts.scheme == "http" and not (cfg.allow_api_http and parts.hostname.lower() in cfg.api_allow_hosts):
        raise ValueError(
            "HTTP API отключён. Для частной сети включите GHOSTFLEET_ALLOW_API_HTTP и API_ALLOW_HOSTS на сервере"
        )
    if cfg.api_allow_hosts and parts.hostname.lower() not in cfg.api_allow_hosts:
        raise ValueError("Домен API отсутствует в GHOSTFLEET_API_ALLOW_HOSTS")
    # .port also validates invalid numeric ports.
    if parts.port is not None and not 1 <= parts.port <= 65535:
        raise ValueError("Некорректный порт API")
    return url if parts.path == "/api" else url + "/api"


async def validate_api_destination(url: str, cfg: Config) -> list[str]:
    parts = urlsplit(url)
    try:
        records = await asyncio.wait_for(
            asyncio.to_thread(
                socket.getaddrinfo,
                parts.hostname,
                parts.port or (443 if parts.scheme == "https" else 80),
                type=socket.SOCK_STREAM,
            ),
            8,
        )
    except (OSError, TimeoutError, asyncio.TimeoutError) as e:
        raise RemnawaveError("Не удалось разрешить домен Remnawave") from e
    for record in records:
        addr = ipaddress.ip_address(record[4][0])
        effective = addr.ipv4_mapped if isinstance(addr, ipaddress.IPv6Address) and addr.ipv4_mapped else addr
        if (
            effective.is_link_local
            or effective.is_multicast
            or effective.is_unspecified
            or str(effective) == "fd00:ec2::254"
        ):
            raise RemnawaveError("Link-local, metadata и multicast адреса API запрещены")
        if not addr.is_global and parts.hostname.lower() not in cfg.api_allow_hosts:
            raise RemnawaveError(
                "Для локального API добавьте его hostname в GHOSTFLEET_API_ALLOW_HOSTS на сервере"
            )

    addresses = list(dict.fromkeys(str(ipaddress.ip_address(record[4][0])) for record in records))
    return sorted(addresses, key=lambda value: ipaddress.ip_address(value).version)


class Remnawave:
    def __init__(self, url: str, token: str, cfg: Config, transport=None):
        self.base_url = normalize_url(url, cfg)
        self.token = token
        self.cfg = cfg
        self.transport = transport

    async def request(self, method: str, path: str, payload: dict | None = None):
        if not re.fullmatch(r"/[a-z0-9/-]+", path):
            raise ValueError("Invalid API path")
        if self.cfg.demo:
            raise RemnawaveError("В демо сетевые запросы запрещены")
        original_url = httpx.URL(self.base_url + path)
        request_url = original_url
        headers = {"Authorization": f"Bearer {self.token}", "Accept": "application/json"}
        extensions = {}
        if not self.transport:
            addresses = await validate_api_destination(self.base_url, self.cfg)
            if not addresses:
                raise RemnawaveError("У API нет адресов")
            # Pin the resolved IP for this request. Preserve Host and TLS hostname
            # verification, so a second DNS resolution cannot rebind to metadata.
            request_url = original_url.copy_with(host=addresses[0])
            headers["Host"] = original_url.netloc.decode("ascii")
            extensions["sni_hostname"] = original_url.raw_host.decode("ascii")
        try:
            # No redirects, no ambient HTTP(S)_PROXY, normal CA verification.
            async with httpx.AsyncClient(
                timeout=httpx.Timeout(25, connect=8),
                follow_redirects=False,
                trust_env=False,
                transport=self.transport,
            ) as client:
                async with client.stream(
                    method,
                    request_url,
                    headers=headers,
                    extensions=extensions,
                    json=payload,
                ) as response:
                    if not 200 <= response.status_code < 300:
                        raise RemnawaveError(
                            f"Remnawave: HTTP {response.status_code} на {method} {path}. Проверьте права API-токена и журнал Remnawave."
                        )
                    data = bytearray()
                    async for chunk in response.aiter_bytes():
                        data.extend(chunk)
                        if len(data) > 8 * 1024 * 1024:
                            raise RemnawaveError("Ответ API больше 8 МБ")
            parsed = json.loads(data)
            if "response" not in parsed:
                raise RemnawaveError("API вернул неожиданный формат; нужен Remnawave 3.x")
            return parsed["response"]
        except RemnawaveError:
            raise
        except (httpx.HTTPError, json.JSONDecodeError, KeyError, TypeError) as e:
            # Never include response bodies, credentials, or a token-containing URL.
            raise RemnawaveError(
                "Remnawave недоступен или вернул некорректный JSON. Проверьте DNS, TLS и API URL."
            ) from e

    async def nodes(self) -> list[dict]:
        response = await self.request("GET", "/nodes")
        if not isinstance(response, list):
            raise RemnawaveError("Неожиданный формат списка нод")
        return response

    async def secret_key(self) -> str:
        response = await self.request("GET", "/keygen")
        value = response.get("secretKey", "")
        if not re.fullmatch(r"[A-Za-z0-9+/=_-]{20,10000}", value):
            raise RemnawaveError("API /keygen вернул неожиданный SECRET_KEY")
        return value

    async def metadata(self) -> dict:
        return await self.request("GET", "/system/metadata")

    async def squads(self) -> list[dict]:
        response = await self.request("GET", "/internal-squads")
        return response.get("internalSquads", [])

    async def create_profile(self, name: str, config: dict) -> dict:
        response = await self.request("POST", "/config-profiles", {"name": name, "config": config})
        if not response.get("inbounds"):
            response = await self.profile(response["uuid"])
        return response

    async def profile(self, profile_uuid: str) -> dict:
        return await self.request("GET", f"/config-profiles/{profile_uuid}")

    async def update_profile(self, profile_uuid: str, config: dict) -> dict:
        return await self.request("PATCH", "/config-profiles", {"uuid": profile_uuid, "config": config})

    async def create_node(self, node: dict, profile_uuid: str, inbound_uuids: list[str]) -> dict:
        return await self.request(
            "POST",
            "/nodes",
            {
                "name": node["name"],
                "address": node["address"],
                "port": node["node_port"],
                "countryCode": node["country"],
                "configProfile": {"activeConfigProfileUuid": profile_uuid, "activeInbounds": inbound_uuids},
                "isTrafficTrackingActive": True,
            },
        )

    async def update_node(self, node_uuid: str, profile_uuid: str, inbound_uuids: list[str]) -> dict:
        return await self.request(
            "PATCH",
            "/nodes",
            {
                "uuid": node_uuid,
                "configProfile": {"activeConfigProfileUuid": profile_uuid, "activeInbounds": inbound_uuids},
            },
        )

    async def action(self, node_uuid: str, action: str) -> dict:
        if action not in {"enable", "disable", "restart"}:
            raise ValueError("Invalid node action")
        return await self.request("POST", f"/nodes/{node_uuid}/actions/{action}")

    async def add_inbounds_to_squads(self, squads: list[str], inbound_uuids: list[str]) -> None:
        for squad_uuid in squads:
            squad = await self.request("GET", f"/internal-squads/{squad_uuid}")
            previous = [i["uuid"] if isinstance(i, dict) else i for i in squad.get("inbounds", [])]
            await self.request(
                "PATCH",
                "/internal-squads",
                {"uuid": squad_uuid, "inbounds": list(dict.fromkeys(previous + inbound_uuids))},
            )

    async def create_hosts(self, node: dict, profile: dict, config: dict, existing: list[str]) -> list[str]:
        result = list(existing)
        # Idempotency for a retry after a response was lost.
        remote = await self.request("GET", "/hosts")
        configs = {i["tag"]: i for i in config["inbounds"]}
        for inbound in profile.get("inbounds", []):
            inbound_id = inbound["uuid"]
            found = next(
                (
                    h
                    for h in remote
                    if h.get("inbound", {}).get("configProfileUuid") == profile["uuid"]
                    and h.get("inbound", {}).get("configProfileInboundUuid") == inbound_id
                    and h.get("address") == node["domain"]
                ),
                None,
            )
            if found:
                if found["uuid"] not in result:
                    result.append(found["uuid"])
                continue
            raw = configs.get(inbound.get("tag"))
            if not raw:
                continue
            grpc = raw["streamSettings"].get("network") == "grpc"
            body = {
                "inbound": {"configProfileUuid": profile["uuid"], "configProfileInboundUuid": inbound_id},
                "remark": f"{node['name']} · {'gRPC' if grpc else 'Hysteria2'}",
                "address": node["domain"],
                "port": 443,
                "sni": node["domain"],
                "alpn": "h2" if grpc else "h3",
                "securityLayer": "TLS",
                "nodes": [node["remnawave_uuid"]],
            }
            if grpc:
                body["path"] = raw["streamSettings"]["grpcSettings"]["serviceName"]
            created = await self.request("POST", "/hosts", body)
            result.append(created["uuid"])
        return list(dict.fromkeys(result))
