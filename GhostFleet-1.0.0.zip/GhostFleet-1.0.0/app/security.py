from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import io
import ipaddress
import json
import secrets
import time
from pathlib import Path

import pyotp
import qrcode
from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError
from argon2.low_level import Type
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from fastapi import HTTPException, Request

from .config import Config
from .db import Database

PASSWORD_HASHER = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=2, type=Type.ID)
PASSWORD_WORKERS = asyncio.Semaphore(2)
DUMMY_HASH = PASSWORD_HASHER.hash(secrets.token_urlsafe(32))


class SecretBox:
    def __init__(self, key: bytes):
        if len(key) != 32:
            raise ValueError("The master key must contain 32 bytes")
        self.key = key
        self.aes = AESGCM(key)

    @classmethod
    def read(cls, path: Path) -> SecretBox:
        return cls(base64.urlsafe_b64decode(path.read_bytes().strip()))

    @classmethod
    def create(cls, path: Path) -> SecretBox:
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        key = secrets.token_bytes(32)
        with path.open("xb") as f:
            f.write(base64.urlsafe_b64encode(key) + b"\n")
        path.chmod(0o400)
        return cls(key)

    def encrypt(self, text: str, label: str) -> str:
        nonce = secrets.token_bytes(12)
        return (
            "v1:"
            + base64.urlsafe_b64encode(
                nonce + self.aes.encrypt(nonce, text.encode(), label.encode())
            ).decode()
        )

    def decrypt(self, text: str, label: str) -> str:
        if not text.startswith("v1:"):
            raise ValueError("Unknown ciphertext version")
        payload = base64.urlsafe_b64decode(text[3:])
        return self.aes.decrypt(payload[:12], payload[12:], label.encode()).decode()

    def digest(self, text: str, label: str) -> str:
        return hmac.new(self.key, (label + ":" + text).encode(), hashlib.sha256).hexdigest()


async def check_password(encoded: str, password: str) -> bool:
    def check() -> bool:
        try:
            return PASSWORD_HASHER.verify(encoded, password)
        except (VerificationError, InvalidHashError):
            return False

    async with PASSWORD_WORKERS:
        return await asyncio.to_thread(check)


async def hash_password(password: str) -> str:
    async with PASSWORD_WORKERS:
        return await asyncio.to_thread(PASSWORD_HASHER.hash, password)


def new_session(db: Database, config: Config, ip: str, ua: str, scope: str) -> tuple[str, dict]:
    token = secrets.token_urlsafe(32)
    sid = hashlib.sha256(token.encode()).hexdigest()
    row = {
        "id": sid,
        "csrf": secrets.token_urlsafe(32),
        "scope": scope,
        "ip": ip,
        "ua": hashlib.sha256(ua.encode()).hexdigest(),
        "created": time.time(),
        "touched": time.time(),
    }
    db.execute("INSERT INTO sessions VALUES(?,?,?,?,?,?,?)", tuple(row.values()))
    # A finite number of sessions limits accidental accumulation.
    db.execute(
        "DELETE FROM sessions WHERE id IN (SELECT id FROM sessions ORDER BY created DESC LIMIT -1 OFFSET 10)"
    )
    return token, row


def client_ip(request: Request) -> str:
    return request.client.host if request.client else ""


def get_session(request: Request, allow_setup: bool = False) -> dict:
    cfg = request.app.state.cfg
    if cfg.demo:
        return {"id": "demo", "csrf": "demo", "scope": "full", "username": "demo"}
    token = request.cookies.get(cfg.cookie_name, "")
    if not token or len(token) > 128:
        raise HTTPException(401, "Войдите в панель")
    sid = hashlib.sha256(token.encode()).hexdigest()
    db = request.app.state.db
    row = db.one("SELECT * FROM sessions WHERE id=?", (sid,))
    now = time.time()
    ua = hashlib.sha256(request.headers.get("user-agent", "").encode()).hexdigest()
    if (
        not row
        or now - row["created"] > cfg.session_seconds
        or now - row["touched"] > cfg.idle_seconds
        or (cfg.bind_session_ip and row["ip"] != client_ip(request))
        or row["ua"] != ua
    ):
        db.execute("DELETE FROM sessions WHERE id=?", (sid,))
        raise HTTPException(401, "Сессия истекла. Войдите снова")
    if row["scope"] != "full" and not allow_setup:
        raise HTTPException(403, "Сначала подключите двухфакторную аутентификацию")
    admin = db.one("SELECT username FROM admins WHERE id=1")
    row["username"] = admin["username"] if admin else "admin"
    return row


def authorize(request: Request, allow_setup: bool = False) -> dict:
    session = get_session(request, allow_setup)
    if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
        if request.app.state.db.get("maintenance_until", 0) > time.time() and request.url.path not in {
            "/api/auth/logout",
            "/api/auth/activity",
        }:
            raise HTTPException(503, "Техническое обслуживание. Изменения временно отключены")
        if request.app.state.cfg.demo:
            raise HTTPException(403, "Демо работает только на чтение и не подключается к серверам")
        supplied = request.headers.get("x-csrf-token", "")
        if not hmac.compare_digest(supplied, session["csrf"]):
            raise HTTPException(403, "Неверный CSRF-токен")
        request.app.state.db.execute("UPDATE sessions SET touched=? WHERE id=?", (time.time(), session["id"]))
    return session


def consume_second_factor(conn, admin: dict, box: SecretBox, code: str) -> bool:
    if not admin.get("totp_secret"):
        return False
    code = code.strip().upper()
    if len(code) == 6 and code.isdigit():
        otp = pyotp.TOTP(box.decrypt(admin["totp_secret"], "admin:totp"))
        counter = int(time.time()) // otp.interval
        for candidate in (counter, counter - 1, counter + 1):
            if candidate > admin["totp_counter"] and hmac.compare_digest(otp.generate_otp(candidate), code):
                conn.execute("UPDATE admins SET totp_counter=? WHERE id=1", (candidate,))
                return True
    recovery = json.loads(admin["recovery"])
    digest = box.digest(code, "recovery")
    for i, saved in enumerate(recovery):
        if hmac.compare_digest(saved, digest):
            recovery.pop(i)
            conn.execute("UPDATE admins SET recovery=? WHERE id=1", (json.dumps(recovery),))
            return True
    return False


def enrollment_qr(secret: str, username: str) -> str:
    uri = pyotp.TOTP(secret).provisioning_uri(name=username, issuer_name="GhostFleet")
    image = qrcode.make(uri)
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    return "data:image/png;base64," + base64.b64encode(buffer.getvalue()).decode()


def rate_ip(ip: str) -> str:
    try:
        addr = ipaddress.ip_address(ip)
        return str(ipaddress.ip_network(f"{addr}/64", strict=False)) if addr.version == 6 else str(addr)
    except ValueError:
        return "unknown"


class SecurityMiddleware:
    """Bounded request bodies, exact origins, access rules and browser hardening."""

    def __init__(self, app, cfg: Config):
        self.app = app
        self.cfg = cfg

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        headers = dict(scope.get("headers", []))
        ip = scope.get("client", ("", 0))[0]
        host = headers.get(b"host", b"").decode(errors="replace").lower()
        host_name = host.split("]")[0].lstrip("[") if host.startswith("[") else host.split(":")[0]

        def hardening() -> list[tuple[bytes, bytes]]:
            values = {
                "X-Content-Type-Options": "nosniff",
                "Referrer-Policy": "no-referrer",
                "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
                "Cache-Control": "no-store",
                "Content-Security-Policy": "default-src 'none'; script-src 'self'; style-src 'self'; style-src-attr 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors "
                + ("*" if self.cfg.demo else "'none'"),
            }
            if not self.cfg.demo:
                values["X-Frame-Options"] = "DENY"
            if self.cfg.secure_cookie:
                values["Strict-Transport-Security"] = "max-age=31536000"
            return [(k.lower().encode(), v.encode()) for k, v in values.items()]

        async def reject(status: int, detail: str):
            body = json.dumps({"detail": detail}, ensure_ascii=False).encode()
            await send(
                {
                    "type": "http.response.start",
                    "status": status,
                    "headers": [(b"content-type", b"application/json; charset=utf-8"), *hardening()],
                }
            )
            await send({"type": "http.response.body", "body": body})

        if not self.cfg.demo:
            if host_name not in self.cfg.trusted_hosts:
                return await reject(400, "Недопустимый Host")
            try:
                addr = ipaddress.ip_address(ip)
            except ValueError:
                return await reject(403, "Доступ закрыт")
            if self.cfg.mode == "tunnel" and not addr.is_loopback:
                return await reject(403, "Доступ разрешён только через SSH-туннель")
            if self.cfg.mode in {"vpn", "allowlist"} and not (
                addr.is_loopback or any(addr in n for n in self.cfg.allowed_cidrs)
            ):
                return await reject(403, "Ваш IP не входит в список разрешённых")
            if scope["method"] in {"POST", "PUT", "PATCH", "DELETE"}:
                origin = headers.get(b"origin", b"").decode(errors="replace")
                if origin != self.cfg.public_url:
                    return await reject(403, "Недопустимый Origin")
        if scope["method"] in {"POST", "PUT", "PATCH", "DELETE"}:
            size = 0
            chunks = []
            deadline = time.monotonic() + 15
            try:
                while True:
                    message = await asyncio.wait_for(receive(), max(0.01, deadline - time.monotonic()))
                    if message["type"] == "http.disconnect":
                        return
                    body = message.get("body", b"")
                    size += len(body)
                    if size > 1024 * 1024:
                        return await reject(413, "Тело запроса больше 1 МБ")
                    chunks.append(body)
                    if not message.get("more_body", False):
                        break
            except (TimeoutError, asyncio.TimeoutError):
                return await reject(408, "Таймаут запроса")
            pending = b"".join(chunks)
            delivered = False
            original_receive = receive

            async def replay():
                nonlocal delivered
                if not delivered:
                    delivered = True
                    return {"type": "http.request", "body": pending, "more_body": False}
                return await original_receive()

            receive = replay

        async def secured_send(message):
            if message["type"] == "http.response.start":
                message["headers"] = [*message.get("headers", []), *hardening()]
            await send(message)

        await self.app(scope, receive, secured_send)
