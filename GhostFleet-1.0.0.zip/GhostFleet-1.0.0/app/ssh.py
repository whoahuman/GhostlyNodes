from __future__ import annotations

import asyncio
import ipaddress
import json
import re
import socket
from contextlib import asynccontextmanager

import asyncssh
import httpx

from .config import Config
from .schemas import COUNTRY_CODES


class SSHError(RuntimeError):
    pass


def validate_target(address: str, cfg: Config) -> str:
    addr = ipaddress.ip_address(address)
    if (
        addr.is_loopback
        or addr.is_link_local
        or addr.is_multicast
        or addr.is_unspecified
        or addr.is_reserved
        or str(addr) == "fd00:ec2::254"
    ):
        raise SSHError("Loopback, link-local/metadata, multicast и reserved IP запрещены")
    if not addr.is_global and not any(addr in net for net in cfg.private_node_cidrs):
        raise SSHError(
            "Частный IP не разрешён. Для VPN-ноды укажите точную сеть в GHOSTFLEET_PRIVATE_NODE_CIDRS на сервере"
        )
    if cfg.demo:
        raise SSHError("В демо SSH отключён")
    return str(addr)


async def verify_dns(domain: str, address: str) -> list[str]:
    try:
        records = await asyncio.wait_for(
            asyncio.to_thread(socket.getaddrinfo, domain, 443, type=socket.SOCK_STREAM), 8
        )
    except (OSError, TimeoutError, asyncio.TimeoutError) as e:
        raise SSHError(
            "Домен ноды не разрешается. Создайте A/AAAA-запись и дождитесь распространения DNS"
        ) from e
    ips = sorted({str(ipaddress.ip_address(r[4][0])) for r in records})
    if str(ipaddress.ip_address(address)) not in ips or any(ip != address for ip in ips):
        raise SSHError(
            "Все A/AAAA домена должны указывать на эту ноду. Уберите лишние записи и отключите Cloudflare Proxy"
        )
    return ips


async def probe_host(address: str, port: int, cfg: Config) -> dict:
    validate_target(address, cfg)
    try:
        # Only fetch a public host key: no username, password or authentication.
        key = await asyncio.wait_for(asyncssh.get_server_host_key(address, port, config=None), 12)
        if not key:
            raise SSHError("SSH не вернул ключ сервера")
        return {
            "host_key": key.export_public_key("openssh").decode().strip(),
            "fingerprint": key.get_fingerprint("sha256"),
            "algorithm": key.get_algorithm(),
        }
    except SSHError:
        raise
    except (asyncssh.Error, OSError, TimeoutError, asyncio.TimeoutError) as e:
        raise SSHError("Не удалось получить SSH fingerprint. Проверьте IP, порт SSH и firewall") from e


async def detect_country(address: str) -> str | None:
    # Only an IP is sent to the geolocation service; explicit opt-in in settings.
    try:
        async with httpx.AsyncClient(timeout=6, follow_redirects=False, trust_env=False) as client:
            response = await client.get(f"https://ipwho.is/{address}")
            if len(response.content) > 50_000:
                return None
            value = response.json().get("country_code", "").upper()
            return value if value in COUNTRY_CODES else None
    except (httpx.HTTPError, ValueError):
        return None


@asynccontextmanager
async def connect(address: str, port: int, approved_host_key: str, credentials: dict, cfg: Config):
    validate_target(address, cfg)
    try:
        host = asyncssh.import_public_key(approved_host_key)
        keys = []
        if credentials.get("private_key"):
            keys.append(
                asyncssh.import_private_key(
                    credentials["private_key"], credentials.get("key_passphrase") or None
                )
            )
        async with asyncssh.connect(
            address,
            port,
            username=credentials.get("username", "root"),
            password=credentials.get("password") or None,
            known_hosts=([host], [], []),
            client_keys=keys,
            agent_path=None,
            config=None,
            login_timeout=20,
            connect_timeout=12,
            keepalive_interval=20,
            keepalive_count_max=3,
        ) as conn:
            yield conn
    except SSHError:
        raise
    except asyncssh.HostKeyNotVerifiable as e:
        raise SSHError(
            "SSH-ключ изменился! Пароль не отправлен. Сверьте fingerprint через консоль провайдера"
        ) from e
    except asyncssh.PermissionDenied as e:
        raise SSHError("SSH отказал во входе. Проверьте логин, пароль/ключ и разрешение SSH на ноде") from e
    except (asyncssh.Error, OSError, TimeoutError, asyncio.TimeoutError, ValueError) as e:
        raise SSHError("Ошибка SSH. Проверьте доступность сервера, sudo и журнал на ноде") from e


async def agent_call(node: dict, box, cfg: Config, operation: str, payload: dict | None = None) -> dict:
    if operation not in {"health", "metrics", "certificates", "logs", "update"}:
        raise ValueError("Unknown agent operation")
    if not node.get("management_key") or not node.get("fingerprint"):
        raise SSHError("У ноды нет ограниченного ключа управления")
    saved = json.loads(node["fingerprint"])
    private = box.decrypt(node["management_key"], f"node:{node['id']}:key")
    async with connect(
        node["address"],
        node["ssh_port"],
        saved["host_key"],
        {"username": "root", "private_key": private},
        cfg,
    ) as conn:
        process = await conn.create_process(operation, input=json.dumps(payload) if payload else "")

        async def bounded_stdout():
            chunks = []
            size = 0
            while chunk := await process.stdout.read(8192):
                size += len(chunk)
                if size > 256_000:
                    raise SSHError("SSH-агент прислал больше 256 КБ. Ответ отклонён")
                chunks.append(chunk)
            return "".join(chunks)

        async def discard_stderr():
            while await process.stderr.read(8192):
                pass

        tasks = [
            asyncio.create_task(bounded_stdout()),
            asyncio.create_task(discard_stderr()),
            asyncio.create_task(process.wait_closed()),
        ]
        try:
            result = await asyncio.wait_for(asyncio.gather(*tasks), 1000 if operation == "update" else 25)
            output = result[0]
        finally:
            for task in tasks:
                if not task.done():
                    task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
        if process.exit_status != 0:
            raise SSHError("Ограниченный SSH-агент не выполнил команду; проверьте локальный журнал ноды")
        try:
            data = json.loads(output)
            if not isinstance(data, dict):
                raise ValueError
            return data
        except ValueError as e:
            raise SSHError("Некорректный ответ SSH-агента") from e


def new_management_key() -> tuple[str, str]:
    key = asyncssh.generate_private_key("ssh-ed25519")
    return key.export_private_key("openssh").decode(), key.export_public_key("openssh").decode().strip()


def clean_remote_path(path: str) -> str:
    # validated remote UUID path; mkdir is atomic and mode 0700
    if not re.fullmatch(r"/tmp/gf-[a-f0-9]{32}", path):  # nosec B108
        raise ValueError("Unexpected remote temporary path")
    return path
