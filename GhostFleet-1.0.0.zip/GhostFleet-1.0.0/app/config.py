from __future__ import annotations

import ipaddress
import os
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlsplit

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]


def flag(name: str, default: bool = False) -> bool:
    return os.getenv(name, str(int(default))).lower() in {"1", "yes", "true"}


@dataclass
class Config:
    data_dir: Path
    public_url: str
    demo: bool = False
    mode: str = "tunnel"
    allowed_cidrs: tuple = ()
    private_node_cidrs: tuple = ()
    api_allow_hosts: tuple[str, ...] = ()
    allow_api_http: bool = False
    monitor_seconds: int = 60
    idle_seconds: int = 1800
    session_seconds: int = 28800
    bind_session_ip: bool = True
    trusted_hosts: set[str] = field(default_factory=set)

    @property
    def secure_cookie(self) -> bool:
        return self.public_url.startswith("https://")

    @property
    def cookie_name(self) -> str:
        return "__Host-ghostfleet" if self.secure_cookie else "ghostfleet-local"

    @property
    def db_path(self) -> Path:
        return self.data_dir / "ghostfleet.sqlite3"

    @property
    def key_path(self) -> Path:
        return self.data_dir / "master.key"

    @classmethod
    def from_env(cls) -> Config:
        env_path = os.getenv("GHOSTFLEET_ENV", "/etc/ghostfleet/ghostfleet.env")
        if Path(env_path).is_file():
            load_dotenv(env_path, override=False)
        demo = flag("GHOSTFLEET_DEMO")
        mode = os.getenv("GHOSTFLEET_MODE", "tunnel")
        url = os.getenv("GHOSTFLEET_PUBLIC_URL", "http://localhost:8088").rstrip("/")
        parts = urlsplit(url)
        if (
            not parts.hostname
            or parts.path
            or parts.query
            or parts.fragment
            or parts.username is not None
            or parts.password is not None
        ):
            raise ValueError("GHOSTFLEET_PUBLIC_URL must be an origin, without a path or credentials")
        if not demo and not (
            parts.scheme == "https"
            or (
                mode == "tunnel"
                and parts.scheme == "http"
                and parts.hostname in {"localhost", "127.0.0.1", "::1"}
            )
        ):
            raise ValueError("HTTP is allowed ONLY for a loopback SSH tunnel")
        if mode not in {"tunnel", "vpn", "allowlist", "public"}:
            raise ValueError("Invalid access mode")

        def nets(name: str) -> tuple:
            return tuple(
                ipaddress.ip_network(v.strip(), strict=False)
                for v in os.getenv(name, "").split(",")
                if v.strip()
            )

        allowed = nets("GHOSTFLEET_ALLOWED_CIDRS")
        private = nets("GHOSTFLEET_PRIVATE_NODE_CIDRS")
        if any(n.prefixlen == 0 for n in (*allowed, *private)):
            raise ValueError("/0 allowlists are forbidden")
        if not demo and mode in {"vpn", "allowlist"} and not allowed:
            raise ValueError("A non-empty GHOSTFLEET_ALLOWED_CIDRS is required")
        hosts = {parts.hostname}
        if mode == "tunnel":
            hosts |= {"localhost", "127.0.0.1", "::1"}
        return cls(
            data_dir=Path(os.getenv("GHOSTFLEET_DATA_DIR", "/var/lib/ghostfleet")),
            public_url=url,
            demo=demo,
            mode=mode,
            allowed_cidrs=allowed,
            private_node_cidrs=private,
            api_allow_hosts=tuple(
                h.strip().lower() for h in os.getenv("GHOSTFLEET_API_ALLOW_HOSTS", "").split(",") if h.strip()
            ),
            allow_api_http=flag("GHOSTFLEET_ALLOW_API_HTTP"),
            monitor_seconds=max(30, int(os.getenv("GHOSTFLEET_MONITOR_SECONDS", "60"))),
            idle_seconds=max(300, int(os.getenv("GHOSTFLEET_IDLE_SECONDS", "1800"))),
            session_seconds=max(900, int(os.getenv("GHOSTFLEET_SESSION_SECONDS", "28800"))),
            bind_session_ip=flag("GHOSTFLEET_BIND_SESSION_IP", True),
            trusted_hosts=hosts,
        )
