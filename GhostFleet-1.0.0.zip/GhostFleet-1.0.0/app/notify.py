from __future__ import annotations

import httpx


async def notify(db, box, cfg, message: str) -> None:
    encrypted = db.get("telegram_token")
    settings = db.get("integration", {})
    if cfg.demo or not encrypted or not settings.get("telegram_chat_id"):
        return
    token = box.decrypt(encrypted, "setting:telegram_token")
    try:
        async with httpx.AsyncClient(timeout=8, trust_env=False, follow_redirects=False) as client:
            response = await client.post(
                f"https://api.telegram.org/bot{token}/sendMessage",
                json={
                    "chat_id": settings["telegram_chat_id"],
                    "text": "GhostFleet\n" + message[:3000],
                    "disable_web_page_preview": True,
                },
            )
            if response.status_code != 200:
                db.audit("notification.failed", "Telegram отклонил уведомление")
    except httpx.HTTPError:
        db.audit("notification.failed", "Telegram недоступен")
