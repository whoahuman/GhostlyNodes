"""GhostFleet: a private Remnawave control plane."""

__version__ = "1.0.0"
