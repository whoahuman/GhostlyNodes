from __future__ import annotations

import asyncio
import json
import math
import re
import time
import uuid

from .notify import notify
from .ssh import agent_call


def number(value, default=None):
    try:
        result = float(value)
        return result if math.isfinite(result) and result >= 0 else default
    except (ValueError, TypeError):
        return default


def normalize_node(raw: dict, now: float) -> dict:
    system = raw.get("system") or {}
    info = system.get("info") or {}
    stats = system.get("stats") or {}
    interface = stats.get("interface") or {}
    versions = raw.get("versions") or {}
    return {
        "connected": raw.get("isConnected") is True,
        "disabled": raw.get("isDisabled") is True,
        "connecting": raw.get("isConnecting") is True,
        "users_online": number(raw.get("usersOnline")),
        "traffic_used": number(raw.get("trafficUsedBytes")),
        "traffic_limit": number(raw.get("trafficLimitBytes")),
        "memory_total": number(info.get("memoryTotal")),
        "memory_used": number(stats.get("memoryUsed")),
        "load1": number((stats.get("loadAvg") or [None])[0]),
        "cpus": number(info.get("cpus")),
        "network_rx": number(interface.get("rxBytesPerSec")),
        "network_tx": number(interface.get("txBytesPerSec")),
        "network_rx_total": number(interface.get("rxTotal")),
        "network_tx_total": number(interface.get("txTotal")),
        "uptime": number(raw.get("xrayUptime")),
        "node_version": str(versions.get("node", ""))[:50],
        "xray_version": str(versions.get("xray", ""))[:50],
        "seen_at": now,
    }


async def alert_transition(
    services, key: str, failing: bool, failure: str, recovery: str, threshold: int = 2
) -> None:
    db = services.db
    row = db.one("SELECT * FROM alerts WHERE key=?", (key,)) or {"failures": 0, "notified": 0}
    failures = row["failures"] + 1 if failing else 0
    notified = row["notified"]
    if failing and failures >= threshold and not notified:
        notified = 1
        await notify(db, services.box, services.cfg, failure)
        db.audit("alert.opened", failure)
    elif not failing and notified:
        notified = 0
        await notify(db, services.box, services.cfg, recovery)
        db.audit("alert.closed", recovery)
    db.execute(
        "INSERT INTO alerts VALUES(?,?,?,?) ON CONFLICT(key) DO UPDATE SET failures=excluded.failures,notified=excluded.notified,updated=excluded.updated",
        (key, failures, notified, time.time()),
    )


async def sync_nodes(services) -> dict:
    if services.cfg.demo:
        return services.db.get("monitor", {})
    async with services.sync_lock:
        db = services.db
        previous = db.get("monitor", {})
        start = time.monotonic()
        try:
            api = services.api()
            nodes = await api.nodes()
            if len(nodes) > 5000:
                raise RuntimeError("Too many nodes")
            now = time.time()
            seen = set()
            for raw in nodes:
                remote_id = str(uuid.UUID(raw["uuid"]))
                seen.add(remote_id)
                local = db.one("SELECT * FROM nodes WHERE remnawave_uuid=?", (remote_id,))
                if not local:
                    pending = db.one(
                        "SELECT id FROM nodes WHERE managed=1 AND remnawave_uuid IS NULL AND address=? AND state='installing'",
                        (raw.get("address"),),
                    )
                    if pending:
                        continue  # Deployment will bind its own newly-created UUID.
                    base = (
                        re.sub(r"[^a-z0-9-]", "-", str(raw.get("name", "node")).lower()).strip("-")[:30]
                        or "node"
                    )
                    slug = base
                    if db.one("SELECT id FROM nodes WHERE slug=?", (slug,)):
                        slug = base + "-" + remote_id[:8]
                    db.execute(
                        "INSERT INTO nodes(id,remnawave_uuid,slug,name,country,ordinal,address,node_port,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?)",
                        (
                            remote_id,
                            remote_id,
                            slug,
                            str(raw.get("name", base))[:100],
                            str(raw.get("countryCode", "XX"))[:2].upper(),
                            0,
                            str(raw.get("address", ""))[:253],
                            raw.get("port") or 2222,
                            now,
                            now,
                        ),
                    )
                    local = db.one("SELECT * FROM nodes WHERE id=?", (remote_id,))
                normalized = normalize_node(raw, now)
                state = local["state"]
                if normalized["connected"] and state in {"waiting", "missing"}:
                    state = "active" if local["managed"] else "imported"
                db.execute(
                    "UPDATE nodes SET rw_data=?,state=?,updated=? WHERE id=?",
                    (json.dumps(normalized), state, now, local["id"]),
                )
                total = normalized["memory_total"]
                used = normalized["memory_used"]
                percent = min(100, 100 * used / total) if total and used is not None else None
                db.execute(
                    "INSERT INTO samples(node_id,ts,connected,users,rx,tx,memory_pct,load,latency) VALUES(?,?,?,?,?,?,?,?,?)",
                    (
                        local["id"],
                        now,
                        int(normalized["connected"]),
                        normalized["users_online"],
                        normalized["network_rx"],
                        normalized["network_tx"],
                        percent,
                        normalized["load1"],
                        (time.monotonic() - start) * 1000,
                    ),
                )
                if state not in {"pending", "installing", "failed"} and not normalized["disabled"]:
                    await alert_transition(
                        services,
                        "node:" + local["id"],
                        not normalized["connected"],
                        f"Нода offline: {local['name']} ({local['address']})",
                        f"Нода снова online: {local['name']}",
                    )
            for local in db.query("SELECT * FROM nodes WHERE remnawave_uuid IS NOT NULL"):
                if local["remnawave_uuid"] not in seen:
                    data = json.loads(local["rw_data"])
                    data["missing"] = True
                    db.execute(
                        "UPDATE nodes SET state='missing',rw_data=?,updated=? WHERE id=?",
                        (json.dumps(data), now, local["id"]),
                    )
            status = {
                "online": True,
                "last_success": now,
                "checked": now,
                "latency_ms": round((time.monotonic() - start) * 1000),
                "error": None,
            }
            db.set("monitor", status)
            await alert_transition(services, "api", False, "", "Связь с Remnawave восстановлена", threshold=3)
            return status
        except Exception:
            # No stale node is labelled offline merely because the API went away.
            status = {
                "online": False,
                "last_success": previous.get("last_success"),
                "checked": time.time(),
                "error": "Не удалось обновить Remnawave. Показаны последние известные данные; это НЕ означает, что ноды offline.",
            }
            db.set("monitor", status)
            if db.get("api_token"):
                await alert_transition(
                    services,
                    "api",
                    True,
                    "API Remnawave недоступен: состояние нод неизвестно",
                    "",
                    threshold=3,
                )
            return status


async def maintain_nodes(services) -> None:
    db = services.db
    if not db.get("monitor", {}).get("online"):
        return
    semaphore = asyncio.Semaphore(4)

    async def maintain(node):
        async with semaphore:
            now = time.time()
            if now - (node.get("last_host_poll") or 0) >= 300:
                try:
                    metrics = await agent_call(node, services.box, services.cfg, "metrics")
                    metrics["seen_at"] = now
                    db.execute(
                        "UPDATE nodes SET host_metrics=?,last_host_poll=? WHERE id=?",
                        (json.dumps(metrics), now, node["id"]),
                    )
                except Exception:
                    db.execute("UPDATE nodes SET last_host_poll=? WHERE id=?", (now, node["id"]))
            last_attempt = db.get("cert_attempt:" + node["id"], 0)
            if now - (node.get("last_cert_sync") or 0) >= 6 * 3600 and now - last_attempt > 900:
                db.set("cert_attempt:" + node["id"], now)
                try:
                    await services.sync_certificate(node)
                    await alert_transition(
                        services,
                        "cert-sync:" + node["id"],
                        False,
                        "",
                        f"Синхронизация TLS восстановлена: {node['name']}",
                    )
                except Exception:
                    await alert_transition(
                        services,
                        "cert-sync:" + node["id"],
                        True,
                        f"Не удалось синхронизировать TLS: {node['name']}. Проверьте SSH-ключ и Config Profile",
                        "",
                        threshold=1,
                    )
            if node.get("cert_expiry"):
                await alert_transition(
                    services,
                    "cert-expiry:" + node["id"],
                    node["cert_expiry"] - now < 14 * 86400,
                    f"TLS-сертификат {node['name']} истекает менее чем через 14 дней",
                    f"TLS-сертификат {node['name']} продлён",
                    threshold=1,
                )

    nodes = db.query(
        "SELECT * FROM nodes WHERE managed=1 AND state IN ('active','waiting') AND management_key IS NOT NULL"
    )
    if nodes:
        await asyncio.gather(*(maintain(n) for n in nodes), return_exceptions=True)


async def monitor_loop(services) -> None:
    last_prune = 0
    while True:
        try:
            if not services.cfg.demo:
                await sync_nodes(services)
                await maintain_nodes(services)
                if time.time() - last_prune >= 3600:
                    services.db.prune()
                    last_prune = time.time()
        except asyncio.CancelledError:
            raise
        except Exception:
            services.db.audit("monitor.failed", "Цикл мониторинга прерван; повтор при следующем опросе")
        await asyncio.sleep(services.cfg.monitor_seconds)
