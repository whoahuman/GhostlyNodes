from __future__ import annotations

import hashlib

import httpx

COMMIT = "00a5df50a45b865e685554683afbb99bb8c81d4f"
URL = f"https://raw.githubusercontent.com/whoahuman/Ghostly-Infrainstall/{COMMIT}/ghostly-infra-installer.sh"
SHA256 = "372d67e2ae0432a1dbe7bd5cbb4238ad1e45c0c241cc8ab582730d676826f138"
_cache: bytes | None = None


async def fetch_installer() -> bytes:
    global _cache
    if _cache is not None:
        return _cache
    async with httpx.AsyncClient(timeout=20, follow_redirects=False, trust_env=False) as client:
        async with client.stream("GET", URL) as response:
            response.raise_for_status()
            data = bytearray()
            async for chunk in response.aiter_bytes():
                data.extend(chunk)
                if len(data) > 1_000_000:
                    raise RuntimeError("Upstream installer too large")
    if hashlib.sha256(data).hexdigest() != SHA256:
        raise RuntimeError("Ghostly installer checksum mismatch: deployment blocked")
    _cache = bytes(data)
    return _cache


# acme.sh release 3.1.6: annotated tag points to this immutable commit.
ACME_COMMIT = "807da6498377ee5e0cf43a78091f46f12dc59a89"
ACME_URL = f"https://codeload.github.com/acmesh-official/acme.sh/tar.gz/{ACME_COMMIT}"
ACME_SHA256 = "ddbe1bcbd1a44a2623a2af167ebdc678669e6e2eb396742f2d1d28e02dc14220"
_acme_cache: bytes | None = None


async def fetch_acme() -> bytes:
    global _acme_cache
    if _acme_cache is not None:
        return _acme_cache
    async with httpx.AsyncClient(timeout=25, follow_redirects=False, trust_env=False) as client:
        async with client.stream("GET", ACME_URL) as response:
            response.raise_for_status()
            data = bytearray()
            async for chunk in response.aiter_bytes():
                data.extend(chunk)
                if len(data) > 2_000_000:
                    raise RuntimeError("acme.sh archive too large")
    if hashlib.sha256(data).hexdigest() != ACME_SHA256:
        raise RuntimeError("acme.sh SHA256 mismatch")
    _acme_cache = bytes(data)
    return _acme_cache
