import copy
import json
from datetime import datetime, timedelta, timezone

import pytest
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID

from app.template import (
    TemplateError,
    parse_certificate,
    redact,
    render_config,
    replace_certificates,
    validate_template,
)


def test_country_tag_service_and_routing_update(filled_template):
    original = copy.deepcopy(filled_template)
    result = render_config(filled_template, "DE", 2)
    assert [i["tag"] for i in result["inbounds"]] == ["de-02-grpc", "de-02-hy2"]
    assert result["inbounds"][0]["streamSettings"]["grpcSettings"]["serviceName"] == "de-2"
    assert result["routing"]["rules"][2]["inboundTag"] == ["de-02-grpc", "de-02-hy2"]
    assert filled_template == original
    assert result["outbounds"][1] == filled_template["outbounds"][1]
    assert result["inbounds"][1]["streamSettings"]["hysteriaSettings"]["masquerade"]["dir"] == "/var/www"


def test_inline_tls_replaces_file_paths(filled_template):
    result = render_config(filled_template, "FI", 3, cert={"certificate": ["CERT"], "key": ["KEY"]})
    for inbound in result["inbounds"]:
        cert = inbound["streamSettings"]["tlsSettings"]["certificates"][0]
        assert "keyFile" not in cert and "certificateFile" not in cert
        assert cert["certificate"] == ["CERT"] and cert["key"] == ["KEY"]


def test_template_unknown_routing_tag(filled_template):
    filled_template["routing"]["rules"][2]["inboundTag"] = ["not-existing"]
    with pytest.raises(TemplateError):
        validate_template(filled_template)


def test_duplicate_inbound_tags(filled_template):
    filled_template["inbounds"][1]["tag"] = filled_template["inbounds"][0]["tag"]
    with pytest.raises(TemplateError):
        validate_template(filled_template)


def test_default_placeholder_config_cannot_deploy():
    from app.template import DEFAULT_TEMPLATE

    with pytest.raises(TemplateError):
        validate_template(json.loads(DEFAULT_TEMPLATE.read_text()))


def test_unknown_country_rejected(filled_template):
    with pytest.raises(TemplateError):
        render_config(filled_template, "ZZ", 1)


def test_do_not_replace_ru_bridge_values(filled_template):
    filled_template["outbounds"][1]["settings"]["address"] = "ru-bridge.example.com"
    result = render_config(filled_template, "PL", 22)
    assert result["outbounds"][1]["settings"]["address"] == "ru-bridge.example.com"
    assert result["outbounds"][1]["streamSettings"]["grpcSettings"]["serviceName"] == "ru-bridge"


def test_clients_cannot_be_baked_in(filled_template):
    filled_template["inbounds"][0]["settings"]["clients"] = [{"id": "test"}]
    with pytest.raises(TemplateError):
        validate_template(filled_template)


def test_redacted_config_never_leaks_keys_and_ids():
    value = {
        "settings": {"id": "secret-id"},
        "realitySettings": {"password": "secret-key"},
        "certificates": [{"key": ["PEMKEY"], "certificate": ["PUBLICCERT"]}],
    }
    output = json.dumps(redact(value))
    assert "secret-id" not in output and "secret-key" not in output and "PEMKEY" not in output
    assert "PUBLICCERT" in output


def test_certificate_patch_preserves_manual_routing(filled_template):
    saved = render_config(filled_template, "DE", 2)
    saved["routing"]["domainStrategy"] = "AsIs"
    saved["routing"]["rules"].append({"type": "field", "domain": ["example.com"], "outboundTag": "block"})
    result = replace_certificates(
        saved, {"de-02-grpc", "de-02-hy2"}, {"certificate": ["CERT"], "key": ["KEY"]}
    )
    assert result["routing"] == saved["routing"]
    assert result["inbounds"][0]["streamSettings"]["tlsSettings"]["certificates"][0]["key"] == ["KEY"]


def test_changed_tags_block_automatic_certificate_patch(filled_template):
    saved = render_config(filled_template, "DE", 2)
    saved["inbounds"][0]["tag"] = "manually-changed"
    with pytest.raises(TemplateError):
        replace_certificates(saved, {"de-02-grpc", "de-02-hy2"}, {"certificate": ["CERT"], "key": ["KEY"]})


def certificate(domain="node.example.com", days=30):
    root_key = ec.generate_private_key(ec.SECP256R1())
    key = ec.generate_private_key(ec.SECP256R1())
    issuer = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "GhostFleet test root")])
    subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, domain)])
    now = datetime.now(timezone.utc)
    root = (
        x509.CertificateBuilder()
        .subject_name(issuer)
        .issuer_name(issuer)
        .public_key(root_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - timedelta(days=30))
        .not_valid_after(now + timedelta(days=365))
        .add_extension(x509.BasicConstraints(ca=True, path_length=1), True)
        .add_extension(x509.KeyUsage(True, False, False, False, False, True, True, False, False), True)
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(root_key.public_key()), False)
        .sign(root_key, hashes.SHA256())
    )
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - timedelta(days=2))
        .not_valid_after(now + timedelta(days=days))
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), True)
        .add_extension(x509.KeyUsage(True, False, False, False, False, False, False, False, False), True)
        .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), False)
        .add_extension(x509.SubjectAlternativeName([x509.DNSName(domain)]), False)
        .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(root_key.public_key()), False)
        .sign(root_key, hashes.SHA256())
    )
    fullchain = (
        cert.public_bytes(serialization.Encoding.PEM).decode()
        + root.public_bytes(serialization.Encoding.PEM).decode()
    )
    return (
        fullchain,
        key.private_bytes(
            serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()
        ).decode(),
        root,
    )


def test_certificate_key_and_domain_validation():
    cert, key, root = certificate()
    result = parse_certificate(cert, key, "node.example.com", trusted_roots=[root])
    assert result["expires"] > datetime.now(timezone.utc).timestamp()
    assert result["certificate"][0] == "-----BEGIN CERTIFICATE-----"
    with pytest.raises(TemplateError):
        parse_certificate(cert, key, "other.example.com", trusted_roots=[root])
    _, wrong_key, _ = certificate()
    with pytest.raises(TemplateError):
        parse_certificate(cert, wrong_key, "node.example.com", trusted_roots=[root])


def test_expired_certificate_is_rejected():
    cert, key, root = certificate(days=-1)
    with pytest.raises(TemplateError):
        parse_certificate(cert, key, "node.example.com", trusted_roots=[root])


def test_self_signed_chain_not_in_system_roots_is_rejected():
    cert, key, _ = certificate()
    with pytest.raises(TemplateError, match="не доверена"):
        parse_certificate(cert, key, "node.example.com")


@pytest.mark.parametrize(
    "config",
    [
        {"inbounds": [], "outbounds": [], "routing": []},
        {"inbounds": ["wrong-shape"], "outbounds": []},
        {"inbounds": [{"tag": ["not-hashable"], "streamSettings": []}]},
    ],
)
def test_malformed_json_structure_has_safe_template_error(config):
    with pytest.raises(TemplateError):
        validate_template(config)
