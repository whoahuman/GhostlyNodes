import ipaddress

import httpx
import pytest
from cryptography.exceptions import InvalidTag

from app.config import Config
from app.main import create_app
from app.schemas import DeployRequest, SettingsUpdate, domain_name
from app.security import PASSWORD_HASHER, SecretBox, rate_ip
from app.ssh import SSHError, validate_target


def test_argon2id_hash():
    value = PASSWORD_HASHER.hash("test-only password phrase")
    assert value.startswith("$argon2id$")
    assert PASSWORD_HASHER.verify(value, "test-only password phrase")


def test_aes_random_nonces_and_context_binding(tmp_path):
    box = SecretBox.create(tmp_path / "master.key")
    a = box.encrypt("sensitive", "node:one:key")
    b = box.encrypt("sensitive", "node:one:key")
    assert a != b and "sensitive" not in a
    assert box.decrypt(a, "node:one:key") == "sensitive"
    with pytest.raises(InvalidTag):
        box.decrypt(a, "node:two:key")
    with pytest.raises(InvalidTag):
        SecretBox.create(tmp_path / "other.key").decrypt(a, "node:one:key")


def test_master_key_is_never_overwritten(tmp_path):
    path = tmp_path / "master.key"
    SecretBox.create(path)
    before = path.read_bytes()
    with pytest.raises(FileExistsError):
        SecretBox.create(path)
    assert path.read_bytes() == before
    assert path.stat().st_mode & 0o777 == 0o400


@pytest.mark.parametrize(
    "address",
    ["127.0.0.1", "::1", "169.254.169.254", "0.0.0.0", "224.0.0.1", "10.0.0.5", "192.168.1.10", "fc00::1"],
)
def test_ssh_ssrf_and_unapproved_private_ips_rejected(app, address):
    with pytest.raises(SSHError):
        validate_target(address, app.state.cfg)


def test_explicit_private_network_allowed_but_never_metadata(app):
    app.state.cfg.private_node_cidrs = (
        ipaddress.ip_network("10.10.0.0/24"),
        ipaddress.ip_network("169.254.0.0/16"),
    )
    assert validate_target("10.10.0.9", app.state.cfg) == "10.10.0.9"
    with pytest.raises(SSHError):
        validate_target("169.254.169.254", app.state.cfg)


def test_ipv6_rate_limit_groups_64_prefix():
    assert rate_ip("2001:db8:abcd:1::1") == rate_ip("2001:db8:abcd:1::2")
    assert rate_ip("2001:db8:abcd:1::1") != rate_ip("2001:db8:abcd:2::1")


@pytest.mark.parametrize(
    "value",
    [
        "node.example.com;whoami",
        "$(id).example.com",
        "https://node.example.com",
        "*.example.com",
        "127.0.0.1",
        "bad..example.com",
    ],
)
def test_domain_shell_injection_and_ip_rejected(value):
    with pytest.raises(ValueError):
        domain_name(value)


def test_idn_domain_canonicalized():
    assert domain_name("нода.example.com").startswith("xn--")


def test_credentials_need_explicit_host_confirmation():
    with pytest.raises(ValueError):
        DeployRequest(
            challenge_id="00000000-0000-4000-8000-000000000000",
            approve_host_key=False,
            username="root",
            password="test",
            country="DE",
            domain="node.example.com",
        )


def test_settings_refuse_unrestricted_node_firewall():
    with pytest.raises(ValueError):
        SettingsUpdate(
            remnawave_url="https://panel.example.com",
            remnawave_ips="0.0.0.0/0",
            manager_ips="1.1.1.1",
            email="admin@example.com",
        )


async def test_tunnel_rejects_remote_client(app):
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app, client=("8.8.8.8", 22)), base_url="http://localhost:8088"
    ) as client:
        assert (await client.get("/")).status_code == 403


async def test_allowlist_checks_real_peer_not_untrusted_forwarded_header(app):
    app.state.cfg.mode = "allowlist"
    app.state.cfg.allowed_cidrs = (ipaddress.ip_network("198.51.100.0/24"),)
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app, client=("8.8.8.8", 22)),
        base_url="http://localhost:8088",
        headers={"X-Forwarded-For": "198.51.100.9"},
    ) as client:
        assert (await client.get("/")).status_code == 403
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app, client=("198.51.100.9", 22)), base_url="http://localhost:8088"
    ) as client:
        assert (await client.get("/")).status_code == 200


async def test_demo_is_readonly_and_supports_safe_config_preview(tmp_path):
    cfg = Config(data_dir=tmp_path / "demo", public_url="http://localhost:8088", demo=True, mode="tunnel")
    app = create_app(cfg, background=False)
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://localhost:8088"
    ) as client:
        assert (await client.get("/api/dashboard")).status_code == 200
        for method, path, body in [
            ("POST", "/api/sync", {}),
            ("POST", "/api/nodes/probe", {"address": "1.1.1.1"}),
            ("PUT", "/api/template", {"config": {}}),
        ]:
            assert (await client.request(method, path, json=body)).status_code == 403
        preview = await client.post("/api/template/preview", json={"country": "DE", "ordinal": 2})
        assert preview.status_code == 200 and "de-02-grpc" in preview.text
        assert (await client.get("/")).headers.get("x-frame-options") is None
        settings = (await client.get("/api/settings")).json()
        assert "api_token" not in settings and "telegram_token" not in settings
        assert settings["api_token_configured"] is True


async def test_secure_cookie_flags_for_https(app):
    from app.security import new_session

    app.state.cfg.public_url = "https://localhost"
    app.state.cfg.mode = "allowlist"
    token, _ = new_session(app.state.db, app.state.cfg, "127.0.0.1", "GhostFleet tests", "full")
    assert app.state.cfg.cookie_name == "__Host-ghostfleet"
    assert app.state.cfg.secure_cookie is True
    assert len(token) >= 40


def test_recovery_marks_credentials_interrupted_and_clears_cipher(app):
    import time

    db = app.state.db
    now = time.time()
    db.execute(
        "INSERT INTO nodes(id,slug,name,country,ordinal,address,managed,state,created,updated) VALUES('node','de-01','DE-01','DE',1,'1.1.1.1',1,'installing',?,?)",
        (now, now),
    )
    db.execute(
        "INSERT INTO jobs(id,node_id,kind,state,message,payload_cipher,created,updated) VALUES('job','node','deploy','running','starting','encrypted-password',?,?)",
        (now, now),
    )
    db.recover_jobs()
    job = db.one("SELECT * FROM jobs WHERE id='job'")
    assert job["state"] == "interrupted" and job["payload_cipher"] is None
    assert db.one("SELECT state FROM nodes WHERE id='node'")["state"] == "failed"
