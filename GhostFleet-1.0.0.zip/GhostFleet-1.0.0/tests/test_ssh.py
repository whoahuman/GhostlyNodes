from __future__ import annotations

import asyncssh
import pytest

from app.ssh import SSHError, connect, probe_host


class TestServer(asyncssh.SSHServer):
    auth_calls = []

    def begin_auth(self, username):
        return True

    def password_auth_supported(self):
        return True

    def validate_password(self, username, password):
        self.auth_calls.append((username, password))
        return username == "root" and password == "test-only-password"


async def test_probe_never_authenticates_and_pin_verified_before_password(app, monkeypatch):
    # Loopback is allowed ONLY by this test stub, never by production validation.
    monkeypatch.setattr("app.ssh.validate_target", lambda address, cfg: address)
    key = asyncssh.generate_private_key("ssh-ed25519")
    TestServer.auth_calls = []
    server = await asyncssh.listen("127.0.0.1", 0, server_factory=TestServer, server_host_keys=[key])
    port = server.get_port()
    try:
        probed = await probe_host("127.0.0.1", port, app.state.cfg)
        assert probed["fingerprint"] == key.get_fingerprint("sha256")
        assert TestServer.auth_calls == []
        wrong = asyncssh.generate_private_key("ssh-ed25519").export_public_key("openssh").decode()
        with pytest.raises(SSHError, match="изменился"):
            async with connect(
                "127.0.0.1",
                port,
                wrong,
                {"username": "root", "password": "test-only-password"},
                app.state.cfg,
            ):
                pass
        assert TestServer.auth_calls == []
        async with connect(
            "127.0.0.1",
            port,
            probed["host_key"],
            {"username": "root", "password": "test-only-password"},
            app.state.cfg,
        ):
            pass
        assert TestServer.auth_calls == [("root", "test-only-password")]
    finally:
        server.close()
        await server.wait_closed()


@pytest.mark.parametrize(
    "operation",
    ["bash", "sftp-server", "certificates; id", "metrics && id", "", "update remnawave/node:latest"],
)
def test_agent_rejects_arbitrary_commands(monkeypatch, operation, capsys):
    from node import agent

    monkeypatch.setattr(agent.os, "geteuid", lambda: 0)
    monkeypatch.setenv("SSH_ORIGINAL_COMMAND", operation)
    assert agent.main() == 1
    assert "Command not allowed" in capsys.readouterr().out


@pytest.mark.parametrize(
    "image",
    ["alpine:latest", "remnawave/node:latest;id", "remnawave/node:3.4.1 --privileged", "evil/node:3.4.1"],
)
def test_agent_update_rejects_non_node_images(monkeypatch, image):
    import io
    import json

    from node import agent

    monkeypatch.setattr(agent.sys, "stdin", io.StringIO(json.dumps({"image": image})))
    with pytest.raises(ValueError, match="Invalid image"):
        agent.update()
