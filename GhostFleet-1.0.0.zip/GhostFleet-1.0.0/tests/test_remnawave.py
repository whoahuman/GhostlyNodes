from __future__ import annotations

import asyncio
import json
import ssl

import httpx
import pytest
from cryptography.hazmat.primitives import serialization

from app.remnawave import Remnawave, RemnawaveError, normalize_url, validate_api_destination
from tests.test_templates import certificate


def test_api_url_normalization(app):
    assert normalize_url("https://panel.example.com/", app.state.cfg) == "https://panel.example.com/api"
    assert normalize_url("https://panel.example.com/api", app.state.cfg) == "https://panel.example.com/api"
    for url in (
        "https://user:pass@panel.example.com",
        "https://panel.example.com/foo",
        "http://panel.example.com",
        "file:///etc/passwd",
        "https://panel.example.com?token=bad",
    ):
        with pytest.raises(ValueError):
            normalize_url(url, app.state.cfg)


def test_private_http_requires_server_side_explicit_optin(app):
    app.state.cfg.allow_api_http = True
    with pytest.raises(ValueError):
        normalize_url("http://10.10.0.2:3000", app.state.cfg)
    app.state.cfg.api_allow_hosts = ("10.10.0.2",)
    assert normalize_url("http://10.10.0.2:3000", app.state.cfg) == "http://10.10.0.2:3000/api"


async def test_api_metadata_target_never_allowed(app, monkeypatch):
    app.state.cfg.api_allow_hosts = ("panel.example.com",)
    monkeypatch.setattr(
        "app.remnawave.socket.getaddrinfo", lambda *a, **k: [(2, 1, 6, "", ("169.254.169.254", 443))]
    )
    with pytest.raises(RemnawaveError):
        await validate_api_destination("https://panel.example.com/api", app.state.cfg)


async def test_api_does_not_follow_redirects_or_echo_secrets(app):
    calls = []

    def handle(request):
        calls.append(str(request.url))
        return httpx.Response(
            302,
            headers={"Location": "https://evil.example/api/nodes"},
            json={"error": "PRIVATE KEY AND API TOKEN"},
        )

    api = Remnawave(
        "https://panel.example.com", "test-token", app.state.cfg, transport=httpx.MockTransport(handle)
    )
    with pytest.raises(RemnawaveError) as error:
        await api.nodes()
    assert len(calls) == 1 and "evil.example" not in calls[0]
    assert "PRIVATE KEY" not in str(error.value) and "test-token" not in str(error.value)


async def test_node_profile_and_update_contract_shapes(app):
    requests = []

    async def handler(request):
        body = json.loads(request.content) if request.content else {}
        requests.append((request.method, request.url.path, body))
        return httpx.Response(200, json={"response": {"uuid": "00000000-0000-4000-8000-000000000001"}})

    api = Remnawave(
        "https://panel.example.com", "test-token", app.state.cfg, transport=httpx.MockTransport(handler)
    )
    node = {"name": "DE-01", "address": "1.1.1.1", "country": "DE", "node_port": 2222}
    profile = "00000000-0000-4000-8000-000000000002"
    inbound = "00000000-0000-4000-8000-000000000003"
    await api.create_node(node, profile, [inbound])
    await api.update_profile(profile, {"inbounds": []})
    await api.update_node("00000000-0000-4000-8000-000000000001", profile, [inbound])
    assert requests[0][0:2] == ("POST", "/api/nodes")
    assert requests[0][2]["configProfile"] == {
        "activeConfigProfileUuid": profile,
        "activeInbounds": [inbound],
    }
    assert requests[1][0:2] == ("PATCH", "/api/config-profiles") and requests[1][2]["uuid"] == profile
    assert requests[2][0:2] == ("PATCH", "/api/nodes")


async def test_real_tls_ip_pinning_preserves_host_and_certificate_name(app, tmp_path, monkeypatch):
    fullchain, key, root = certificate("localhost")
    (tmp_path / "certificate.pem").write_text(fullchain)
    (tmp_path / "key.pem").write_text(key)
    server_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    server_context.load_cert_chain(tmp_path / "certificate.pem", tmp_path / "key.pem")
    received = []
    sni = []
    server_context.set_servername_callback(lambda sock, name, ctx: sni.append(name))

    async def handle(reader, writer):
        try:
            received.append((await reader.readuntil(b"\r\n\r\n")).decode())
            body = b'{"response":[]}'
            writer.write(
                b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: "
                + str(len(body)).encode()
                + b"\r\nConnection: close\r\n\r\n"
                + body
            )
            await writer.drain()
        finally:
            writer.close()
            await writer.wait_closed()

    server = await asyncio.start_server(handle, "127.0.0.1", 0, ssl=server_context)
    port = server.sockets[0].getsockname()[1]
    verify_context = ssl.create_default_context(cadata=root.public_bytes(serialization.Encoding.PEM).decode())
    original_client = httpx.AsyncClient

    def trusted_test_client(*args, **kwargs):
        return original_client(*args, verify=verify_context, **kwargs)

    monkeypatch.setattr("app.remnawave.httpx.AsyncClient", trusted_test_client)
    app.state.cfg.api_allow_hosts = ("localhost",)
    try:
        api = Remnawave(f"https://localhost:{port}", "test-token-not-real", app.state.cfg)
        assert await api.nodes() == []
        assert sni == ["localhost"]
        assert f"Host: localhost:{port}" in received[0]
        assert "GET /api/nodes HTTP/1.1" in received[0]
    finally:
        server.close()
        await server.wait_closed()
