import hashlib
import json
import time

import pyotp
import pytest

from tests.conftest import PASSWORD


async def test_unauthenticated_dashboard_denied(client):
    assert (await client.get("/api/dashboard")).status_code == 401


async def test_login_requires_second_factor_enrollment(app, client):
    result = await client.post("/api/auth/login", json={"username": "admin", "password": PASSWORD})
    assert result.status_code == 200
    assert result.json()["must_enroll"] is True
    assert "httponly" in result.headers["set-cookie"].lower()
    assert "samesite=strict" in result.headers["set-cookie"].lower()
    client.headers["X-CSRF-Token"] = result.json()["csrf"]
    assert (await client.get("/api/dashboard")).status_code == 403
    setup = await client.post("/api/auth/totp/setup", json={})
    assert setup.status_code == 200
    assert setup.json()["qr"].startswith("data:image/png;base64,")
    secret = setup.json()["secret"]
    assert secret not in app.state.db.one("SELECT pending_totp FROM admins")["pending_totp"]
    confirm = await client.post("/api/auth/totp/confirm", json={"code": pyotp.TOTP(secret).now()})
    assert confirm.status_code == 200
    codes = confirm.json()["recovery_codes"]
    assert len(codes) == 10 and len(set(codes)) == 10
    stored = app.state.db.one("SELECT recovery FROM admins")["recovery"]
    assert all(c not in stored for c in codes)
    assert (await client.get("/api/dashboard")).status_code == 200
    assert (await client.post("/api/auth/totp/setup", json={})).status_code == 409


async def test_wrong_password_is_generic(client):
    response = await client.post(
        "/api/auth/login", json={"username": "admin", "password": "not the password"}
    )
    assert response.status_code == 401
    assert "not the password" not in response.text


async def test_password_never_in_validation_output(client):
    marker = "never-echo-this-password"
    response = await client.post("/api/auth/login", json={"username": "", "password": marker})
    assert response.status_code == 422
    assert marker not in response.text
    assert "input" not in response.text


async def test_login_rate_limit(client):
    for _ in range(5):
        assert (
            await client.post("/api/auth/login", json={"username": "admin", "password": "wrong"})
        ).status_code == 401
    assert (
        await client.post("/api/auth/login", json={"username": "admin", "password": "wrong"})
    ).status_code == 429


async def test_totp_replay_is_rejected(app, client):
    secret = pyotp.random_base32()
    app.state.db.execute(
        "UPDATE admins SET totp_secret=?,totp_counter=-1", (app.state.box.encrypt(secret, "admin:totp"),)
    )
    code = pyotp.TOTP(secret).now()
    body = {"username": "admin", "password": PASSWORD, "code": code}
    first = await client.post("/api/auth/login", json=body)
    assert first.status_code == 200 and first.json()["must_enroll"] is False
    assert (await client.post("/api/auth/login", json=body)).status_code == 401


async def test_recovery_code_is_single_use(app, client):
    secret = pyotp.random_base32()
    code = "ABCDE-FGHIJ-KLMNO-PQRST"
    app.state.db.execute(
        "UPDATE admins SET totp_secret=?,recovery=?",
        (app.state.box.encrypt(secret, "admin:totp"), json.dumps([app.state.box.digest(code, "recovery")])),
    )
    body = {"username": "admin", "password": PASSWORD, "code": code}
    assert (await client.post("/api/auth/login", json=body)).status_code == 200
    assert (await client.post("/api/auth/login", json=body)).status_code == 401


async def test_missing_csrf_rejected(authed):
    authed.headers.pop("X-CSRF-Token")
    assert (await authed.post("/api/auth/logout", json={})).status_code == 403


async def test_csrf_mismatch_rejected(authed):
    assert (
        await authed.post("/api/auth/logout", json={}, headers={"X-CSRF-Token": "invalid"})
    ).status_code == 403


async def test_missing_origin_rejected(authed):
    authed.headers.pop("Origin")
    assert (await authed.post("/api/auth/logout", json={})).status_code == 403


async def test_cross_origin_rejected(authed):
    assert (
        await authed.post("/api/auth/logout", json={}, headers={"Origin": "https://evil.example"})
    ).status_code == 403


async def test_host_header_rejected(client):
    assert (await client.get("/", headers={"Host": "evil.example"})).status_code == 400


async def test_cookie_opaque_and_not_stored_plain(app, client):
    response = await client.post("/api/auth/login", json={"username": "admin", "password": PASSWORD})
    token = client.cookies.get(app.state.cfg.cookie_name)
    row = app.state.db.one("SELECT * FROM sessions")
    assert row["id"] == hashlib.sha256(token.encode()).hexdigest()
    assert token not in json.dumps(row)
    assert "." not in token
    assert "password" not in response.text


async def test_logout_revokes_session(app, authed):
    assert (await authed.post("/api/auth/logout", json={})).status_code == 200
    assert (await authed.get("/api/auth/me")).status_code == 401
    assert not app.state.db.query("SELECT * FROM sessions")


async def test_idle_expiry_and_polls_do_not_refresh(app, authed):
    app.state.db.execute("UPDATE sessions SET touched=?", (time.time() - 100,))
    before = app.state.db.one("SELECT touched FROM sessions")["touched"]
    assert (await authed.get("/api/dashboard")).status_code == 200
    assert app.state.db.one("SELECT touched FROM sessions")["touched"] == before
    app.state.db.execute("UPDATE sessions SET touched=?", (time.time() - app.state.cfg.idle_seconds - 1,))
    assert (await authed.get("/api/dashboard")).status_code == 401


async def test_real_activity_extends_idle_timer(app, authed):
    app.state.db.execute("UPDATE sessions SET touched=?", (time.time() - 100,))
    assert (await authed.post("/api/auth/activity", json={})).status_code == 200
    assert time.time() - app.state.db.one("SELECT touched FROM sessions")["touched"] < 2


async def test_session_user_agent_binding(authed):
    assert (await authed.get("/api/auth/me", headers={"User-Agent": "different browser"})).status_code == 401


async def test_absolute_session_expiry(app, authed):
    app.state.db.execute("UPDATE sessions SET created=?", (time.time() - app.state.cfg.session_seconds - 1,))
    assert (await authed.get("/api/auth/me")).status_code == 401


async def test_security_headers(client):
    result = await client.get("/")
    assert result.headers["x-content-type-options"] == "nosniff"
    assert result.headers["x-frame-options"] == "DENY"
    assert "script-src 'self'" in result.headers["content-security-policy"]
    assert "frame-ancestors 'none'" in result.headers["content-security-policy"]
    assert result.headers["cache-control"] == "no-store"
    assert result.headers["referrer-policy"] == "no-referrer"


async def test_request_size_limit(client):
    result = await client.post("/api/auth/login", content=b"x" * (1024 * 1024 + 1))
    assert result.status_code == 413


async def test_no_public_signup_or_openapi(client):
    for path in ("/api/register", "/docs", "/openapi.json"):
        assert (await client.get(path)).status_code == 404


async def test_enrollment_scope_cannot_write_settings(client):
    response = await client.post("/api/auth/login", json={"username": "admin", "password": PASSWORD})
    client.headers["X-CSRF-Token"] = response.json()["csrf"]
    assert (await client.get("/api/settings")).status_code == 403
    assert (await client.get("/api/template")).status_code == 403


async def test_password_change_requires_otp_and_revokes_all(app, authed):
    secret = pyotp.random_base32()
    app.state.db.execute(
        "UPDATE admins SET totp_secret=?,totp_counter=-1", (app.state.box.encrypt(secret, "admin:totp"),)
    )
    data = {
        "old_password": PASSWORD,
        "new_password": "New test-only password phrase 2026",
        "code": pyotp.TOTP(secret).now(),
    }
    assert (await authed.post("/api/auth/password", json=data)).status_code == 200
    assert not app.state.db.query("SELECT * FROM sessions")
    assert (await authed.get("/api/auth/me")).status_code == 401


@pytest.mark.parametrize("path", ["/api/settings", "/api/template", "/api/nodes", "/api/jobs", "/api/audit"])
async def test_private_api_not_available_without_session(client, path):
    assert (await client.get(path)).status_code == 401
