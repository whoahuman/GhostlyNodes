# Эксплуатация, backup и восстановление

## Мониторинг

Remnawave опрашивается каждые 60 секунд, agent metrics приблизительно каждые 5 минут, TLS автоматически проверяется/синхронизируется периодически. Локальная история хранится 7 дней. Dashboard polling не продлевает idle session; heartbeat посылается только при действиях пользователя.

- `Online`: Remnawave подтвердил isConnected; не просто доступный SSH или Docker process.
- `Нет данных`: API недоступен / stale; не принудительно `Offline`. Старое connected значение сохраняется, но не выдаётся за свежий факт. Глобальные показатели при недоступном API — `—`.
- `Online в опросах / 24 ч`: доля **известных** samples с connected=true. Unknown интервалы не в denominator. Это не SLA uptime.
- `Учтённый трафик`: счётчик Remnawave текущего tracking периода, не расчёт billing и не только отображённого интервала графика.
- RX+TX: скорость интерфейсов, включая не-proxy трафик. CPU первого agent sample может отсутствовать; RAM из Remnawave не всегда равна контейнерной RAM.
- Импортированные чужие ноды доступны в API мониторинге/операциях Remnawave, но не становятся root-managed агентом автоматически.

Alerts после повторных offline samples уменьшают шум. Нет гарантии доставки Telegram; Telegram необязателен, токен encrypted, в чат идут метаданные нод/заданий, не пароли.

## Обслуживание нод

- Restart/enable/disable через Remnawave, с подтверждением имени. Не делает root shell.
- Update image — только ваш `remnawave/node` image; задайте version@digest в настройках, затем подтвердите update конкретной ноды. Agent сохраняет предыдущий override и пытается вернуть его при ошибке pull/up. Успешный compose не является end-to-end health-check Xray: подтвердите Online и тестового клиента.
- Sync TLS проверяет принадлежность profile/node, refuses shared чужой профиль/изменённые inbound tags. Меняет только сертификаты, сохраняет remote routing edits. Новый шаблон **не перезаписывает** старые профили.
- Certificate renewal делает acme.sh на ноде; отдельная операция GhostFleet синхронизирует новый сертификат в profile. Если не хватает CA chain/files/агент недоступен, выдаётся alert, старый профиль не затирается.
- Logs — ограниченный tail контейнера, частичная redaction, только полному администратору, событие в audit. Не публиковать без проверки.
- Running job нельзя безопасно «отменить» кнопкой; queued job можно отменить. Restart/stop контроллера во время bootstrap может оставить частичную установку. Проверяйте её перед retry и вводите credentials заново.

## Зашифрованный off-site backup

Важная пара: **DB + master.key**. Без master.key не расшифровать токен/template/agent keys. Вместе эта пара раскрывает все сохранённые секреты, поэтому plaintext локальную копию нельзя отправлять в GitHub/облако.

На другом доверенном устройстве:

```bash
# Установите age своим package manager
age-keygen -o ghostfleet-backup-identity.txt
# Команда печатает public recipient age1...; только его переносим на VPS.
```

Private identity оставьте **вне** panel VPS. На VPS:

```bash
sudo apt-get install age
sudo bash /opt/ghostfleet/current/deploy/backup.sh \
  --recipient age1YOUR_REAL_PUBLIC_RECIPIENT \
  --output /var/backups/ghostfleet/backup.tar.gz.age
```

Здесь placeholders надо заменить. Backup ждёт отсутствия queued/running jobs, блокирует изменения, использует SQLite backup API, сохраняет DB/master/env/manifest, удаляет sessions/challenges **в копии**, упаковывает и шифрует age. Живые сессии не отзываются. После успешного backup блокировка снимается.

Скопируйте `.age` на отдельный хост и периодически проверяйте restore на изолированном VPS. Создавайте архив после изменений API/template/нод и до updates. `--allow-plaintext` — только сознательная root-only emergency копия, с предупреждением; default требует recipient.

Pre-update snapshots тоже содержат master рядом с DB, root0600, **не зашифрованы**. Это страховка обновления, не off-site backup. Не оставляйте их бессрочно.

## Restore

Установите доверенный совместимый GhostFleet release на заменяющем/изолированном сервере; если первый setup требует нового admin password, это только временный пароль до restore. Не подключайте production API до проверки.

```bash
sudo bash /opt/ghostfleet/current/deploy/restore.sh \
  --archive /path/to/backup.tar.gz.age \
  --identity /path/to/ghostfleet-backup-identity.txt \
  --confirm RESTORE
```

Restore принимает только DB/master/env/manifest, без links/paths, проверяет checksums и SQLite integrity, останавливает service, убирает старые WAL/SHM, восстанавливает права. Все sessions/challenges и временные SSH payload удаляются; активные задания отмечаются interrupted. Используются **пароль и TOTP/recovery из backup**.

После:

1. Проверить restored PUBLIC_URL/port/mode, nginx/VPN/firewall, `sudo ghostfleet check`, `systemctl status`, login.
2. При новом egress IP через свой административный SSH/консоль исправить `from=` authorized_keys на нодах и integration manager IP. Старое ограничение не обходится автоматически.
3. Проверить inventory, принадлежность профилей, Online и тестовый клиент. Ноды, созданные **после** backup, могут импортироваться из Remnawave как unmanaged: их приватные management keys в старом архиве отсутствуют.
4. Уберите private age identity с panel VPS, если копировали для restore; не оставляйте единственную её копию там.

**Restore разрушительно заменяет текущих пользователей/настройки/state.** Сначала отдельный backup текущего состояния. Не восстанавливать чужой/untrusted архив: age encryption обеспечивает конфиденциальность, но не доказывает автора, знающего public recipient.

Это **не** бэкап самой Remnawave DB и VPS нод. Делайте их отдельно. При большом изменении схемы в будущем нельзя просто переключить old code; нужна совместимая DB копия.

## Доступ и обслуживания приложения

```bash
sudo ghostfleet check
sudo ghostfleet reset-password    # 2FA сохраняется, все sessions revoked
sudo ghostfleet reset-mfa         # явное RESET-MFA, затем enroll вновь
sudo ghostfleet revoke-sessions
sudo journalctl -u ghostfleet --since today
```

Нет штатной online master-key rotation: никогда не заменяйте файл случайным новым ключом, рассчитывая сохранить ciphertext. После компрометации нужна полноценная ротация токенов/ключей и восстановление доверенной инфраструктуры.
