# Частые проблемы

| Симптом | Что проверить |
|---|---|
| localhost:8088 не открывается | Туннель запущен на ноутбуке, port forwarding не занят, systemctl status ghostfleet; сервис не слушает публичный интерфейс |
| 403 Origin | Используется точный PUBLIC_URL. Для default — http://localhost:8088, не 127.0.0.1/иной порт; не обходите проверку заголовками |
| 403 IP | Фактический peer/nginx remote_addr входит в allowlist, вы на нужном VPN; не подставляйте доверенный X-Forwarded-For вручную |
| TOTP не принимается | NTP/время VPS и телефона; код уже мог быть использован. Дождитесь следующего 30-секундного кода; recovery только одноразовый |
| TLS панели не выпускается | DNS admin FQDN на VPS, 80 доступен ACME, нет конфликтующего nginx server_name; закрытый без-публичного-80 VPS → tunnel/custom CA |
| Первая install завершилась ошибкой | Если создан новый env/site — installer убирает их, encrypted state/password сохраняет. Повторить ту же команду, не генерировать новый master поверх старого |
| API 401/403/404 | URL именно Remnawave backend v3, /api один раз; token без Bearer с нужными правами; reverse proxy не режет endpoints; не открывать токен в логах |
| Не получается сменить API URL | Нужно повторно ввести новый токен для нового сервера: старый не пересылается другому endpoint |
| API private address запрещён | Явно API_ALLOW_HOSTS в server env; HTTPS обязателен. HTTP только при deliberate ALLOW_API_HTTP=1 для изолированного VPN |
| DNS проверки ноды не проходят | DNS-only; A/AAAA все на выбранный IP. По IPv4 удалить чужой AAAA; propagation. Domain нельзя заменить IP, нужен сертификат |
| SSH ключ изменился | НЕ нажимать вслепую. Сверить через провайдерскую консоль после переустановки/изменения SSH, заново probe; password не был отправлен при mismatch |
| SSH password rejected | PasswordAuth на ноде реально разрешён? Ubuntu cloud часто key-only. Используйте расширенную форму SSH-key; не ослабляйте SSH ради панели |
| sudo | root либо NOPASSWD sudo. Иначе отдельный sudo password; неинтерактивный sudo с tty requirement не поддерживается |
| blocked чужая Remnanode | Адаптер не принимает существующий unmanaged /opt/remnanode/.env или marker чужого контроллера; используйте новый VPS/осознанный ручной перенос |
| ACME ноды ошибся, код 78 | TCP80, HTTP-01, DNS, port 80 свободен, CA rate limits; cert файлы обязательны. Upstream мог вывести warning и exit0, adapter это не считает успехом |
| SHA256/GPG mismatch | Установка fail-closed. Не удаляйте проверку. Review нового upstream commit/архива/подписного ключа и обновление соответствующих pins в своём repo |
| job done, node not Online | Remnawave egress → node2222, provider firewall, container remnanode, SECRET_KEY, config validation; статус подтверждает API, не Docker |
| новая нода не в subscription | Hosts, active inbounds node profile, назначения Internal Squads и принадлежность пользователя; проверить тип клиента/Hysteria2 и subscription template |
| metrics/agent недоступен | from= использует настоящий source IP GhostFleet. Если контроллер перенесён — исправлять через собственный SSH/консоль, не key агента |
| TLS sync blocked | Профиль переназначен/стал shared с чужими нодами/переименованы inbound tags. Разделите профили; не заставляйте blind replace |
| обновление/backup refused | Ожидающие/активные jobs или ongoing maintenance. Дождаться или отменить только queued jobs |
| retained maintenance после kill | Если никакой backup/update больше не работает, flag expires через час; root может сбросить maintenance_until в DB. Сначала проверить процессы, не открывать гонку |

На **ноде** своим обычным административным SSH, не restricted ключом:

```bash
sudo docker ps -a --filter name=remnanode
sudo docker logs --tail 100 remnanode
sudo ss -lntup
sudo cat /etc/ghostfleet-node.json
sudo nft list ruleset              # или фактический firewall вашей ОС
```

Смотрите локальный `/var/log/ghostly-installer.log`; там могут быть конфиденциальные данные. Не публикуйте `.env`, TLS private key, полный Config Profile, node API SECRET_KEY, SQL backup или raw dumps при обращении за помощью.
