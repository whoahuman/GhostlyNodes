# Собственный GitHub и обновления

Архив — исходники, не чужой repository deployment. Создайте свой repo, распакуйте и положите app/deploy/node/requirements в его корень. Все обязательные файлы, включая hidden `.github`, `.gitignore`, входят в архив.

## Что можно публиковать

Исходники, UI, docs, тесты с синтетическими test-only значениями, lock-файлы и JSON **с REPLACE_WITH заглушками**. MIT относится только к собственному коду GhostFleet, лицензии сторонних проектов отдельные.

## Чего не должно быть в git

Заполненный JSON с bridge ID, SSH keys/passwords, API/Telegram tokens, `.env` установки, DB/WAL, `master.key`, backups, demo-state и virtualenv. `.gitignore` уменьшает риск, но не отменяет review. `git add -f` и ранее закоммиченные файлы всё равно могут утечь. Если секрет оказался в history — отозвать/заменить, удаления файла в последнем commit недостаточно.

## Public source repository

Root installer fetch поддерживает только `https://github.com/USER/REPO.git`, без токенов в URL, и ref commit/tag/branch. Рекомендуется точный 40-hex commit SHA. Ветку `main` можно передать, но она mutable: перед установкой review именно целевого commit.

Первый root-скрипт тоже берите с SHA через raw.githubusercontent.com, скачивайте в файл и прочитайте. Не делайте `curl ... | bash` без просмотра. Git SHA/hashes не заменяют доверие к владельцу repo: ваш изменённый код запускается с правами сервиса, а install script — root.

## Private repository

Токены в URL запрещены намеренно, installer не создаёт PAT и не публикует private sources. Клонируйте private repo **как свой обычный пользователь** через собственный GitHub SSH/deploy key/credential helper, затем:

```bash
git clone git@github.com:YOUR_LOGIN/YOUR_REPO.git
cd YOUR_REPO
git checkout COMMIT_SHA
sudo bash deploy/install.sh --source "$(pwd)" --mode tunnel
```

Для обновления private source:

```bash
# в локальном checkout под вашим пользователем
git fetch origin
git checkout NEW_COMMIT_SHA
sudo bash /opt/ghostfleet/current/deploy/update.sh --source "$(pwd)"
```

Не давайте приложению GitHub PAT и не копируйте `.git/credentials` в release.

## Обновить public source

```bash
sudo bash /opt/ghostfleet/current/deploy/update.sh --ref NEW_COMMIT_SHA
# Если ранее устанавливали --source без saved repo URL:
sudo bash /opt/ghostfleet/current/deploy/update.sh \
  --repo https://github.com/YOUR_LOGIN/YOUR_REPO.git --ref NEW_COMMIT_SHA
```

Перед этим encrypted off-site backup и отсутствие queued/running jobs. Установщик строит новый release с exact hashed wheels, блокирует очередь, останавливает service, сохраняет согласованный snapshot, переключает symlink и проверяет health. При неудачном запуске возвращает предыдущий **code release**. Это не автоматический downgrade произвольной будущей schema DB; pre-update snapshot позволяет ручное восстановление.

Nginx/mode/.env/admin password при update сохраняются. Старые releases/snapshots автоматически не удаляются — очистка только после успешного пилота и backup.

## CI / зависимости

`.github/workflows/ci.yml`: Python 3.10/3.13, pytest, ruff, Bandit, pip-audit runtime lock, bash/shellcheck, JS syntax. Actions pinned по commit; недельный audit. Dependabot готовит PR, не выполняет auto-merge.

Если меняете зависимости, обновляйте оба input файла/locks, например установленным `uv`:

```bash
uv pip compile --universal --generate-hashes --python-version 3.10 requirements.in -o requirements.txt
uv pip compile --universal --generate-hashes --python-version 3.10 requirements-dev.in -o requirements-dev.txt
```

Проверьте matrix CI, package Python requirements и audit перед новым deployment SHA. Installer не устанавливает произвольные sdists/build hooks: `--only-binary=:all: --require-hashes`.
