# Установка и сетевые режимы

Панель управляется systemd и слушает `127.0.0.1`, не Docker published port. Установщик контроллера не меняет firewall/SSH/Docker хоста. На ноде отдельный root-адаптер действительно применяет firewall и Docker.

## SSH-туннель — default

```bash
sudo bash deploy/install.sh --repo https://github.com/YOU/REPO.git --ref COMMIT_SHA --mode tunnel
# На ноутбуке
ssh -N -L 127.0.0.1:8088:127.0.0.1:8088 YOUR_SSH_USER@PANEL_IP
```

Browser origin: `http://localhost:8088`. Только localhost, не сторонний hostname и не `http://127.0.0.1:8088` вместо настроенного origin. Все cookies и CSRF/Origin рассчитаны на настроенный URL.

## Уже существующий VPN + HTTPS

```bash
sudo bash deploy/install.sh \
  --repo https://github.com/YOU/REPO.git --ref COMMIT_SHA \
  --mode vpn --domain admin.example.com --email owner@example.com \
  --allow-cidr '10.66.0.2/32,10.66.0.3/32'
```

Сначала создайте/проверьте VPN. Контроллер не выдаёт VPN-ключи и не настраивает WireGuard/Tailscale. Закройте внешний 443 на provider firewall либо привяжите nginx к VPN interface; CIDR должен быть адресом пользователя **после VPN**, видимым nginx. Нельзя просто написать 10.0.0.0/8 и считать весь хост приватным.

Для Let's Encrypt HTTP-01 временно/постоянно нужен TCP/80 из интернета и публичная DNS запись на этот VPS. `/.well-known/acme-challenge/` доступен без admin allowlist; другая HTTP локация не даёт доступ к приложению. Если VPS совершенно без публичного 80 — используйте tunnel, или поставьте свой сертификат/CA и nginx вручную. Штатный install не автоматизирует DNS-01 для панели.

## HTTPS allowlist без VPN

```bash
sudo bash deploy/install.sh \
  --repo https://github.com/YOU/REPO.git --ref COMMIT_SHA \
  --mode allowlist --domain admin.example.com --email owner@example.com \
  --allow-cidr 'YOUR_STATIC_IPV4/32,YOUR_STATIC_IPV6/128'
```

Подставьте реальные IP, не буквальные placeholders. Для динамического домашнего IP предпочтительнее VPN с постоянным адресом. Allowlist применяется и в nginx, и в API. Certbot renewal hook перезагружает nginx после обновления сертификата; проверить `sudo certbot renew --dry-run`.

## Публичный HTTPS

`--mode public --domain … --email …` требует ввод `PUBLIC`. Нет allowlist, но остаются пароль/TOTP, rate-limit, CSRF, защищённые cookies. Вы сознательно повышаете attack surface. Не рекомендовано для root-инфраструктурной панели.

## Размещение файлов

| Путь | Назначение |
|---|---|
| `/opt/ghostfleet/releases/<commit>-<timestamp>` | root-owned release и virtualenv |
| `/opt/ghostfleet/current` | активный symlink |
| `/etc/ghostfleet/ghostfleet.env` | root:ghostfleet 0640, URL/mode/server policy, не admin password |
| `/etc/ghostfleet/source.json` | repo/ref/commit, без credentials |
| `/var/lib/ghostfleet/ghostfleet.sqlite3` | encrypted state, metrics, audit |
| `/var/lib/ghostfleet/master.key` | 32-byte AES key, owner ghostfleet, 0400 |
| `/usr/local/bin/ghostfleet` | console CLI wrapper, запуск через sudo |
| `/etc/systemd/system/ghostfleet.service` | непривилегированный sandboxed service |
| `/var/backups/ghostfleet` | локальные snapshots / age archives; не GitHub |

Один worker обязателен: очереди/locks/rate state рассчитаны на один процесс. Не запускайте несколько replicas на одной DB.

## Дополнительная server policy

Измените `/etc/ghostfleet/ghostfleet.env`, затем при отсутствии jobs `sudo systemctl restart ghostfleet`:

```ini
# Разрешён только конкретный API hostname (не URL, без /api)
GHOSTFLEET_API_ALLOW_HOSTS=rw.example.com
# Не включать без изолированного VPN и явного понимания риска
GHOSTFLEET_ALLOW_API_HTTP=0
# При необходимости управлять VPN-нодами: точные доверенные сети
GHOSTFLEET_PRIVATE_NODE_CIDRS=10.66.1.0/24
GHOSTFLEET_BIND_SESSION_IP=1
```

Private Remnawave API допускается только с explicit API_ALLOW_HOSTS. HTTP дополнительно требует ALLOW_API_HTTP=1; штатно HTTPS обязателен. Если используете private CA — установите её в системное trust store и корректно настройте HTTPS, не выключайте проверки TLS.

После смены публичного URL/mode/port самостоятельно синхронизируйте nginx/firewall и зайдите заново; `update.sh` не выполняет миграцию схемы доступа. Файл `.env.production.example` — памятка, не готовый production-secret file.
