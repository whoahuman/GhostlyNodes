# Защита и правильное закрытие панели

GhostFleet контролирует root-установку нод и обладает привилегированным API-токеном Remnawave. Относитесь к нему как к инфраструктурной админке, а не публичному сайту.

## Рекомендуемая схема

```text
Ноутбук ── SSH-туннель / ваш VPN ── GhostFleet на отдельном VPS
                                     │ HTTPS + Bearer → Remnawave
                                     │ SSH, pinned host key → ноды
Remnawave ── native authenticated node API → NODE_IP:2222 (только IP Remnawave)
Клиенты    ── TCP/443 gRPC + UDP/443 Hysteria2 → ноды
ACME       ── TCP/80 HTTP-01 → ноды
```

**Лучший базовый вариант:** `--mode tunnel`. Только loopback:8088, доступ на VPS по SSH-ключу, пароль панели + TOTP. Открытый HTTP localhost в этой схеме проходит внутри зашифрованного SSH-туннеля; это не открытая HTTP-админка в интернете.

Вариант с VPN: сначала самостоятельно WireGuard/Tailscale/другой VPN, затем `--mode vpn --allow-cidr …`. Приватный allowlist применяется в приложении и nginx. `vpn` не создаёт VPN и сам по себе не делает nginx VPN-only: закройте внешний 443 на firewall/security group или привяжите nginx к VPN-интерфейсу. HTTPS-сертификат должен соответствовать вашему DNS/CA.

Если выбираете `allowlist`, используйте точные адреса администратора / небольшие доверенные CIDR и HTTPS. Allowlist не шифрует сеть. Публичный режим намеренно требует подтверждения `PUBLIC`, но **не рекомендуется**.

## Что реализовано в коде

| Слой | Механизм |
|---|---|
| Пароль | Argon2id, 64 MiB, time cost 3; нет default password/публичной регистрации; первый пароль задаётся на консоли |
| 2FA | TOTP обязательно до доступа к управлению; один код не принимается повторно; recovery-коды одноразовые, хранятся хэши |
| Сессии | Случайный opaque cookie, в DB только SHA256; HttpOnly, SameSite=Strict, Secure и `__Host-` при HTTPS; idle 30 минут, максимум 8 часов |
| IP / UA | Проверка peer IP/allowlist; привязка сессии к IP и хэшу User-Agent; `/64` группировка IPv6 для rate-limit |
| Брутфорс | Ограничения на IP и глобально, Argon2 выполняется максимум в двух задачах одновременно; login rate-limit в nginx при HTTPS |
| Браузер | CSRF token для изменений + точный Origin; CSP с локальными скриптами, frame-deny, no-sniff, Referrer-Policy; HTML escaping |
| Запросы | Тело ≤1 MiB, полный приём тела ≤15 секунд, no-store для API; валидационные ошибки без отражения passwords/tokens |
| Секреты | AES-256-GCM, отдельный AAD контекст поля/ноды/задания, случайный nonce; `master.key` 0400, state directory 0700, DB 0600 |
| API-токен | Write-only в UI; сохранённое значение не возвращается клиенту; смена URL требует нового токена, старый не пересылается новому серверу |
| Remnawave | HTTPS validation, redirect disabled, ambient proxy disabled; DNS IP проверяется и используется непосредственно с сохранением Host / TLS SNI и проверкой имени |
| SSH перед bootstrap | Только literal IP; credential-free probe; одноразовый challenge session/IP/port bound; точный known_hosts, без agent/config/autodiscovery ключей |
| После bootstrap | Отдельный ed25519 ключ на ноду, `restrict,from=…,command=…`; только health/metrics/certificates/logs/update; shell, SFTP, PTY и forwarding этим ключом не доступны |
| Выполнение | Валидированные домены/CIDR/образ, shlex для параметров; агент не использует shell=True/произвольную команду; bounded stdout |
| Supply chain | Ghostly и fresh acme.sh по commit + SHA256, повторная проверка на ноде; default Docker image digest; signed Docker APT key fingerprint; Python wheels exact version + hashes |
| Сервис | Непривилегированный ghostfleet, один worker, root-owned releases, systemd sandbox, NoNewPrivileges, ограниченный writable state |
| Аудит | Входы/ошибки/изменения/операции фиксируются без raw installer output и passwords; установочные credentials удаляются после задания/ошибки/restart |

CSP допускает inline **style attributes** для прогресс-баров, но не inline scripts/handlers. Это не защита от уже скомпрометированного local JS/dependency.

Loopback, link-local, multicast, reserved и известные metadata IP запрещены для SSH. Private CIDR нод — только explicit server-side opt-in. API private host тоже должен быть явно разрешён; link-local/metadata исключения не открываются opt-in.

## Не путать три набора IP

1. **Админ вашего ноутбука / VPN:** `GHOSTFLEET_ALLOWED_CIDRS` и nginx allowlist.
2. **Egress Remnawave:** доступ к `NODE_PORT` на нодах (по умолчанию 2222). Для native node API адрес Cloudflare не подходит.
3. **Egress GhostFleet:** `from=` ограничение root-ключа агента. Обычно статический IP VPS GhostFleet, не адрес браузера.

При NAT/IPv6/egress VPN проверьте именно адрес, который видит нода. Используйте отдельные `/32` и `/128`. При смене IP контроллера сначала через собственный SSH/консоль обновите `from=` на нодах; новая машина не должна обходить старую защиту автоматически.

nginx перезаписывает `X-Forwarded-For` реальным `$remote_addr`; uvicorn доверяет forwarding только loopback. Не включайте `--forwarded-allow-ips '*'`, не ставьте произвольный proxy перед этой схемой и не доверяйте пользовательским `X-Forwarded-*`. За Cloudflare понадобится отдельно выверенная модель trusted proxies; штатный вариант — DNS-only / VPN.

## Обязательная гигиена владельца

- Отдельные VPS/пользователь/репозиторий для контроллера; не публиковать порт 8088.
- SSH на контроллер по личному ключу, при необходимости с hardware/FIDO2 ключом. Provider security group: SSH только с вашей сети/VPN. Сохранить провайдерскую recovery-консоль.
- Держать OS, OpenSSH, nginx, Docker, Remnawave и зависимости обновлёнными; проверять CI/weekly pip-audit. Закреплённые версии не заменяют обновления безопасности.
- Root password SSH на нодах не отключается автоматически: прежде подтвердите собственный административный key-only доступ отдельной сессией/консолью. Затем самостоятельно отключите password login и ограничьте management SSH на firewall. **Не отключайте рабочий SSH вслепую.**
- Длинный уникальный пароль, TOTP/recovery вне VPS. Не хранить всё в одном публичном месте.
- Заполненный RU_BRIDGE JSON, приватные SSH/TLS ключи, `.env`, DB, мастер-ключ, backups — **не GitHub**, в том числе private repo.
- Зашифрованный off-site backup; private age identity хранить на другом устройстве. Шифрование диска/зашифрованный swap — отдельная ответственность ОС.
- Ограничить API hostname через `GHOSTFLEET_API_ALLOW_HOSTS`; отдельный API-токен только для GhostFleet. У Remnawave-пользователя токена должны быть права на используемые операции; универсального safe RBAC scope здесь не изобретается.
- Проверить правила ноды через свой SSH: 2222 действительно закрыт извне, 80/443 назначены правильно; приложение само не проверяет provider firewall.

## Честные ограничения

- **Компрометация VPS/пользователя ghostfleet/RCE ломает local encryption:** работающий сервис должен читать master.key. Атакующий получит токен, приватный шаблон и ключи агента. AES-GCM защищает копию DB без ключа, не полностью захваченный хост.
- Bootstrap выполняет root-код на ноде и меняет её firewall. Проверяйте исходники и используйте новый тестовый VPS. Защита web app не делает root-установщик безопасным для произвольного сервера с существующими сервисами.
- Forced-command ключ **не полностью read-only**: update может pull/up контейнера, logs/certificates раскрывают информацию администратору. Разрешена только namespace `remnawave/node`; официальный образ всё равно является доверенным root-level компонентом Docker.
- Pin covers entrypoints/archives/default image, но не замораживает подписанные OS repositories или весь код сторонних проектов. Уже установленный владельцем acme.sh сохраняется и может иметь собственные auto-updates/hooks. Проверяйте его отдельно.
- Приватные TLS ключи и параметры bridge передаются Remnawave через API и хранятся в его профилях/DB. Безопасность Remnawave — часть общей модели доверия. Не включайте его body/debug logging с secrets.
- Данные API/имена/заметки могут быть недоверенными; UI экранирует их, CSV защищает formula injection, но экспорт всё равно содержит IP и labels инфраструктуры.
- Логи ограничены и частично редактируются, однако могут содержать user IP/UUID и контекст, который regex не распознает. Не публикуйте их без просмотра.
- TLS проверяет доверие цепочки, имя, срок и ключ; это не online OCSP/CRL/Certificate Transparency аудит.
- Internal Squad assignment — read/merge/write без server CAS: не редактируйте тот же squad одновременно в Remnawave GUI и GhostFleet.
- Нет независимого pentest и гарантии «взломать невозможно». Первая версия требует пилота на одной ноде и собственного review перед production.

## Если подозреваете проникновение

Закройте доступ к панели на firewall, остановите ghostfleet, сохраните forensic-копию диска/журнала. С чистой консоли отзовите сессии, поменяйте пароль/2FA, перевыпустите API-токен Remnawave, отзовите management authorized_keys на нодах, проверьте образы/профили и bridge credentials. После root-компрометации пересоздавайте VPS из доверенного образа, а не просто меняйте пароль. Не публикуйте forensic archive с master.key.
