# Архитектура и источник API контрактов

## Компоненты

- `app/main.py`: FastAPI factory, static UI, login/TOTP/CSRF, integration/template, nodes/jobs/audit/CSV.
- `app/security.py`, `config.py`, `db.py`: ASGI body/IP/Origin/security headers, sessions/rate limits, Argon2/AES-GCM, SQLite WAL + secure_delete.
- `app/deployment.py`: single-process queue, temporary encrypted credentials, SSH bootstrap и регистрация. После credentials wipe retry запрашивает их вновь.
- `app/remnawave.py`: HTTPS client, explicit destination policy, IP-pinned request с original SNI/Host, envelope `response`.
- `app/ssh.py`: credential-free probe, точный pinned host key, явные keys/no agent/no ssh_config; bounded agent responses.
- `app/template.py`: импорт структуры, country/index mapping, routing tags, inline TLS, public CA verification, redaction.
- `app/monitor.py`: API inventory, unknown/stale, local 7-day samples, host metrics, alerts и TLS sync.
- `node/bootstrap.sh`: root адаптер на сервере ноды; verified Ghostly source + pinned fresh acme, signed Docker APT, per-node markers/forced SSH key.
- `node/agent.py`: stdlib-only fixed-command root agent; health/metrics/certificates/logs/update, без arbitrary shell.
- `deploy/`: root panel installer/update/backup/restore, hardened non-root systemd.

Очередь сериализована, настройки защищены при active jobs; один uvicorn worker. Полного durable worker-брокера нет: restart прерывает jobs и чистит payload, затем нужен осознанный retry. Ownership marker `/etc/ghostfleet-node.json` связывает ноду с instance UUID и node UUID; нельзя автоматически перезаписать чужую установку.

## Использованные источники

Контракты проверялись по [исходникам Remnawave backend](https://github.com/remnawave/backend/tree/b22970cc88481a7e278b5767721672a18f8b2ada), версия 3.4.4. `libs/contract` и `src/modules` — приоритетный источник, а не неофициальные пересказы.

Под `/api` с response envelope:

| Операция | Endpoint / shape |
|---|---|
| Версия | GET /system/metadata → version |
| Inventory | GET /nodes → array |
| Node API shared payload | GET /keygen → secretKey |
| Config profile | POST /config-profiles `{name,config}`; PATCH /config-profiles `{uuid,config}` |
| Создать ноду | POST /nodes `{name,address,port,countryCode,configProfile:{activeConfigProfileUuid,activeInbounds}}` |
| Обновить ноду | PATCH /nodes `{uuid,...}`; не PATCH /nodes/{uuid} |
| Управление | POST /nodes/{uuid}/actions/{restart,enable,disable} |
| Squads | GET /internal-squads → internalSquads; PATCH /internal-squads `{uuid,inbounds:[UUID...]}` |
| Hosts | GET/POST /hosts, inbound `{configProfileUuid,configProfileInboundUuid}`, nodes `[nodeUuid]`, securityLayer TLS |

Для gRPC Host.path — **serviceName без искусственно добавленного slash**: в `resolve-proxy-config.service.ts:resolveGrpc` `inputHost.path` напрямую overrides `grpcSettings.serviceName`. Hysteria2 использует h3 и свой inbound; user UUID/password создаёт Remnawave, не baked clients в template.

Профиль, node, Hosts и Squad assignment — последовательные API-изменения, не одна server transaction. После частичной ошибки результат виден в local state и retry проверяет принадлежность/существующие ресурсы; не обещается атомарный global rollback всех объектов. Owner должен review результата в Remnawave.

## Supply-chain pins (v1.0.0)

- Ghostly 1.2.2: commit `00a5df50a45b865e685554683afbb99bb8c81d4f`.
  - URL: `https://raw.githubusercontent.com/whoahuman/Ghostly-Infrainstall/00a5df50a45b865e685554683afbb99bb8c81d4f/ghostly-infra-installer.sh`
  - SHA256: `372d67e2ae0432a1dbe7bd5cbb4238ad1e45c0c241cc8ab582730d676826f138`.
- Fresh acme.sh 3.1.6: commit `807da6498377ee5e0cf43a78091f46f12dc59a89`.
  - URL: `https://codeload.github.com/acmesh-official/acme.sh/tar.gz/807da6498377ee5e0cf43a78091f46f12dc59a89`
  - SHA256: `ddbe1bcbd1a44a2623a2af167ebdc678669e6e2eb396742f2d1d28e02dc14220`.
- Default image: `remnawave/node:3.4.1@sha256:0cdf386dd49f360fc885bb34bde21132e478e40f0deac62d616086ec0fa9257e`.
- Docker APT signing key fingerprint: `9DC858229FC7DD38854AE2D88D81803C0EBFCD88`.

Ghostly source не bundled: приложение скачивает verified bytes, передаёт на ноду. Adapter ещё раз проверяет original hash и заменяет ровно одно присваивание mutable latest на pinned image **до** выполнения original installer. Signed APT Docker используется вместо перезаписи `daemon.json`; Ghostly вызывается с `--skip-docker`. Fresh acme.sh заранее installed по pinned archive, чтобы не выполнялся fallback `get.acme.sh | sh`. Существующий owner acme.sh не перезаписывается.

README и security docs описывают границы этой модели, сторонние repositories/packages лицензируются отдельно. При смене upstream review нужны одновременно download constants, bootstrap recheck/patch и tests; silent hash bypass недопустим.
