#!/usr/bin/env python3
"""Root-side, forced-command agent. No shell, SFTP, forwarding, PTY or arbitrary argv."""

from __future__ import annotations

import json
import os
import re

# forced-command agent; fixed argv, never shell=True
import subprocess  # nosec B404
import sys
import time
from pathlib import Path

META = Path("/etc/ghostfleet-node.json")
NODE = Path("/opt/remnanode")
IMAGE_PATTERN = re.compile(r"^remnawave/node:(?:[0-9]+\.[0-9]+\.[0-9]+|latest)(?:@sha256:[a-f0-9]{64})?$")


def run(args: list[str], timeout: int = 20, allow_nonzero: bool = False) -> str:
    result = subprocess.run(
        # internal fixed argv only; untrusted image is separately validated
        args,  # nosec B603
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
        env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "HOME": "/root"},
    )
    if result.returncode and not allow_nonzero:
        raise RuntimeError("Operation failed")
    return result.stdout[:200_000]


def cpu_ticks() -> tuple[int, int]:
    numbers = list(map(int, Path("/proc/stat").read_text().splitlines()[0].split()[1:9]))
    return sum(numbers), numbers[3] + numbers[4]


def metrics() -> dict:
    total, idle = cpu_ticks()
    time.sleep(0.25)
    total2, idle2 = cpu_ticks()
    cpu = 100 * (1 - (idle2 - idle) / max(1, total2 - total))
    memory = {}
    for line in Path("/proc/meminfo").read_text().splitlines():
        key, rest = line.split(":", 1)
        memory[key] = int(rest.split()[0]) * 1024
    disk = os.statvfs("/")
    disk_total = disk.f_blocks * disk.f_frsize
    disk_free = disk.f_bavail * disk.f_frsize
    stats = {
        "cpu_pct": round(max(0, min(100, cpu)), 1),
        "load": os.getloadavg()[0],
        "memory_total": memory.get("MemTotal", 0),
        "memory_available": memory.get("MemAvailable", 0),
        "disk_total": disk_total,
        "disk_used": disk_total - disk_free,
        "uptime": float(Path("/proc/uptime").read_text().split()[0]),
        "container_running": run(
            ["/usr/bin/docker", "inspect", "--format", "{{.State.Running}}", "remnanode"], allow_nonzero=True
        ).strip()
        == "true",
    }
    return stats


def certificates() -> dict:
    return {
        "fullchain": (NODE / "certs/fullchain.pem").read_text(),
        "private_key": (NODE / "certs/privkey.key").read_text(),
    }


def logs() -> dict:
    # fixed docker logs command, no user argv
    result = subprocess.run(  # nosec B603
        ["/usr/bin/docker", "logs", "--tail", "100", "--timestamps", "remnanode"],
        capture_output=True,
        text=True,
        timeout=20,
        check=False,
    )
    text = (result.stdout + result.stderr)[-100_000:]
    text = re.sub(
        r"-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----",
        "<PRIVATE KEY OMITTED>",
        text,
    )
    text = re.sub(r"(?i)(SECRET_KEY|password|token)\s*[=:]\s*[^\s,;]+", r"\1=<REDACTED>", text)
    return {"logs": text}


def update() -> dict:
    content = sys.stdin.read(65537)
    if len(content) > 65536:
        raise ValueError("Payload too large")
    data = json.loads(content)
    if (
        set(data) != {"image"}
        or not isinstance(data["image"], str)
        or not IMAGE_PATTERN.fullmatch(data["image"])
    ):
        raise ValueError("Invalid image")
    path = NODE / "ghostfleet.override.json"
    override = json.loads(path.read_text())
    previous_image = override["services"]["remnanode"]["image"]
    override["services"]["remnanode"]["image"] = data["image"]
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(override))
    os.chmod(temp, 0o600)
    os.replace(temp, path)
    compose = ["/usr/bin/docker", "compose", "-f", str(NODE / "docker-compose.yml"), "-f", str(path)]
    try:
        run([*compose, "pull", "remnanode"], timeout=600)
        run([*compose, "up", "-d", "remnanode"], timeout=120)
    except Exception:
        override["services"]["remnanode"]["image"] = previous_image
        temp.write_text(json.dumps(override))
        os.chmod(temp, 0o600)
        os.replace(temp, path)
        # A failed pull/start restores the previous desired image.
        run([*compose, "up", "-d", "remnanode"], timeout=120, allow_nonzero=True)
        raise
    metadata = json.loads(META.read_text())
    metadata["node_image"] = data["image"]
    META.write_text(json.dumps(metadata))
    os.chmod(META, 0o600)
    return {"updated": True, "image": data["image"]}


def main() -> int:
    if os.geteuid() != 0:
        return 1
    command = os.getenv("SSH_ORIGINAL_COMMAND", "")
    handlers = {
        "health": lambda: json.loads(META.read_text()),
        "metrics": metrics,
        "certificates": certificates,
        "logs": logs,
        "update": update,
    }
    if command not in handlers:
        print('{"error":"Command not allowed"}')
        return 1
    try:
        result = handlers[command]()
        print(json.dumps(result))
        return 0
    except Exception:
        # Never serialize exceptions containing command output or private keys.
        print('{"error":"Operation failed; inspect the node locally"}')
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
