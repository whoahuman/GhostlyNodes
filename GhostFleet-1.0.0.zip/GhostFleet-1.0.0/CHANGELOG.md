# Изменения

## 1.0.0 — 2026-10-04

Первая версия GhostFleet: Remnawave v3 contract integration, Ghostly adapter, приватная установка systemd, русскоязычная UI, обязательная TOTP, temporary encrypted SSH credentials, pinned SSH trust, restricted node agent, индивидуальные Config Profiles/TLS/Hosts/Internal Squads, monitoring/jobs/audit, age backup/restore и CI.

Release не прошёл live E2E на инфраструктуре владельца. Перед массовым deployment нужен пилот на новом VPS и review security/операционных ограничений.
