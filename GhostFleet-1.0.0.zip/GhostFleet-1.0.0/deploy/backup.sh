#!/usr/bin/env bash
# Consistent SQLite snapshot + master key. age encryption is required by default.
set -Eeuo pipefail
umask 077
RECIPIENT=""; OUTPUT=""; PLAINTEXT=0; STATE=/var/lib/ghostfleet; TMP=""; LOCKED=0
usage(){ cat <<'EOF'
sudo bash /opt/ghostfleet/current/deploy/backup.sh --recipient age1... [--output /path/backup.tar.gz.age]

Generate an age identity OFF the panel server: age-keygen -o identity.txt
Copy only its PUBLIC age1... recipient to this server.
--allow-plaintext is available for an intentional root-only local emergency copy.
EOF
}
while (($#)); do
  case "$1" in --recipient) RECIPIENT="${2:?}";shift 2;; --output) OUTPUT="${2:?}";shift 2;; --allow-plaintext) PLAINTEXT=1;shift;; -h|--help) usage;exit 0;; *) echo 'Unknown argument' >&2;exit 1;; esac
done
[[ $EUID -eq 0 ]] || { echo 'Use sudo' >&2;exit 1; }
[[ -f "$STATE/ghostfleet.sqlite3" && -f "$STATE/master.key" ]] || { echo 'Panel not initialised' >&2;exit 1; }
if (( ! PLAINTEXT )); then
  [[ "$RECIPIENT" =~ ^age1[a-z0-9]{40,100}$ ]] || { echo 'A valid age recipient is required' >&2;exit 1; }
  command -v age >/dev/null || { echo 'apt install age' >&2;exit 1; }
fi
cleanup(){
  if ((LOCKED)); then
    python3 - "$STATE/ghostfleet.sqlite3" <<'PY' || true
import sqlite3,sys
with sqlite3.connect(sys.argv[1]) as conn:conn.execute("UPDATE settings SET value='0' WHERE key='maintenance_until'")
PY
  fi
  [[ -z "$TMP" ]] || rm -rf -- "$TMP"
}
trap cleanup EXIT
python3 - "$STATE/ghostfleet.sqlite3" <<'PY'
import json,sqlite3,sys,time
with sqlite3.connect(sys.argv[1],timeout=15) as c:
    c.execute('BEGIN IMMEDIATE')
    if c.execute("SELECT COUNT(*) FROM jobs WHERE state IN ('queued','running')").fetchone()[0]:
        raise SystemExit('Wait for installation/maintenance jobs to complete before backing up credentials')
    row=c.execute("SELECT value FROM settings WHERE key='maintenance_until'").fetchone()
    if row and json.loads(row[0])>time.time():raise SystemExit('Maintenance already in progress')
    c.execute("INSERT INTO settings VALUES('maintenance_until',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(json.dumps(time.time()+3600),))
PY
LOCKED=1
TMP="$(mktemp -d /tmp/ghostfleet-backup.XXXXXXXX)"
python3 - "$STATE/ghostfleet.sqlite3" "$TMP/ghostfleet.sqlite3" <<'PY'
import sqlite3,sys
with sqlite3.connect(sys.argv[1]) as src,sqlite3.connect(sys.argv[2]) as dst:src.backup(dst)
with sqlite3.connect(sys.argv[2]) as c:
    c.execute("UPDATE settings SET value='0' WHERE key='maintenance_until'")
    c.execute('DELETE FROM sessions');c.execute('DELETE FROM challenges')
PY
cp "$STATE/master.key" "$TMP/master.key"
cp /etc/ghostfleet/ghostfleet.env "$TMP/environment.env"
python3 - "$TMP" <<'PY'
import hashlib,json,sys,time
from pathlib import Path
p=Path(sys.argv[1])
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while chunk:=f.read(1024*1024):h.update(chunk)
    return h.hexdigest()
files={name:digest(p/name) for name in ('ghostfleet.sqlite3','master.key','environment.env')}
(p/'manifest.json').write_text(json.dumps({'format':1,'schema':1,'created':time.time(),'files':files},indent=2))
PY
chmod 0600 "$TMP"/*
tar -C "$TMP" -czf "$TMP/backup.tar.gz" ghostfleet.sqlite3 master.key environment.env manifest.json
install -m 0700 -d /var/backups/ghostfleet
if ((PLAINTEXT)); then
  OUTPUT="${OUTPUT:-/var/backups/ghostfleet/$(date +%Y%m%d-%H%M%S).tar.gz}"
  [[ ! -e "$OUTPUT" ]] || { echo 'Output already exists' >&2;exit 1; }
  install -m 0600 "$TMP/backup.tar.gz" "$OUTPUT"
  echo 'WARNING: this archive contains a master key + database and can reveal all stored secrets!' >&2
else
  OUTPUT="${OUTPUT:-/var/backups/ghostfleet/$(date +%Y%m%d-%H%M%S).tar.gz.age}"
  [[ ! -e "$OUTPUT" ]] || { echo 'Output already exists' >&2;exit 1; }
  age -r "$RECIPIENT" -o "$OUTPUT" "$TMP/backup.tar.gz"
  chmod 0600 "$OUTPUT"
fi
printf 'Backup: %s\nCopy it OFF the server; do not commit it to GitHub.\n' "$OUTPUT"
