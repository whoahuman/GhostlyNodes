#!/usr/bin/env bash
# GhostFleet auto installer. Review this file and pin your own GitHub commit.
set -Eeuo pipefail
umask 077
VERSION=1.0.0
REPO=""; REF=""; SOURCE=""; MODE=tunnel; PORT=8088; DOMAIN=""; ALLOWED=""; EMAIL=""; ADMIN="admin"; UPGRADE=0
BASE=/opt/ghostfleet; STATE=/var/lib/ghostfleet; ENVFILE=/etc/ghostfleet/ghostfleet.env
OLD=""; NEW=""; SWITCHED=0; TMP=""; COMMITTED=0; ENV_CREATED=0; NGX_CREATED=0; LOCKED=0
say(){ printf '\033[1;35m[GhostFleet]\033[0m %s\n' "$*"; }
die(){ printf 'Ошибка: %s\n' "$*" >&2; exit 1; }
help(){ cat <<EOF
GhostFleet ${VERSION} — Ubuntu 22.04/24.04, Debian 12/13

sudo bash deploy/install.sh --repo https://github.com/YOU/ghostfleet.git --ref COMMIT
sudo bash deploy/install.sh --source /path/to/unpacked/project

По умолчанию: --mode tunnel --port 8088 (НЕ открыт в интернет).

Опции:
  --repo URL          ваш GitHub HTTPS repository, без токенов в URL
  --ref COMMIT/TAG    рекомендуем 40-символьный commit SHA
  --source DIR       установить из скачанных файлов, без git clone
  --mode MODE        tunnel | vpn | allowlist | public
  --domain FQDN      HTTPS-домен панели для режимов кроме tunnel
  --allow-cidr LIST  разрешённые адреса/CIDR через запятую (vpn/allowlist)
  --email EMAIL      email Let's Encrypt для HTTPS панели
  --port PORT        локальный порт приложения (8088)
  --admin LOGIN      первый администратор (пароль вводится скрыто)
  --upgrade          сохранить секреты/доступ, обновить код; нужен --ref или --source

Ноды имеют отдельный Let's Encrypt email в настройках панели.
Не запускайте этот установщик на сервере ноды вместо панели управления.
EOF
}
while (($#)); do
  case "$1" in
    --repo) REPO="${2:?}"; shift 2;; --ref) REF="${2:?}"; shift 2;;
    --source) SOURCE="${2:?}"; shift 2;; --mode) MODE="${2:?}"; shift 2;;
    --port) PORT="${2:?}"; shift 2;; --domain) DOMAIN="${2:?}"; shift 2;;
    --allow-cidr) ALLOWED="${2:?}"; shift 2;; --email) EMAIL="${2:?}"; shift 2;;
    --admin) ADMIN="${2:?}"; shift 2;; --upgrade) UPGRADE=1; shift;;
    -h|--help) help; exit 0;; *) die "Неизвестный аргумент: $1";;
  esac
done
[[ $EUID -eq 0 ]] || die 'Запустите через sudo bash'
exec 9>/run/ghostfleet-panel-install.lock
flock -n 9 || die 'Другая установка/обновление панели уже выполняется' 
cleanup(){
  local rc=$?
  if ((LOCKED)) && [[ -f "$STATE/ghostfleet.sqlite3" ]]; then
    python3 - "$STATE/ghostfleet.sqlite3" <<'PY_CLEAN' || true
import json,sqlite3,sys
with sqlite3.connect(sys.argv[1]) as c:
    c.execute("UPDATE settings SET value='0' WHERE key='maintenance_until'")
PY_CLEAN
  fi
  if [[ $rc -ne 0 && $SWITCHED -eq 1 && $COMMITTED -eq 0 ]]; then
    say 'Неудачный запуск: возвращаю предыдущий release'
    if [[ -n "$OLD" && -d "$OLD" ]]; then
      ln -sfn "$OLD" "$BASE/current"
      systemctl restart ghostfleet 2>/dev/null || true
    else
      systemctl stop ghostfleet 2>/dev/null || true
    fi
  fi
  if [[ $rc -ne 0 && $UPGRADE -eq 1 && $SWITCHED -eq 0 && -n "$OLD" ]]; then
    systemctl start ghostfleet 2>/dev/null || true
  fi
  if [[ $rc -ne 0 && $UPGRADE -eq 0 && $COMMITTED -eq 0 ]]; then
    if ((NGX_CREATED)); then
      rm -f /etc/nginx/sites-enabled/ghostfleet /etc/nginx/sites-available/ghostfleet /etc/nginx/conf.d/ghostfleet-limit.conf
      if nginx -t >/dev/null 2>&1; then systemctl reload nginx 2>/dev/null || true; fi
    fi
    if ((ENV_CREATED)); then
      systemctl stop ghostfleet 2>/dev/null || true
      rm -f "$BASE/current" "$ENVFILE"
      echo 'First install failed. Encrypted state was preserved. Rerun the same install command; existing administrator password is kept.' >&2
    fi
  fi
  [[ -z "$TMP" ]] || rm -rf -- "$TMP"
}
trap cleanup EXIT
# shellcheck disable=SC1091
. /etc/os-release
case "${ID}:${VERSION_ID}" in ubuntu:22.04|ubuntu:24.04|debian:12|debian:13) ;; *) die 'Нужен Ubuntu 22.04/24.04 или Debian 12/13';; esac
command -v systemctl >/dev/null || die 'Нужен systemd'
[[ "$PORT" =~ ^[0-9]{1,5}$ ]] || die 'Порт должен быть 1024–65535'
PORT=$((10#$PORT))
if ((PORT<1024 || PORT>65535)); then die 'Порт должен быть 1024–65535'; fi
[[ "$ADMIN" =~ ^[A-Za-z0-9_.-]{1,64}$ ]] || die 'Неверное имя администратора'
if [[ -f "$ENVFILE" && $UPGRADE -eq 0 ]]; then
  die 'Панель уже настроена. Для смены версии используйте deploy/update.sh --ref COMMIT'
fi
if ((UPGRADE)); then
  [[ -f "$ENVFILE" ]] || die 'Для upgrade нужна существующая установка'
  [[ -n "$REF" || -n "$SOURCE" ]] || die 'Для upgrade обязательно укажите --ref COMMIT/TAG или --source DIR'
  if [[ -z "$REPO" && -z "$SOURCE" && -f /etc/ghostfleet/source.json ]]; then
    REPO="$(python3 -c 'import json; print(json.load(open("/etc/ghostfleet/source.json")).get("repo",""))')"
  fi
  MODE="$(sed -n 's/^GHOSTFLEET_MODE=//p' "$ENVFILE")"
  PORT="$(sed -n 's/^GHOSTFLEET_PORT=//p' "$ENVFILE")"
  [[ "$MODE" =~ ^(tunnel|vpn|allowlist|public)$ && "$PORT" =~ ^[0-9]+$ ]] || die 'Проверьте существующий env'
fi
case "$MODE" in tunnel|vpn|allowlist|public) ;; *) die 'Неверный режим доступа';; esac
if [[ "$MODE" != tunnel && $UPGRADE -eq 0 ]]; then
  [[ -n "$DOMAIN" ]] || read -r -p 'HTTPS-домен панели (DNS уже создан): ' DOMAIN
  [[ -n "$EMAIL" ]] || read -r -p "Let's Encrypt email для панели: " EMAIL
  [[ "$DOMAIN" =~ ^[a-z0-9]([a-z0-9.-]*[a-z0-9])?$ && "$DOMAIN" == *.* ]] || die 'Нужен ASCII/Punycode FQDN, без портов и пути'
  [[ "$EMAIL" =~ ^[A-Za-z0-9.!%+_-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,63}$ ]] || die 'Проверьте email'
  if [[ "$MODE" == vpn || "$MODE" == allowlist ]]; then
    [[ -n "$ALLOWED" ]] || read -r -p 'Разрешённые IP/CIDR через запятую: ' ALLOWED
    [[ -n "$ALLOWED" ]] || die 'Пустой allowlist запрещён'
  else
    say 'ВНИМАНИЕ: публичная админка повышает риск. VPN/SSH-туннель безопаснее.'
    read -r -p 'Для публичного HTTPS напишите PUBLIC: ' answer
    [[ "$answer" == PUBLIC ]] || die 'Отменено'
  fi
fi
if [[ -z "$SOURCE" && -z "$REPO" ]]; then
  HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
  if [[ -f "$HERE/app/main.py" && -f "$HERE/requirements.txt" && $UPGRADE -eq 0 ]]; then SOURCE="$HERE";
  else read -r -p 'Ваш GitHub URL (https://github.com/USER/REPO.git): ' REPO; fi
fi
if [[ -n "$REPO" ]]; then
  [[ "$REPO" =~ ^https://github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+(\.git)?$ ]] || die 'Разрешён только GitHub HTTPS URL без секретов'
  [[ -n "$REF" ]] || read -r -p 'Commit SHA / tag [main]: ' REF
  REF="${REF:-main}"
  [[ "$REF" =~ ^[A-Za-z0-9][A-Za-z0-9._/-]{0,150}$ && "$REF" != *..* ]] || die 'Недопустимый ref'
  if ! [[ "$REF" =~ ^[a-f0-9]{40}$ ]]; then say 'Ref не является commit SHA: он может измениться. Для production лучше закрепить commit.'; fi
fi
say 'Ставлю зависимости. Firewall, SSH и Docker этого сервера НЕ меняются.'
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq python3 python3-venv git ca-certificates openssl curl age iproute2 >/dev/null
python3 -c 'import sys; assert sys.version_info >= (3,10)' || die 'Нужен Python >=3.10'
if [[ -n "$ALLOWED" ]]; then
  ALLOWED="$(python3 - "$ALLOWED" <<'PY'
import ipaddress,sys
nets=[ipaddress.ip_network(s.strip(),strict=False) for s in sys.argv[1].split(',') if s.strip()]
if not nets or any(n.prefixlen==0 or n.network_address.is_unspecified or n.network_address.is_multicast or n.network_address.is_link_local for n in nets):
    raise SystemExit('Invalid CIDR list')
print(','.join(map(str,nets)))
PY
)"
fi
getent passwd ghostfleet >/dev/null || useradd --system --home-dir "$STATE" --shell /usr/sbin/nologin --user-group ghostfleet
install -m 0755 -d "$BASE" "$BASE/releases"
install -m 0700 -o ghostfleet -g ghostfleet -d "$STATE"
install -m 0750 -o root -g ghostfleet -d /etc/ghostfleet
TMP="$(mktemp -d /tmp/ghostfleet-install.XXXXXXXX)"
if [[ -n "$REPO" ]]; then
  say "Получаю код: $REPO ($REF)"
  git -c core.hooksPath=/dev/null init -q "$TMP/repo"
  git -C "$TMP/repo" -c core.hooksPath=/dev/null remote add origin "$REPO"
  git -C "$TMP/repo" -c core.hooksPath=/dev/null fetch -q --depth 1 origin "$REF"
  git -C "$TMP/repo" -c core.hooksPath=/dev/null checkout -q --detach FETCH_HEAD
  SOURCE="$TMP/repo"
  COMMIT="$(git -C "$SOURCE" rev-parse HEAD)"
else
  SOURCE="$(realpath -- "$SOURCE")"
  [[ -f "$SOURCE/app/main.py" && -f "$SOURCE/requirements.txt" && -f "$SOURCE/deploy/ghostfleet.service" ]] || die 'Неверная папка проекта'
  COMMIT="local-$(date +%Y%m%d%H%M%S)-$(sha256sum "$SOURCE/app/main.py" | cut -c1-8)"
fi
NEW="$BASE/releases/${COMMIT}-$(date +%s)"
install -m 0755 -d "$NEW"
tar -C "$SOURCE" --exclude=.git --exclude=.env --exclude='*.env' --exclude=.venv --exclude=venv --exclude=__pycache__ --exclude=.pytest_cache --exclude=.ruff_cache --exclude=.arena --exclude=state --exclude=backups --exclude=secrets --exclude='*.sqlite*' --exclude='*.key' --exclude='*.pem' --exclude='*.age' --exclude='*.zip' --exclude='*.tar*' -cf - . | tar -C "$NEW" -xf -
python3 -m venv "$NEW/.venv"
say 'Устанавливаю Python-зависимости: pinned versions + SHA256, только wheels'
"$NEW/.venv/bin/pip" --isolated --disable-pip-version-check install --only-binary=:all: --require-hashes -r "$NEW/requirements.txt" -q
"$NEW/.venv/bin/python" -m compileall -q "$NEW/app"
chown -R root:ghostfleet "$NEW"
chmod -R go-w "$NEW"
find "$NEW" -type d -exec chmod g+rx {} +
find "$NEW" -type f -exec chmod g+r {} +
if ((UPGRADE)); then
  OLD="$(readlink -f "$BASE/current")"
  python3 - "$STATE/ghostfleet.sqlite3" <<'PY_LOCK'
import json,sqlite3,sys,time
with sqlite3.connect(sys.argv[1],timeout=15) as c:
    c.execute("BEGIN IMMEDIATE")
    if c.execute("SELECT COUNT(*) FROM jobs WHERE state IN ('queued','running')").fetchone()[0]:
        raise SystemExit('Wait for active jobs to finish before updating')
    existing=c.execute("SELECT value FROM settings WHERE key='maintenance_until'").fetchone()
    if existing and json.loads(existing[0])>time.time():raise SystemExit('Maintenance/backup already running')
    c.execute("INSERT INTO settings VALUES('maintenance_until',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (json.dumps(time.time()+3600),))
PY_LOCK
  LOCKED=1
  systemctl stop ghostfleet
  BACKUP="/var/backups/ghostfleet/pre-update-$(date +%Y%m%d%H%M%S)"
  install -m 0700 -d "$BACKUP"
  python3 - "$STATE/ghostfleet.sqlite3" "$BACKUP/ghostfleet.sqlite3" <<'PY'
import sqlite3,sys
with sqlite3.connect(sys.argv[1]) as src,sqlite3.connect(sys.argv[2]) as dst:src.backup(dst)
PY
  cp "$STATE/master.key" "$BACKUP/master.key"; cp "$ENVFILE" "$BACKUP/environment.env"
  chmod 0600 "$BACKUP"/*
  say "Локальная страховочная копия: $BACKUP (не заменяет зашифрованный off-site backup)"
else
  if ss -H -ltn "sport = :$PORT" | grep -q .; then die "Порт $PORT занят. Используйте --port другой_порт"; fi
  PUBLIC_URL="http://localhost:$PORT"
  [[ "$MODE" == tunnel ]] || PUBLIC_URL="https://$DOMAIN"
  ENV_CREATED=1
  cat >"$ENVFILE" <<EOF
GHOSTFLEET_DATA_DIR=$STATE
GHOSTFLEET_PORT=$PORT
GHOSTFLEET_PUBLIC_URL=$PUBLIC_URL
GHOSTFLEET_MODE=$MODE
GHOSTFLEET_ALLOWED_CIDRS=$ALLOWED
GHOSTFLEET_PRIVATE_NODE_CIDRS=
GHOSTFLEET_API_ALLOW_HOSTS=
GHOSTFLEET_ALLOW_API_HTTP=0
GHOSTFLEET_BIND_SESSION_IP=1
GHOSTFLEET_MONITOR_SECONDS=60
GHOSTFLEET_IDLE_SECONDS=1800
GHOSTFLEET_SESSION_SECONDS=28800
GHOSTFLEET_DEMO=0
EOF
  ENV_CREATED=1
  chown root:ghostfleet "$ENVFILE"; chmod 0640 "$ENVFILE"
fi
# Admin is local-only. No bootstrap password in .env, command arguments or logs.
(cd "$NEW" && runuser -u ghostfleet -- env -i HOME="$STATE" PATH=/usr/bin:/bin GHOSTFLEET_ENV="$ENVFILE" "$NEW/.venv/bin/python" -m app.cli init --username "$ADMIN")
(cd "$NEW" && runuser -u ghostfleet -- env -i HOME="$STATE" PATH=/usr/bin:/bin GHOSTFLEET_ENV="$ENVFILE" "$NEW/.venv/bin/python" -m app.cli check)
install -m 0644 "$NEW/deploy/ghostfleet.service" /etc/systemd/system/ghostfleet.service
ln -sfn "$NEW" "$BASE/current"; SWITCHED=1
cat >/usr/local/bin/ghostfleet <<'CLI'
#!/bin/sh
[ "$(id -u)" -eq 0 ] || { echo 'Use: sudo ghostfleet <command>' >&2; exit 1; }
cd /opt/ghostfleet/current || exit 1
exec runuser -u ghostfleet -- env -i HOME=/var/lib/ghostfleet PATH=/usr/bin:/bin GHOSTFLEET_ENV=/etc/ghostfleet/ghostfleet.env /opt/ghostfleet/current/.venv/bin/python -m app.cli "$@"
CLI
chmod 0755 /usr/local/bin/ghostfleet
systemctl daemon-reload
systemctl enable --now ghostfleet >/dev/null
systemctl restart ghostfleet
sleep 2
HOST="$(sed -n 's|^GHOSTFLEET_PUBLIC_URL=https\?://\([^/:]*\).*|\1|p' "$ENVFILE")"
curl -fsS --retry 10 --retry-connrefused --retry-delay 1 --retry-max-time 35 --max-time 3 -H "Host: ${HOST}" "http://127.0.0.1:${PORT}/healthz" >/dev/null || { journalctl -u ghostfleet -n 20 --no-pager >&2; die 'Панель не прошла health check'; }

if [[ "$MODE" != tunnel && $UPGRADE -eq 0 ]]; then
  say 'Настраиваю HTTPS. DNS панели должен указывать на этот сервер, TCP/80 открыт для ACME.'
  DEBIAN_FRONTEND=noninteractive apt-get install -y -qq nginx certbot >/dev/null
  [[ ! -e /etc/nginx/sites-enabled/ghostfleet && ! -e /etc/nginx/sites-available/ghostfleet && ! -e /etc/nginx/conf.d/ghostfleet-limit.conf ]] || die 'nginx ghostfleet уже существует; не перезаписываю'
  install -m 0755 -d /var/lib/ghostfleet-acme
  NGX_CREATED=1
  cat >/etc/nginx/sites-available/ghostfleet <<EOF
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN;
    location /.well-known/acme-challenge/ { root /var/lib/ghostfleet-acme; }
    location / { return 403; }
}
EOF
  ln -s /etc/nginx/sites-available/ghostfleet /etc/nginx/sites-enabled/ghostfleet
  nginx -t; systemctl enable --now nginx >/dev/null; systemctl reload nginx
  certbot certonly --non-interactive --agree-tos --email "$EMAIL" --webroot -w /var/lib/ghostfleet-acme -d "$DOMAIN"
  cat >/etc/nginx/conf.d/ghostfleet-limit.conf <<'NGX'
limit_req_zone $binary_remote_addr zone=ghostfleet_login:10m rate=5r/m;
NGX
  ALLOW_RULES=""
  if [[ "$MODE" == vpn || "$MODE" == allowlist ]]; then
    for net in ${ALLOWED//,/ }; do ALLOW_RULES+="    allow $net;"$'\n'; done
    ALLOW_RULES+='    deny all;'
  fi
  cat >/etc/nginx/sites-available/ghostfleet <<EOF
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN;
    location /.well-known/acme-challenge/ { root /var/lib/ghostfleet-acme; }
    location / { return 301 https://$DOMAIN\$request_uri; }
}
server {
    listen 443 ssl;
    listen [::]:443 ssl;
    server_name $DOMAIN;
    ssl_certificate /etc/letsencrypt/live/$DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$DOMAIN/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    server_tokens off;
    client_max_body_size 1m;
    client_body_timeout 15s;
    access_log /var/log/nginx/ghostfleet-access.log;
    error_log /var/log/nginx/ghostfleet-error.log warn;
$ALLOW_RULES
    location = /healthz { return 404; }
    location = /api/auth/login {
        limit_req zone=ghostfleet_login burst=5 nodelay;
        limit_req_status 429;
        proxy_pass http://127.0.0.1:$PORT;
        proxy_set_header Host \$host;
        proxy_set_header X-Forwarded-Proto https;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$remote_addr;
        proxy_read_timeout 75s;
    }
    location / {
        proxy_pass http://127.0.0.1:$PORT;
        proxy_set_header Host \$host;
        proxy_set_header X-Forwarded-Proto https;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$remote_addr;
        proxy_read_timeout 75s;
    }
}
EOF
  nginx -t; systemctl reload nginx
  install -m 0755 -d /etc/letsencrypt/renewal-hooks/deploy
  printf '#!/bin/sh\nnginx -t && systemctl reload nginx\n' >/etc/letsencrypt/renewal-hooks/deploy/ghostfleet-nginx
  chmod 0755 /etc/letsencrypt/renewal-hooks/deploy/ghostfleet-nginx
  systemctl enable --now certbot.timer >/dev/null 2>&1 || true
fi
python3 - "$REPO" "$REF" "$COMMIT" <<'PY'
import json,sys
from pathlib import Path
Path('/etc/ghostfleet/source.json').write_text(json.dumps({'repo':sys.argv[1],'ref':sys.argv[2],'commit':sys.argv[3]},indent=2))
PY
chmod 0640 /etc/ghostfleet/source.json; chown root:ghostfleet /etc/ghostfleet/source.json
COMMITTED=1
say 'Панель установлена. При первом входе обязательно подключите 2FA.'
if [[ "$MODE" == tunnel ]]; then
  cat <<EOF

На своём компьютере выполните (не на сервере):
  ssh -N -L $PORT:127.0.0.1:$PORT YOUR_SSH_USER@PANEL_IP

Откройте:
  http://localhost:$PORT

Не открывайте $PORT в firewall: сервис слушает только 127.0.0.1.
EOF
else say "Адрес панели: https://${DOMAIN:-$HOST}"; fi
cat <<EOF

Далее:
  1. Настройки → API Remnawave, IP Remnawave и GhostFleet, email нод.
  2. Проверить API, загрузить Internal Squads, выбрать группы, сохранить.
  3. Конфигурация → импортировать ваш JSON (с реальными параметрами RU_BRIDGE).
  4. Создать DNS-запись ноды и добавить IP LOGIN:PASSWORD + домен.

Сервис:    systemctl status ghostfleet
Журнал:    journalctl -u ghostfleet
Доступ:    sudo ghostfleet reset-password | reset-mfa | revoke-sessions
Ключ:      $STATE/master.key — не терять, не загружать в GitHub!
Памятка:   $BASE/current/docs/SECURITY.md
EOF
