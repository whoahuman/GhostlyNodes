# GhostFleet

**Приватная self-hosted панель для установки и мониторинга Remnanode в Remnawave 3.x.**

Вводите `IP LOGIN:PASSWORD`, домен ноды и страну → подтверждаете SSH fingerprint → фоновое задание устанавливает ноду вашим [Ghostly-Infrainstall](https://github.com/whoahuman/Ghostly-Infrainstall), готовит персональный Xray Config Profile, регистрирует ноду и, при настройке, добавляет Hosts / Internal Squads.

> **Сначала прочитайте [SECURITY.md](docs/SECURITY.md).** По умолчанию панель НЕ открыта в интернет: `127.0.0.1:8088` + SSH-туннель. Первое подключение требует настройки 2FA. Исходный JSON в репозитории содержит заглушки, а не ваши параметры RU_BRIDGE.

![Демонстрационный интерфейс GhostFleet — только синтетические данные](docs/images/dashboard.png)

## Что внутри

- Русскоязычный адаптивный интерфейс: обзор, ноды, задания, конфигурация, настройки, безопасность, аудит.
- Добавление по паролю или SSH-ключу; нестандартный SSH-порт, IPv6, sudo / NOPASSWD sudo.
- Проверка DNS и SSH host key **до отправки пароля**. Одноразовое подтверждение привязано к вашей сессии, IP и порту, действует 10 минут.
- Адаптер вашего Ghostly 1.2.2: TLS через HTTP-01, строгие правила firewall, fail2ban, Docker из официального подписанного APT-репозитория.
- Свой профиль для каждой управляемой ноды. Согласованная замена `pl-01-* → de-02-*`, `serviceName: pl-1 → de-2` и `routing.rules[].inboundTag`. Параметры RU bridge не заменяются по стране.
- TLS-цепочка, имя, срок и соответствие приватному ключу проверяются. Сертификат и ключ передаются в индивидуальный профиль inline; не нужно вручную переносить `/ssl` на сервер Remnawave.
- Hosts VLESS gRPC / Hysteria2 + присоединение новых inbound к выбранным Internal Squads без намеренного удаления старых назначений.
- Импорт текущего списка Remnawave, онлайн/офлайн/unknown, пользователи онлайн, учтённый трафик, сетевые скорости, CPU/RAM/disk для управляемых нод, история 7 дней, предупреждения TLS.
- Restart / enable / disable через API Remnawave. Подтверждаемое обновление образа, TLS sync, ограниченный просмотр логов, CSV без секретов.
- Фоновые задания, повтор после ошибки с новыми credentials, отмена ожидающего задания, журнал аудита, необязательные Telegram-уведомления.
- Пароль Argon2id, обязательная TOTP 2FA, одноразовые recovery-коды, защищённые сессии, CSRF + Origin + CSP, IP-ограничения.
- AES-256-GCM для токенов/приватного шаблона/ключей. SSH-пароль хранится только как временный зашифрованный payload задания и удаляется после завершения, ошибки или восстановления прерванного задания.
- Ограниченные ed25519 SSH-ключи для агента: `restrict`, `from=`, forced command. Они не дают обычную shell/SFTP/PTY/forwarding-сессию.
- Установщик панели, systemd-hardening, обновление с локальным snapshot и возвратом code release при неуспешном запуске, зашифрованный `age` backup / restore, CI.

## Требования и границы

Панель: отдельный VPS с **Ubuntu 22.04/24.04 или Debian 12/13**, systemd, Python ≥3.10. Рекомендуется 2 GB RAM, особенно при большом списке нод. Не устанавливайте контроллер на сервер ноды.

Ноды: Debian/Ubuntu, root или sudo, доступный SSH, свободный TCP/80 для HTTP-01, TCP/443 + UDP/443 для клиентов. Для каждой ноды нужен отдельный публичный FQDN с прямой DNS-записью. DNS создаётся вручную; Cloudflare proxy для нод выключен. В этой версии все A/AAAA имени должны соответствовать **одному введённому IP**: лишние AAAA при установке по IPv4 надо убрать.

Интеграция ориентирована на контракты **Remnawave 3.4.4**; default image — **Remnanode 3.4.1 по digest**. `3.x` — целевая ветка, не обещание совместимости со всеми прошлыми/будущими minor-версиями. Hysteria2 требует поддерживающего Xray core и совместимого клиента. Введённый IPv6 поддерживается в форме/SSH/API-политике, но для IPv6-only клиентского транспорта необходимо отдельно проверить listen-адреса исходного профиля и firewall/образ; исходный пример слушает `0.0.0.0`, рекомендуемый первый пилот — IPv4. Remnawave устанавливается отдельно; GhostFleet не заменяет его веб-интерфейс, базу пользователей и subscriptions.

**Важно:** код и UI проверены автоматическими тестами и локальными SSH/TLS-серверами; цикл API/установки проверен с имитацией Remnawave. Ваш настоящий сервер, ACME, firewall, Docker и боевой Remnawave в этой сессии не разворачивались. Это первая версия, которую следует сначала проверить на одном новом тестовом VPS. Подробный [отчёт](docs/TESTING.md).

## 1. Загрузить в свой GitHub

Распакуйте архив и загрузите **содержимое** папки проекта в свой репозиторий; `.github` и `.gitignore` тоже нужны. Не вкладывайте ещё один лишний уровень папок: `app/`, `deploy/`, `node/` должны лежать в корне GitHub.

```bash
git init
git add .
git commit -m "Initial GhostFleet source"
git branch -M main
git remote add origin https://github.com/YOUR_LOGIN/YOUR_REPO.git
git push -u origin main
git rev-parse HEAD
```

Запомните полученный 40-символьный commit SHA. Это пример для созданного вами пустого репозитория. Инструкции для private repo и обновлений: [GITHUB.md](docs/GITHUB.md).

## 2. Автоустановка панели — рекомендуемый закрытый режим

На **сервере панели**, заменив `YOUR_LOGIN`, `YOUR_REPO`, `COMMIT_SHA`:

```bash
curl --fail --show-error --location --proto '=https' \
  https://raw.githubusercontent.com/YOUR_LOGIN/YOUR_REPO/COMMIT_SHA/deploy/install.sh \
  -o ghostfleet-install.sh

# Посмотреть скрипт перед root-запуском
less ghostfleet-install.sh
sudo bash ghostfleet-install.sh \
  --repo https://github.com/YOUR_LOGIN/YOUR_REPO.git \
  --ref COMMIT_SHA --mode tunnel
```

Администратор по умолчанию `admin`. Установщик попросит пароль скрытым вводом, минимум 12 символов; используйте случайный пароль 20+ символов из менеджера. Пароля в `.env`, GitHub, командной строке или выводе установщика не будет.

Установка непосредственно из скачанных файлов без GitHub:

```bash
sudo bash deploy/install.sh --source "$(pwd)" --mode tunnel
```

На **своём компьютере**, а не на VPS:

```bash
ssh -o ExitOnForwardFailure=yes -N \
  -L 127.0.0.1:8088:127.0.0.1:8088 YOUR_SSH_USER@PANEL_IP
```

Откройте **`http://localhost:8088`**, именно этот origin. `8088` не нужно открывать в firewall. На VPS сервис слушает только loopback; SSH должен быть настроен по вашему ключу. Если локальный порт занят — установите другой через `--port`, URL и Origin должны совпадать.

Первый вход: логин/пароль, поле 2FA пока пустое → QR/секрет TOTP → подтвердить код → сохранить recovery-коды **вне VPS и GitHub**. Без этого API управления не доступен.

VPN/allowlist/HTTPS режимы: [DEPLOYMENT.md](docs/DEPLOYMENT.md). VPN установщик **не создаёт**.

## 3. Первичная настройка интеграции

В разделе **Настройки**:

1. HTTPS URL своего Remnawave, например `https://rw.example.com` (суффикс `/api` добавляется), API-токен без `Bearer`.
2. **Исходящие IP сервера Remnawave** — только им будет открыт `NODE_PORT` на нодах. Это не IP Cloudflare и не IP домена за reverse proxy.
3. **Исходящие IP сервера GhostFleet** — `from=` ограничение SSH-ключа агента. Это не адрес вашего ноутбука. Укажите реальные egress IP, лучше `/32` IPv4 и `/128` IPv6.
4. Email Let's Encrypt для нод, порт API по умолчанию `2222`, закреплённый образ.
5. Сохранить → **Проверить API** → **Загрузить Internal Squads** → выбрать необходимые группы → сохранить.
6. Оставить создание Hosts включённым, если новые точки должны появляться в subscriptions. Проверьте, что пользователь Remnawave состоит в выбранном Internal Squad и ваш шаблон подписок поддерживает оба протокола.
7. Необязательно: Telegram bot token / chat ID. GeoIP выключен по умолчанию; при включении внешний `ipwho.is` получает только IP ноды, не credentials.

Затем **Конфигурация**: вставьте свой JSON из исходного запроса или загрузите приватный файл, сохраните. В архиве сохранена структура VLESS gRPC + Hysteria2, YouTube → RU bridge, block private/bittorrent/YouTube QUIC и direct fallback, но параметры моста заменены `REPLACE_WITH_…`. С заглушками установка блокируется. Настоящий JSON хранится зашифрованно в state DB и не должен попадать в репозиторий.

Наконец на сервере рекомендуется зафиксировать hostname своего API в `/etc/ghostfleet/ghostfleet.env`:

```ini
GHOSTFLEET_API_ALLOW_HOSTS=rw.example.com
```

`sudo systemctl restart ghostfleet` — только когда нет активных заданий.

## 4. Добавить ноду

1. Создать DNS `de-01.nodes.example.com → NODE_IP`; дождаться распространения. Не использовать CDN proxy и чужие A/AAAA.
2. **Добавить ноду** → `NODE_IP root:PASSWORD` (пароль может содержать двоеточия), страна `DE`, домен.
3. **Проверить SSH** — только IP/порт/домен, credentials ещё не отправляются. Сверьте `SHA256:…` с ключом через консоль провайдера:

   ```bash
   ssh-keygen -l -E sha256 -f /etc/ssh/ssh_host_ed25519_key.pub
   ```

   Если показан другой алгоритм, сравните соответствующий `ssh_host_…_key.pub`. Не принимайте fingerprint вслепую.
4. Отметить подтверждение → **Развернуть ноду**. За ходом смотреть в **Заданиях**.
5. `Готово` означает завершение установки и регистрации. **Online** появляется только после подтверждения от Remnawave, не от успешного SSH или `docker compose up`.
6. Проверить оба протокола тестовым пользователем, TLS, subscriptions и ограничения API-порта до массового добавления нод.

Примеры ввода: `1.2.3.4 root:password:with:colons`, `1.2.3.4:2222 ubuntu:password`, `[2001:4860:…]:22 root:password`. Для key-only SSH раскройте расширенную форму и используйте свой административный ключ; ключ агента GhostFleet — ограниченный, не bootstrap-ключ.

## Обновление, бэкап и доступ

```bash
# После загрузки нового кода в свой GitHub
sudo bash /opt/ghostfleet/current/deploy/update.sh --ref NEW_COMMIT_SHA

# Сохранить зашифрованный архив (public age recipient с вашего компьютера)
sudo bash /opt/ghostfleet/current/deploy/backup.sh --recipient age1...

sudo ghostfleet check
sudo ghostfleet reset-password
sudo ghostfleet reset-mfa        # требует явного RESET-MFA
sudo ghostfleet revoke-sessions
sudo systemctl status ghostfleet
sudo journalctl -u ghostfleet
```

Backup и update отказываются запускаться при queued/running заданиях и на время операции закрывают изменения. Локальная pre-update копия не зашифрована; только root, не отправляйте её в облако/GitHub. [Backup / restore](docs/OPERATIONS.md) и [разбор проблем](docs/TROUBLESHOOTING.md).

## Разработка / демонстрация

```bash
python3 -m venv .venv
.venv/bin/pip --isolated install --only-binary=:all: --require-hashes -r requirements-dev.txt
.venv/bin/python -m pytest -q
.venv/bin/ruff check app node tests
.venv/bin/bandit -r app node -c pyproject.toml
.venv/bin/pip-audit --disable-pip --no-deps -r requirements.txt

GHOSTFLEET_DEMO=1 GHOSTFLEET_MODE=tunnel \
GHOSTFLEET_DATA_DIR="$PWD/.demo-state" GHOSTFLEET_PUBLIC_URL=http://localhost:3000 \
.venv/bin/python -m uvicorn app.main:create_app --factory --host 127.0.0.1 --port 3000
```

Демо синтетическое, публичный вход только в демонстрационном режиме, сеть/SSH/изменения отключены. Не используйте `GHOSTFLEET_DEMO=1` для production и не совмещайте demo-data с реальным state. **Один worker**, без `--reload` в production. Конфигурация процессов, pin-источники и API контракты: [ARCHITECTURE.md](docs/ARCHITECTURE.md).
