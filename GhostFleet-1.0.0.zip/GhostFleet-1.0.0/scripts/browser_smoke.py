"""Optional one-shot browser QA. Installs no production service and uses temporary local state.

Run with: python scripts/browser_smoke.py
Requires optional Playwright (not part of production runtime) and Chromium.
"""

from __future__ import annotations

import asyncio
import socket
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pyotp
import uvicorn
from playwright.async_api import async_playwright

from app.config import Config
from app.db import Database
from app.main import create_app
from app.security import PASSWORD_HASHER, SecretBox


async def smoke():
    with tempfile.TemporaryDirectory(prefix="ghostfleet-browser-qa-") as folder:
        sock = socket.socket()
        sock.bind(("127.0.0.1", 0))
        sock.listen(128)
        port = sock.getsockname()[1]
        origin = f"http://localhost:{port}"
        cfg = Config(
            data_dir=Path(folder) / "state", public_url=origin, mode="tunnel", trusted_hosts={"localhost"}
        )
        db = Database(cfg.db_path)
        db.init()
        SecretBox.create(cfg.key_path)
        password = "TEMPORARY QA PASSWORD ONLY 2026"
        db.execute(
            "INSERT INTO admins(id,username,password_hash) VALUES(1,?,?)",
            ("admin", PASSWORD_HASHER.hash(password)),
        )
        app = create_app(cfg, background=False)
        server = uvicorn.Server(uvicorn.Config(app, log_level="error", access_log=False))
        server_task = asyncio.create_task(server.serve(sockets=[sock]))

        async def ready():
            while not server.started:
                if server_task.done():
                    await server_task
                    raise RuntimeError("QA server stopped")
                await asyncio.sleep(0.02)

        await asyncio.wait_for(ready(), 10)
        try:
            async with async_playwright() as playwright:
                browser = await playwright.chromium.launch(headless=True, args=["--no-sandbox"])
                page = await browser.new_page(viewport={"width": 1440, "height": 1000})
                errors = []
                page.on("pageerror", lambda error: errors.append(str(error)))
                await page.goto(origin, wait_until="networkidle")
                await page.locator("#login-user").fill("admin")
                await page.locator("#login-password").fill(password)
                await page.locator('#login-form button[type="submit"]').click()
                await page.wait_for_selector(".otp-key")
                secret = (await page.locator(".otp-key").inner_text()).strip()
                await page.locator("#otp-confirm").fill(pyotp.TOTP(secret).now())
                await page.locator('#otp-form button[type="submit"]').click()
                await page.wait_for_selector('[data-action="finish-enrollment"]')
                assert await page.locator(".recovery-grid span").count() == 10
                await page.locator('[data-action="finish-enrollment"]').click()
                await page.wait_for_selector("h1")
                assert "Обзор" in await page.locator("h1").inner_text()
                await page.locator('.nav-item[data-page="settings"]').click()
                await page.wait_for_selector("#settings-form")
                assert await page.locator("#rw-token").input_value() == ""

                # A deliberately delayed template response must not overwrite a later page.
                async def delay(route):
                    await asyncio.sleep(0.5)
                    await route.continue_()

                await page.route("**/api/template", delay)
                await page.locator('.nav-item[data-page="template"]').click()
                await page.locator('.nav-item[data-page="security"]').click()
                await page.wait_for_selector("#password-form")
                await page.wait_for_timeout(900)
                assert await page.locator("#password-form").count() == 1
                assert await page.locator("#template-editor").count() == 0
                await page.unroute("**/api/template")
                await page.locator('[data-action="logout"]').click()
                await page.wait_for_selector("#login-form")
                response = await page.request.get(origin + "/api/auth/me")
                assert response.status == 401
                assert not errors, errors
                print(
                    "PASS: password login → local QR TOTP → recovery codes → protected dashboard → navigation-race guard → logout/session revocation. No page errors."
                )
                await browser.close()
        finally:
            server.should_exit = True
            await asyncio.wait_for(server_task, 10)
            await app.state.services.shutdown()
            sock.close()


if __name__ == "__main__":
    asyncio.run(smoke())
