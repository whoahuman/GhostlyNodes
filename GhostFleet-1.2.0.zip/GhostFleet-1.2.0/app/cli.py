from __future__ import annotations

import argparse
import getpass
import re
import sys
import uuid

from .config import Config
from .db import Database
from .security import PASSWORD_HASHER, SecretBox
from .template import DEFAULT_TEMPLATE


def new_password() -> str:
    first = getpass.getpass("Новый пароль администратора (12–256 символов): ")
    if not 12 <= len(first) <= 256:
        raise SystemExit("Пароль должен содержать 12–256 символов; лучше случайная парольная фраза")
    if first != getpass.getpass("Повторите пароль: "):
        raise SystemExit("Пароли не совпали")
    return first


def main() -> int:
    parser = argparse.ArgumentParser(description="GhostFleet: local, server-console administration")
    parser.add_argument(
        "command",
        choices=[
            "init",
            "reset-password",
            "reset-mfa",
            "revoke-sessions",
            "check",
            "rotate-key",
            "reset-access",
        ],
    )
    parser.add_argument("--username", default="admin")
    args = parser.parse_args()
    cfg = Config.from_env()
    db = Database(cfg.db_path)
    db.init()
    admin = (
        db.one("SELECT * FROM admins WHERE username=?", (args.username,))
        if args.command not in {"init", "check", "reset-access"}
        else db.one("SELECT * FROM admins WHERE id=1")
    )
    if args.command == "init":
        if admin:
            print("Администратор уже существует; init ничего не меняет")
            return 0
        if not re.fullmatch(r"[A-Za-z0-9_.-]{1,64}", args.username):
            raise SystemExit("Неверное имя пользователя")
        box = SecretBox.read(cfg.key_path) if cfg.key_path.exists() else SecretBox.create(cfg.key_path)
        password = new_password()
        db.execute(
            "INSERT INTO admins(id,username,password_hash) VALUES(1,?,?)",
            (args.username, PASSWORD_HASHER.hash(password)),
        )
        db.set("instance_id", db.get("instance_id", str(uuid.uuid4())))
        db.set("template", box.encrypt(DEFAULT_TEMPLATE.read_text(), "setting:template"))
        db.audit("admin.initialized", "Первый вход требует 2FA", actor=args.username, ip="console")
        print("Администратор создан. Подключите обязательную 2FA при первом входе.")
        return 0
    if not admin or not cfg.key_path.exists():
        raise SystemExit(
            "Сначала выполните init. Если master.key потерян, восстановите backup, а НЕ создавайте новый ключ."
        )
    if args.command == "reset-password":
        password = new_password()
        with db.transaction() as conn:
            conn.execute(
                "UPDATE admins SET password_hash=? WHERE id=?", (PASSWORD_HASHER.hash(password), admin["id"])
            )
            conn.execute("DELETE FROM sessions WHERE admin_id=?", (admin["id"],))
        db.audit("admin.password_reset", actor="console", ip="console")
        print("Пароль изменён, все сессии отозваны. 2FA сохранена.")
    elif args.command == "reset-mfa":
        if input("Сбросить 2FA и отозвать сессии? Напишите RESET-MFA: ") != "RESET-MFA":
            raise SystemExit("Отменено")
        with db.transaction() as conn:
            conn.execute(
                "UPDATE admins SET totp_secret=NULL,pending_totp=NULL,totp_counter=-1,recovery='[]' WHERE id=?",
                (admin["id"],),
            )
            conn.execute("DELETE FROM sessions WHERE admin_id=?", (admin["id"],))
        db.audit("admin.mfa_reset", actor="console", ip="console")
        print("2FA сброшена. При следующем входе подключите её заново.")
    elif args.command == "revoke-sessions":
        db.execute("DELETE FROM sessions WHERE admin_id=?", (admin["id"],))
        db.audit("admin.sessions_revoked", actor="console", ip="console")
        print("Все сессии отозваны")
    elif args.command == "reset-access":
        if (
            input(
                "Сбросить UI allowlist к env CIDR и восстановить активного владельца id=1? Напишите RESET-ACCESS: "
            )
            != "RESET-ACCESS"
        ):
            raise SystemExit("Отменено")
        with db.transaction() as conn:
            conn.execute("DELETE FROM settings WHERE key='access_policy'")
            conn.execute(
                "UPDATE admins SET active=1,role='owner',permissions=NULL,allowed_cidrs='[]' WHERE id=1"
            )
            conn.execute("DELETE FROM sessions")
        db.audit("access.console_reset", actor="console", ip="console")
        print("Вернулись к env CIDR; provider firewall/nginx outside gateway не изменены")
    elif args.command == "check":
        box = SecretBox.read(cfg.key_path)
        for row in db.query(
            "SELECT key,value FROM settings WHERE key IN ('template','api_token','telegram_token','cloudflare_token')"
        ):
            import json

            box.decrypt(json.loads(row["value"]), "setting:" + row["key"])
        print("База и master.key читаются; значения секретов не выводятся")
    elif args.command == "rotate-key":
        # Offline operation: updates every encrypted cell and the key as one maintenance task.
        raise SystemExit(
            "Автоматическая ротация master.key в v1 не поддерживается. Не заменяйте файл вручную: это сделает секреты нечитаемыми. При компрометации ротируйте API/SSH/TOTP и переинициализируйте чистую панель."
        )
    return 0


if __name__ == "__main__":
    sys.exit(main())
