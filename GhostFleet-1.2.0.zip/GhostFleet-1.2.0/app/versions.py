from __future__ import annotations

import json
import time
import uuid

from .template import validate_template


def save_version(db, box, config, name, actor):
    validate_template(config)
    key = str(uuid.uuid4())
    db.execute(
        "INSERT INTO config_versions VALUES(?,?,?,?,?)",
        (
            key,
            name,
            box.encrypt(json.dumps(config, ensure_ascii=False), "config-version:" + key),
            time.time(),
            actor,
        ),
    )
    db.execute(
        "DELETE FROM config_versions WHERE id IN (SELECT id FROM config_versions ORDER BY created DESC LIMIT -1 OFFSET 30)"
    )
    return key
