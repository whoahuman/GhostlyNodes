from __future__ import annotations

import json
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any

SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS admins (
 id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL, totp_secret TEXT, pending_totp TEXT,
 totp_counter INTEGER NOT NULL DEFAULT -1, recovery TEXT NOT NULL DEFAULT '[]',
 role TEXT NOT NULL DEFAULT 'owner', permissions TEXT, active INTEGER NOT NULL DEFAULT 1,
 allowed_cidrs TEXT NOT NULL DEFAULT '[]', created REAL NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS sessions (
 id TEXT PRIMARY KEY, csrf TEXT NOT NULL, scope TEXT NOT NULL,
 ip TEXT NOT NULL, ua TEXT NOT NULL, created REAL NOT NULL, touched REAL NOT NULL,
 admin_id INTEGER NOT NULL DEFAULT 1, elevated_at REAL NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS rate_limits (key TEXT PRIMARY KEY, start REAL NOT NULL, hits INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS challenges (
 id TEXT PRIMARY KEY, session_id TEXT NOT NULL, address TEXT NOT NULL,
 port INTEGER NOT NULL, host_key TEXT NOT NULL, fingerprint TEXT NOT NULL, expires REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS nodes (
 id TEXT PRIMARY KEY, remnawave_uuid TEXT UNIQUE, slug TEXT NOT NULL UNIQUE,
 name TEXT NOT NULL, country TEXT NOT NULL, ordinal INTEGER NOT NULL,
 address TEXT NOT NULL, domain TEXT NOT NULL DEFAULT '', node_port INTEGER NOT NULL DEFAULT 2222,
 ssh_port INTEGER NOT NULL DEFAULT 22, fingerprint TEXT, management_key TEXT,
 managed INTEGER NOT NULL DEFAULT 0, state TEXT NOT NULL DEFAULT 'imported',
 profile_uuid TEXT, host_uuids TEXT NOT NULL DEFAULT '[]', squad_uuids TEXT NOT NULL DEFAULT '[]',
 inbound_uuids TEXT NOT NULL DEFAULT '[]', config_cipher TEXT,
 rw_data TEXT NOT NULL DEFAULT '{}', host_metrics TEXT NOT NULL DEFAULT '{}',
 cert_hash TEXT, cert_expiry REAL, last_cert_sync REAL, last_host_poll REAL,
 notes TEXT NOT NULL DEFAULT '', created REAL NOT NULL, updated REAL NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS managed_address ON nodes(address) WHERE managed=1;
CREATE TABLE IF NOT EXISTS jobs (
 id TEXT PRIMARY KEY, node_id TEXT NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,
 kind TEXT NOT NULL, state TEXT NOT NULL, step INTEGER NOT NULL DEFAULT 0,
 message TEXT NOT NULL, logs TEXT NOT NULL DEFAULT '[]', payload_cipher TEXT,
 created REAL NOT NULL, updated REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS samples (
 id INTEGER PRIMARY KEY AUTOINCREMENT, node_id TEXT NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,
 ts REAL NOT NULL, connected INTEGER, users INTEGER, rx REAL, tx REAL,
 memory_pct REAL, load REAL, latency REAL
);
CREATE INDEX IF NOT EXISTS samples_time ON samples(ts);
CREATE INDEX IF NOT EXISTS samples_node_time ON samples(node_id,ts);
CREATE TABLE IF NOT EXISTS audit (
 id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL,
 event TEXT NOT NULL, actor TEXT NOT NULL, ip TEXT NOT NULL, detail TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS alerts (
 key TEXT PRIMARY KEY, failures INTEGER NOT NULL DEFAULT 0,
 notified INTEGER NOT NULL DEFAULT 0, updated REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS service_accounts (
 id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE, token_hash TEXT NOT NULL UNIQUE,
 token_prefix TEXT NOT NULL, scopes TEXT NOT NULL, allowed_cidrs TEXT NOT NULL,
 expires REAL NOT NULL, active INTEGER NOT NULL DEFAULT 1, created REAL NOT NULL,
 created_by INTEGER NOT NULL, last_used REAL
);
CREATE TABLE IF NOT EXISTS user_cache (uuid TEXT PRIMARY KEY, data TEXT NOT NULL, seen REAL NOT NULL);
CREATE TABLE IF NOT EXISTS user_observations (user_uuid TEXT PRIMARY KEY, count INTEGER NOT NULL DEFAULT 0,
 fingerprints TEXT NOT NULL DEFAULT '[]', first_seen REAL NOT NULL, last_seen REAL NOT NULL,
 consecutive INTEGER NOT NULL DEFAULT 0, flagged INTEGER NOT NULL DEFAULT 0, notified INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS install_profiles (id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE,
 data TEXT NOT NULL, created REAL NOT NULL, updated REAL NOT NULL);
CREATE TABLE IF NOT EXISTS config_versions (id TEXT PRIMARY KEY, name TEXT NOT NULL, cipher TEXT NOT NULL,
 created REAL NOT NULL, actor TEXT NOT NULL);
"""


class Database:
    def __init__(self, path: Path):
        self.path = path

    @contextmanager
    def transaction(self):
        conn = sqlite3.connect(self.path, timeout=15)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=15000")
        conn.execute("PRAGMA secure_delete=ON")
        try:
            conn.execute("BEGIN IMMEDIATE")
            yield conn
            conn.commit()
        except BaseException:
            conn.rollback()
            raise
        finally:
            conn.close()

    def init(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        with sqlite3.connect(self.path) as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA secure_delete=ON")
            has_meta = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='meta'"
            ).fetchone()
            version = (
                conn.execute("SELECT value FROM meta WHERE key='schema'").fetchone() if has_meta else None
            )
            if version and version[0] not in {"1", "2"}:
                raise RuntimeError(
                    "Unsupported database schema. Restore a compatible backup, never overwrite the master key"
                )
            if version and version[0] == "1":
                # Atomic additive migration. Legacy ciphertext/AAD and node IDs remain unchanged.
                conn.executescript(
                    "".join(
                        (
                            # Both migration text and SCHEMA are source constants; no user-controlled SQL.
                            """BEGIN IMMEDIATE;
                ALTER TABLE admins RENAME TO admins_v1;
                CREATE TABLE admins (id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE,
                  password_hash TEXT NOT NULL, totp_secret TEXT, pending_totp TEXT,
                  totp_counter INTEGER NOT NULL DEFAULT -1, recovery TEXT NOT NULL DEFAULT '[]',
                  role TEXT NOT NULL DEFAULT 'owner', permissions TEXT, active INTEGER NOT NULL DEFAULT 1,
                  allowed_cidrs TEXT NOT NULL DEFAULT '[]', created REAL NOT NULL DEFAULT 0);
                INSERT INTO admins(id,username,password_hash,totp_secret,pending_totp,totp_counter,recovery)
                  SELECT id,username,password_hash,totp_secret,pending_totp,totp_counter,recovery FROM admins_v1;
                DROP TABLE admins_v1;
                ALTER TABLE sessions ADD COLUMN admin_id INTEGER NOT NULL DEFAULT 1;
                ALTER TABLE sessions ADD COLUMN elevated_at REAL NOT NULL DEFAULT 0;
                DELETE FROM sessions;
                DELETE FROM challenges;
                """,
                            SCHEMA,
                            "UPDATE meta SET value='2' WHERE key='schema'; COMMIT;",
                        )
                    )
                )
            else:
                conn.executescript(SCHEMA)
                conn.execute("INSERT OR IGNORE INTO meta VALUES ('schema','2')")
            columns = {row[1] for row in conn.execute("PRAGMA table_info(nodes)")}
            for name, statement in {
                "install_profile": "ALTER TABLE nodes ADD COLUMN install_profile TEXT",
                "tuning": "ALTER TABLE nodes ADD COLUMN tuning TEXT NOT NULL DEFAULT '{}'",
                "agent_version": "ALTER TABLE nodes ADD COLUMN agent_version TEXT",
            }.items():
                if name not in columns:
                    conn.execute(statement)
        self.path.chmod(0o600)

    def query(self, sql: str, params: tuple = ()) -> list[dict]:
        with self.transaction() as conn:
            return [dict(r) for r in conn.execute(sql, params).fetchall()]

    def one(self, sql: str, params: tuple = ()) -> dict | None:
        rows = self.query(sql, params)
        return rows[0] if rows else None

    def execute(self, sql: str, params: tuple = ()) -> None:
        with self.transaction() as conn:
            conn.execute(sql, params)

    def get(self, key: str, default: Any = None) -> Any:
        row = self.one("SELECT value FROM settings WHERE key=?", (key,))
        return json.loads(row["value"]) if row else default

    def set(self, key: str, value: Any) -> None:
        self.execute(
            "INSERT INTO settings VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, json.dumps(value, ensure_ascii=False)),
        )

    def audit(self, event: str, detail: str = "", actor: str = "system", ip: str = "") -> None:
        self.execute(
            "INSERT INTO audit(ts,event,actor,ip,detail) VALUES(?,?,?,?,?)",
            (time.time(), event[:80], actor[:80], ip[:80], detail[:2000]),
        )

    def hit(self, key: str, limit: int, window: int) -> bool:
        now = time.time()
        with self.transaction() as conn:
            row = conn.execute("SELECT start,hits FROM rate_limits WHERE key=?", (key,)).fetchone()
            if not row or now - row["start"] >= window:
                conn.execute(
                    "INSERT INTO rate_limits VALUES(?,?,1) ON CONFLICT(key) DO UPDATE SET start=excluded.start,hits=1",
                    (key, now),
                )
                return True
            if row["hits"] >= limit:
                return False
            conn.execute("UPDATE rate_limits SET hits=hits+1 WHERE key=?", (key,))
            return True

    def job_progress(self, job_id: str, step: int, message: str, state: str | None = None) -> None:
        with self.transaction() as conn:
            row = conn.execute("SELECT logs,state FROM jobs WHERE id=?", (job_id,)).fetchone()
            if not row:
                return
            logs = json.loads(row["logs"])
            logs.append({"ts": time.time(), "step": step, "message": message[:1000]})
            conn.execute(
                "UPDATE jobs SET step=?,message=?,state=?,logs=?,updated=? WHERE id=?",
                (
                    step,
                    message[:1000],
                    state or row["state"],
                    json.dumps(logs[-80:], ensure_ascii=False),
                    time.time(),
                    job_id,
                ),
            )

    def recover_jobs(self) -> None:
        with self.transaction() as conn:
            conn.execute(
                "UPDATE nodes SET state='failed' WHERE id IN (SELECT node_id FROM jobs WHERE state IN ('queued','running'))"
            )
            conn.execute(
                "UPDATE jobs SET state='interrupted', payload_cipher=NULL, message='Панель перезапущена. Проверьте состояние сервера и повторите установку с SSH-реквизитами.',updated=? WHERE state IN ('queued','running')",
                (time.time(),),
            )

    def prune(self) -> None:
        now = time.time()
        with self.transaction() as conn:
            conn.execute("DELETE FROM samples WHERE ts<?", (now - 30 * 86400,))
            conn.execute("DELETE FROM audit WHERE ts<?", (now - 90 * 86400,))
            conn.execute("DELETE FROM challenges WHERE expires<?", (now,))
            conn.execute("DELETE FROM rate_limits WHERE start<?", (now - 86400,))
            conn.execute("DELETE FROM sessions WHERE created<?", (now - 86400,))
            conn.execute(
                "DELETE FROM jobs WHERE updated<? AND state NOT IN ('queued','running')", (now - 30 * 86400,)
            )
