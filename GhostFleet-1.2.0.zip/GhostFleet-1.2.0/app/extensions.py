from __future__ import annotations

import hashlib
import hmac
import ipaddress
import json
import re
import secrets
import sqlite3
import time
import uuid

from fastapi import APIRouter, HTTPException, Query, Request, Response

from .cloudflare import Cloudflare
from .extensions_models import (
    AccessPolicy,
    CloudSettings,
    DnsRecord,
    Elevate,
    InstallProfile,
    NodeTune,
    NotificationRules,
    ServiceCreate,
    SharingPolicy,
    StaffCreate,
    StaffEdit,
    UserOperation,
    VersionSave,
)
from .notify import notify
from .rbac import ALL, ROLES, SERVICE_SCOPES, permissions
from .remnawave import RemnawaveError
from .security import (
    authorize,
    check_password,
    client_ip,
    consume_second_factor,
    hash_password,
    ip_allowed,
    require_recent,
)
from .ssh import agent_call, validate_target
from .template import validate_template
from .users import masked_ip, observe_sharing, safe_user
from .versions import save_version


def state(request):
    a = request.app.state
    return a.db, a.box, a.cfg, a.services


def audit(request, principal, event, detail=""):
    request.app.state.db.audit(event, detail, principal["username"], client_ip(request))


def staff_public(row):
    return {
        "id": row["id"],
        "username": row["username"],
        "role": row["role"],
        "active": bool(row["active"]),
        "permissions": permissions(
            row["role"], json.loads(row["permissions"]) if row["permissions"] is not None else None
        ),
        "custom": row["permissions"] is not None,
        "allowed_cidrs": json.loads(row["allowed_cidrs"]),
        "totp_enabled": bool(row["totp_secret"]),
        "created": row["created"],
    }


def user_identity(value):
    if re.fullmatch(r"[1-9][0-9]{0,15}", value):
        return value
    try:
        return str(uuid.UUID(value))
    except ValueError as e:
        raise HTTPException(422, "Неверный user ID") from e


def extension_router():
    r = APIRouter()

    @r.post("/api/auth/elevate")
    async def elevate(body: Elevate, request: Request):
        principal = authorize(request)
        db, box, _, _ = state(request)
        if not db.hit("elevate:" + principal["id"], 5, 900):
            raise HTTPException(429, "Повторите подтверждение позже")
        admin = db.one("SELECT * FROM admins WHERE id=?", (principal["admin_id"],))
        if not await check_password(admin["password_hash"], body.password.get_secret_value()):
            raise HTTPException(401, "Неверные реквизиты")
        with db.transaction() as c:
            current = dict(c.execute("SELECT * FROM admins WHERE id=?", (admin["id"],)).fetchone())
            if current["password_hash"] != admin["password_hash"] or not consume_second_factor(
                c, current, box, body.code
            ):
                raise HTTPException(401, "Неверный/повторный 2FA-код")
            c.execute("UPDATE sessions SET elevated_at=? WHERE id=?", (time.time(), principal["id"]))
        audit(request, principal, "auth.elevated")
        return {"ok": True, "seconds": 300}

    @r.get("/api/staff")
    async def staff_get(request: Request):
        authorize(request)
        db, _, cfg, _ = state(request)
        if cfg.demo:
            return {
                "accounts": [
                    {
                        "id": 1,
                        "username": "owner",
                        "role": "owner",
                        "permissions": sorted(ALL),
                        "active": True,
                        "totp_enabled": True,
                        "allowed_cidrs": [],
                        "custom": False,
                        "created": time.time() - 86400 * 42,
                    },
                    {
                        "id": 2,
                        "username": "ops.team",
                        "role": "operator",
                        "permissions": permissions("operator"),
                        "active": True,
                        "totp_enabled": True,
                        "allowed_cidrs": ["198.51.100.0/24"],
                        "custom": False,
                        "created": time.time() - 86400 * 9,
                    },
                ],
                "roles": {k: sorted(v) for k, v in ROLES.items()},
                "permissions": sorted(ALL),
            }
        return {
            "accounts": [staff_public(a) for a in db.query("SELECT * FROM admins ORDER BY id")],
            "roles": {k: sorted(v) for k, v in ROLES.items()},
            "permissions": sorted(ALL),
        }

    @r.post("/api/staff", status_code=201)
    async def staff_create(body: StaffCreate, request: Request):
        p = authorize(request)
        require_recent(p)
        db, _, _, _ = state(request)
        hashed = await hash_password(body.password.get_secret_value())
        try:
            db.execute(
                "INSERT INTO admins(username,password_hash,role,permissions,allowed_cidrs,created) VALUES(?,?,?,?,?,?)",
                (
                    body.username,
                    hashed,
                    body.role,
                    json.dumps(body.permissions) if body.permissions is not None else None,
                    json.dumps(body.allowed_cidrs),
                    time.time(),
                ),
            )
        except sqlite3.IntegrityError as e:
            raise HTTPException(409, "Логин уже существует") from e
        audit(request, p, "staff.created", body.username + " / " + body.role)
        return staff_public(db.one("SELECT * FROM admins WHERE username=?", (body.username,)))

    @r.patch("/api/staff/{admin_id}")
    async def staff_edit(admin_id: int, body: StaffEdit, request: Request):
        p = authorize(request)
        require_recent(p)
        db, _, _, _ = state(request)
        with db.transaction() as c:
            old = c.execute("SELECT * FROM admins WHERE id=?", (admin_id,)).fetchone()
            if not old:
                raise HTTPException(404, "Аккаунт не найден")
            if admin_id == p["admin_id"] and (not body.active or body.role != "owner"):
                raise HTTPException(409, "Нельзя отключить/понизить текущего владельца через свою сессию")
            if admin_id == p["admin_id"] and not ip_allowed(client_ip(request), body.allowed_cidrs):
                raise HTTPException(409, "Ваш IP отсутствует в новом индивидуальном allowlist")
            owners = c.execute("SELECT COUNT(*) FROM admins WHERE active=1 AND role='owner'").fetchone()[0]
            if (
                old["role"] == "owner"
                and old["active"]
                and owners <= 1
                and (body.role != "owner" or not body.active)
            ):
                raise HTTPException(409, "Последний владелец должен остаться активным")
            c.execute(
                "UPDATE admins SET role=?,permissions=?,active=?,allowed_cidrs=? WHERE id=?",
                (
                    body.role,
                    json.dumps(body.permissions) if body.permissions is not None else None,
                    int(body.active),
                    json.dumps(body.allowed_cidrs),
                    admin_id,
                ),
            )
            # Stale credentials/permissions never survive an account edit.
            c.execute("DELETE FROM sessions WHERE admin_id=?", (admin_id,))
        audit(request, p, "staff.updated", old["username"] + " / " + body.role)
        return {"ok": True, "sessions_revoked": True}

    @r.post("/api/staff/{admin_id}/revoke-sessions")
    async def staff_revoke(admin_id: int, request: Request):
        p = authorize(request)
        require_recent(p)
        db, _, _, _ = state(request)
        db.execute("DELETE FROM sessions WHERE admin_id=?", (admin_id,))
        audit(request, p, "staff.sessions_revoked", str(admin_id))
        return {"ok": True}

    @r.get("/api/service-accounts")
    async def service_get(request: Request):
        authorize(request)
        db, _, cfg, _ = state(request)
        rows = db.query(
            "SELECT id,name,token_prefix,scopes,allowed_cidrs,expires,active,created,last_used FROM service_accounts ORDER BY created DESC"
        )
        for row in rows:
            row.update(scopes=json.loads(row["scopes"]), allowed_cidrs=json.loads(row["allowed_cidrs"]))
        return {"accounts": rows, "scopes": sorted(SERVICE_SCOPES), "demo": cfg.demo}

    @r.post("/api/service-accounts", status_code=201)
    async def service_create(body: ServiceCreate, request: Request):
        p = authorize(request)
        require_recent(p)
        db, _, _, _ = state(request)
        key = str(uuid.uuid4())
        token = "gfk_" + secrets.token_urlsafe(32)
        try:
            db.execute(
                "INSERT INTO service_accounts(id,name,token_hash,token_prefix,scopes,allowed_cidrs,expires,created,created_by) VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    key,
                    body.name,
                    hashlib.sha256(token.encode()).hexdigest(),
                    token[:12],
                    json.dumps(body.scopes),
                    json.dumps(body.allowed_cidrs),
                    time.time() + body.days * 86400,
                    time.time(),
                    p["admin_id"],
                ),
            )
        except sqlite3.IntegrityError as e:
            raise HTTPException(409, "Имя сервисного аккаунта занято") from e
        audit(request, p, "service.created", body.name + " / " + ",".join(body.scopes))
        return {
            "id": key,
            "name": body.name,
            "token": token,
            "show_once": True,
            "expires": time.time() + body.days * 86400,
        }

    @r.delete("/api/service-accounts/{account_id}")
    async def service_delete(account_id: str, request: Request):
        p = authorize(request)
        require_recent(p)
        db, _, _, _ = state(request)
        db.execute("UPDATE service_accounts SET active=0 WHERE id=?", (account_id,))
        audit(request, p, "service.revoked", account_id)
        return {"ok": True}

    @r.get("/api/access")
    async def access_get(request: Request):
        p = authorize(request)
        db, _, cfg, _ = state(request)
        current = db.get("access_policy", {})
        return {
            "mode": cfg.mode,
            "cidrs": current.get("cidrs", [str(n) for n in cfg.allowed_cidrs]),
            "enabled": current.get("enabled", False),
            "gateway_ready": bool(getattr(cfg, "gateway_token", "")),
            "peer_ip": client_ip(request),
            "demo": cfg.demo,
            "can_write": "access.write" in p["permissions"],
            "note": "Только allowlist приложения/nginx. Не меняет provider firewall, VPN и SSH.",
        }

    @r.put("/api/access")
    async def access_put(body: AccessPolicy, request: Request):
        p = authorize(request)
        require_recent(p)
        db, _, cfg, _ = state(request)
        if cfg.mode not in {"allowlist", "vpn"}:
            raise HTTPException(
                409, "Изменение глобального IP-доступа работает только в HTTPS allowlist/VPN режиме"
            )
        if not getattr(cfg, "gateway_token", ""):
            raise HTTPException(
                409,
                "Сначала обновите nginx gateway через deploy/access-gateway.sh. Старый статический nginx allowlist нельзя обойти из UI",
            )
        peer = client_ip(request)
        if not ipaddress.ip_address(peer).is_loopback and not ip_allowed(peer, body.cidrs):
            raise HTTPException(409, "Добавьте текущий IP: нельзя лишить себя доступа")
        db.set("access_policy", {"enabled": True, "cidrs": body.cidrs, "updated": time.time()})
        audit(request, p, "access.updated", ",".join(body.cidrs))
        return {"ok": True, "provider_firewall_changed": False}

    @r.get("/internal/access-check")
    async def edge_check(request: Request):
        db, _, cfg, _ = state(request)
        token = getattr(cfg, "gateway_token", "")
        try:
            is_loopback = ipaddress.ip_address(client_ip(request)).is_loopback
        except ValueError:
            is_loopback = False
        if (
            not token
            or not is_loopback
            or not hmac.compare_digest(request.headers.get("x-ghostfleet-gateway", ""), token)
        ):
            raise HTTPException(403, "Internal gateway only")
        policy = db.get("access_policy", {})
        cidrs = policy.get("cidrs") if policy.get("enabled") else [str(n) for n in cfg.allowed_cidrs]
        peer = request.headers.get("x-ghostfleet-peer", "")
        if not cidrs or not ip_allowed(peer, cidrs):
            raise HTTPException(403, "IP not admitted")
        return Response(status_code=204)

    def cloud(request):
        db, box, cfg, _ = state(request)
        if cfg.demo:
            raise HTTPException(403, "Демо не подключается к Cloudflare")
        encrypted = db.get("cloudflare_token")
        if not encrypted:
            raise HTTPException(409, "Сначала сохраните ограниченный Cloudflare API token")
        return Cloudflare(box.decrypt(encrypted, "setting:cloudflare_token"))

    def zone_allowed(request, zone):
        allowed = request.app.state.db.get("cloudflare_settings", {}).get("allowed_zones", [])
        if not allowed or zone not in allowed:
            raise HTTPException(403, "Zone ID не разрешён владельцем панели")

    @r.get("/api/cloudflare/settings")
    async def cloud_settings_get(request: Request):
        authorize(request)
        db, _, _, _ = state(request)
        return {
            **db.get("cloudflare_settings", {"allowed_zones": []}),
            "configured": bool(db.get("cloudflare_token")),
        }

    @r.put("/api/cloudflare/settings")
    async def cloud_settings_put(body: CloudSettings, request: Request):
        p = authorize(request)
        require_recent(p)
        db, box, _, _ = state(request)
        with db.transaction() as c:
            if body.token:
                value = body.token.get_secret_value().strip()
                if re.search(r"\s", value):
                    raise HTTPException(400, "Токен без пробелов/Bearer")
                c.execute(
                    "INSERT INTO settings VALUES('cloudflare_token',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (json.dumps(box.encrypt(value, "setting:cloudflare_token")),),
                )
            if body.clear:
                c.execute("DELETE FROM settings WHERE key='cloudflare_token'")
            c.execute(
                "INSERT INTO settings VALUES('cloudflare_settings',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (json.dumps({"allowed_zones": body.allowed_zones}),),
            )
        audit(request, p, "cloudflare.settings", "Токен/зоны обновлены; значение не выводится")
        return {"ok": True, "configured": bool(db.get("cloudflare_token"))}

    @r.get("/api/cloudflare/zones")
    async def cloud_zones(request: Request):
        p = authorize(request)
        db, _, cfg, _ = state(request)
        if cfg.demo:
            return [{"id": "a" * 32, "name": "nodes.example.com", "status": "active"}]
        allzones = await cloud(request).zones()
        allowed = db.get("cloudflare_settings", {}).get("allowed_zones", [])
        return allzones if "dns.manage" in p["permissions"] else [z for z in allzones if z["id"] in allowed]

    @r.get("/api/cloudflare/records")
    async def cloud_records(request: Request, zone_id: str = Query(pattern=r"^[a-f0-9]{32}$")):
        authorize(request)
        _, _, cfg, _ = state(request)
        if cfg.demo:
            return [
                {
                    "id": "b" * 32,
                    "type": "A",
                    "name": "de-01.nodes.example.com",
                    "content": "203.0.113.10",
                    "ttl": 300,
                    "proxied": False,
                }
            ]
        zone_allowed(request, zone_id)
        return await cloud(request).records(zone_id)

    @r.post("/api/cloudflare/records")
    async def cloud_record_put(body: DnsRecord, request: Request):
        p = authorize(request)
        _, _, cfg, _ = state(request)
        zone_allowed(request, body.zone_id)
        validate_target(body.address, cfg)
        result = await cloud(request).upsert(body.zone_id, body.name, body.address, body.ttl, body.replace)
        audit(request, p, "dns.saved", body.name + " → " + body.address + " / DNS-only")
        return result

    @r.get("/api/users")
    async def users_list(
        request: Request,
        start: int = Query(default=0, ge=0, le=10000000),
        size: int = Query(default=25, ge=1, le=100),
        search: str = Query(default="", max_length=64),
    ):
        p = authorize(request)
        db, _, cfg, services = state(request)
        if not db.hit("users-list:" + p["id"], 30, 60):
            raise HTTPException(429, "Слишком частые запросы пользователей")
        if cfg.demo:
            from .demo import demo_users

            rows = demo_users()
            rows = [u for u in rows if search.lower() in u["username"].lower()]
            return {"users": rows[start : start + size], "total": len(rows), "online": True, "demo": True}
        try:
            response = await services.api().users(start, size, search)
            rows = [safe_user(u, time.time()) for u in response.get("users", [])]
            for user in rows:
                db.execute(
                    "INSERT INTO user_cache VALUES(?,?,?) ON CONFLICT(uuid) DO UPDATE SET data=excluded.data,seen=excluded.seen",
                    (user["identity"], json.dumps(user), time.time()),
                )
            meta = {"online": True, "last_success": time.time(), "total": response.get("total", len(rows))}
            db.set("users_state", meta)
            for user in rows:
                observation = db.one(
                    "SELECT count,flagged,last_seen FROM user_observations WHERE user_uuid=?",
                    (user["identity"],),
                )
                user["observation"] = observation
            return {"users": rows, "total": meta["total"], "online": True, "demo": False}
        except RemnawaveError:
            # No false active/disabled claims during an upstream outage.
            rows = db.query("SELECT data FROM user_cache ORDER BY seen DESC LIMIT ? OFFSET ?", (size, start))
            fallback = [{**json.loads(x["data"]), "stale": True} for x in rows]
            if search:
                fallback = [u for u in fallback if search.lower() in u["username"].lower()]
            db.set("users_state", {**db.get("users_state", {}), "online": False})
            return {
                "users": fallback,
                "total": db.get("users_state", {}).get("total", len(fallback)),
                "online": False,
                "error": "API пользователей недоступен. Показана последняя известная выборка, не текущий статус.",
            }

    @r.get("/api/users/policy")
    async def sharing_get(request: Request):
        authorize(request)
        db, _, cfg, _ = state(request)
        policy = db.get("sharing_policy", SharingPolicy().model_dump())
        signals = []
        for o in db.query(
            "SELECT * FROM user_observations WHERE flagged=1 ORDER BY last_seen DESC LIMIT 100"
        ):
            c = db.one("SELECT data FROM user_cache WHERE uuid=?", (o["user_uuid"],))
            signals.append(
                {
                    "identity": o["user_uuid"],
                    "username": json.loads(c["data"])["username"] if c else o["user_uuid"],
                    "devices": o["count"],
                    "last_seen": o["last_seen"],
                    "reason": "Превышен наблюдательный порог зарегистрированных HWID",
                    "not_proof": True,
                }
            )
        if cfg.demo:
            signals = [
                {
                    "identity": "1007",
                    "username": "alex.mobile",
                    "devices": 7,
                    "last_seen": time.time() - 80,
                    "reason": "7 зарегистрированных HWID, порог 3. Нужно проверить личные устройства.",
                    "not_proof": True,
                },
                {
                    "identity": "1011",
                    "username": "guest.team",
                    "devices": 9,
                    "last_seen": time.time() - 100,
                    "reason": "9 зарегистрированных HWID. Возможное семейное/командное использование.",
                    "not_proof": True,
                },
            ]
            policy = {**policy, "enabled": True}
            state_ = {
                "online": True,
                "supported": True,
                "mode": "observe",
                "last_success": time.time() - 60,
                "inspected": 100,
                "partial": True,
                "coverage_limit": 100,
            }
        else:
            state_ = db.get("sharing_state", {})
        return {"policy": policy, "state": state_, "signals": signals, "automatic_bans": False}

    @r.put("/api/users/policy")
    async def sharing_put(body: SharingPolicy, request: Request):
        p = authorize(request)
        db, _, _, _ = state(request)
        db.set("sharing_policy", body.model_dump())
        audit(request, p, "sharing.policy", "Observe only; no automatic disable/delete")
        return {"ok": True, "mode": "observe", "automatic_bans": False}

    @r.post("/api/users/observe")
    async def sharing_force(request: Request):
        p = authorize(request)
        db, _, _, services = state(request)
        if not db.hit("observe-manual:" + p["id"], 2, 300):
            raise HTTPException(429, "Повтор через 5 минут")
        return await observe_sharing(services, True)

    @r.get("/api/users/{user_id}/devices")
    async def devices_get(user_id: str, request: Request):
        authorize(request)
        db, box, cfg, services = state(request)
        key = user_identity(user_id)
        if cfg.demo:
            return {
                "total": 3,
                "devices": [
                    {
                        "fingerprint": "dev_demo_" + str(i),
                        "platform": v,
                        "model": "Личное устройство",
                        "ip_network": "198.51.100.0/24",
                        "updated_at": "2026-10-06T10:00:00Z",
                    }
                    for i, v in enumerate(["iOS", "Windows", "Android"])
                ],
                "registered_not_concurrent": True,
            }
        response = await services.api().user_devices(key)
        result = []
        for d in response.get("devices", [])[:100]:
            fp = box.digest(str(d.get("hwid", "")), "hwid:" + key)[:16]
            result.append(
                {
                    "fingerprint": fp,
                    "platform": str(d.get("platform") or "")[:40],
                    "model": str(d.get("deviceModel") or "")[:80],
                    "ip_network": masked_ip(d.get("requestIp")),
                    "updated_at": str(d.get("updatedAt") or "")[:40],
                }
            )
        return {
            "total": response.get("total", len(result)),
            "devices": result,
            "registered_not_concurrent": True,
        }

    @r.post("/api/users/{user_id}/actions")
    async def user_action(user_id: str, body: UserOperation, request: Request):
        p = authorize(request)
        db, _, _, services = state(request)
        key = user_identity(user_id)
        if not db.hit("user-action:" + p["id"], 12, 60):
            raise HTTPException(429, "Лимит операций")
        user = await services.api().user(key)
        if body.confirm != user.get("username"):
            raise HTTPException(400, "Для подтверждения введите username пользователя")
        if body.action == "hwid-limit":
            if body.device_limit is None:
                raise HTTPException(422, "Нужен device_limit")
            result = await services.api().user_limit(user, body.device_limit)
        else:
            result = await services.api().user_action(key, body.action)
        audit(request, p, "user.action", body.confirm + " / " + body.action)
        return {"ok": True, "user": safe_user(result, time.time()), "manual": True}

    @r.get("/api/install-profiles")
    async def profiles_get(request: Request):
        authorize(request)
        db, _, _, _ = state(request)
        rows = db.query("SELECT * FROM install_profiles ORDER BY name")
        for row in rows:
            row["data"] = json.loads(row["data"])
        return {
            "profiles": rows,
            "default": InstallProfile(name="Безопасный baseline").model_dump(),
            "notes": [
                "По умолчанию параметры ОС не изменяются",
                "Shaping — лимит всего egress интерфейса VPS, не per-user",
                "Bridge/routing настраиваются отдельно в версиях Xray шаблона",
            ],
        }

    @r.post("/api/install-profiles", status_code=201)
    async def profile_create(body: InstallProfile, request: Request):
        p = authorize(request)
        db, _, _, _ = state(request)
        key = str(uuid.uuid4())
        try:
            db.execute(
                "INSERT INTO install_profiles VALUES(?,?,?,?,?)",
                (key, body.name, json.dumps(body.model_dump()), time.time(), time.time()),
            )
        except sqlite3.IntegrityError as e:
            raise HTTPException(409, "Имя профиля занято") from e
        audit(request, p, "install-profile.created", body.name)
        return {"id": key}

    @r.delete("/api/install-profiles/{profile_id}")
    async def profile_delete(profile_id: str, request: Request):
        p = authorize(request)
        db, _, _, _ = state(request)
        db.execute("DELETE FROM install_profiles WHERE id=?", (profile_id,))
        audit(request, p, "install-profile.deleted", profile_id)
        return {"ok": True}

    @r.get("/api/nodes/{node_id}/tuning")
    async def tuning_get(node_id: str, request: Request):
        authorize(request)
        db, box, cfg, _ = state(request)
        node = db.one("SELECT * FROM nodes WHERE id=?", (node_id,))
        if not node:
            raise HTTPException(404, "Нода не найдена")
        if cfg.demo:
            return {
                "supported": True,
                "version": "1.1.0",
                "settings": {"congestion": "bbr", "qdisc": "fq", "egress_mbps": None},
                "capabilities": ["tcp-congestion", "qdisc", "egress-shaping"],
            }
        if not node["managed"] or not node["management_key"]:
            return {"supported": False, "reason": "Нода не имеет управляемого агента"}
        health = await agent_call(node, box, cfg, "health")
        supported = "tune" in health.get("capabilities", [])
        db.execute(
            "UPDATE nodes SET agent_version=? WHERE id=?", (health.get("agent_version", "1.0.0"), node_id)
        )
        return {
            "supported": supported,
            "version": health.get("agent_version", "1.0.0"),
            "settings": json.loads(node["tuning"]),
            "reason": None
            if supported
            else "Агент 1.0 не обновляется через restricted key. Обновите его своим SSH: deploy/update-node-agent.sh",
        }

    @r.post("/api/nodes/{node_id}/tuning", status_code=202)
    async def tuning_put(node_id: str, body: NodeTune, request: Request):
        p = authorize(request)
        db, box, cfg, services = state(request)
        node = db.one("SELECT * FROM nodes WHERE id=?", (node_id,))
        if not node or body.confirm != node["slug"]:
            raise HTTPException(400, "Подтвердите slug ноды")
        if not node["managed"] or not node["management_key"]:
            raise HTTPException(400, "Только управляемые ноды")
        if db.one("SELECT id FROM jobs WHERE node_id=? AND state IN ('queued','running')", (node_id,)):
            raise HTTPException(409, "Для ноды уже выполняется задание")
        health = await agent_call(node, box, cfg, "health")
        if "tune" not in health.get("capabilities", []):
            raise HTTPException(409, "Сначала обновите агент ноды через собственный SSH")
        key = str(uuid.uuid4())
        payload = body.tuning.model_dump()
        db.execute(
            "INSERT INTO jobs(id,node_id,kind,state,message,payload_cipher,created,updated) VALUES(?,?,?,?,?,?,?,?)",
            (
                key,
                node_id,
                "tune",
                "queued",
                "Проверка и применение профиля тюнинга",
                box.encrypt(json.dumps(payload), "job:" + key),
                time.time(),
                time.time(),
            ),
        )
        services.spawn(key)
        audit(request, p, "node.tuning.queued", node["slug"])
        return {"job_id": key}

    @r.get("/api/config-versions")
    async def versions_get(request: Request):
        authorize(request)
        db, _, _, _ = state(request)
        return db.query("SELECT id,name,created,actor FROM config_versions ORDER BY created DESC")

    @r.post("/api/config-versions", status_code=201)
    async def versions_save(body: VersionSave, request: Request):
        p = authorize(request)
        db, box, _, _ = state(request)
        key = save_version(db, box, body.config, body.name, p["username"])
        audit(request, p, "config.version.saved", body.name)
        return {"id": key}

    @r.get("/api/config-versions/{version_id}")
    async def version_get(version_id: str, request: Request):
        authorize(request)
        db, box, _, _ = state(request)
        row = db.one("SELECT * FROM config_versions WHERE id=?", (version_id,))
        if not row:
            raise HTTPException(404, "Версия не найдена")
        return {
            "id": version_id,
            "name": row["name"],
            "config": json.loads(box.decrypt(row["cipher"], "config-version:" + version_id)),
        }

    @r.post("/api/config-versions/{version_id}/activate")
    async def version_activate(version_id: str, request: Request):
        p = authorize(request)
        db, box, _, _ = state(request)
        row = db.one("SELECT * FROM config_versions WHERE id=?", (version_id,))
        if not row:
            raise HTTPException(404, "Версия не найдена")
        value = box.decrypt(row["cipher"], "config-version:" + version_id)
        validate_template(json.loads(value))
        db.set("template", box.encrypt(value, "setting:template"))
        audit(request, p, "config.version.activated", row["name"])
        return {"ok": True, "existing_nodes_changed": False}

    @r.get("/api/notifications")
    async def notifications_get(request: Request):
        authorize(request)
        db, _, _, _ = state(request)
        return {
            "rules": db.get("notification_rules", NotificationRules().model_dump()),
            "configured": bool(db.get("telegram_token"))
            and bool(db.get("integration", {}).get("telegram_chat_id")),
            "health": db.get("notification_health", {}),
        }

    @r.put("/api/notifications")
    async def notifications_put(body: NotificationRules, request: Request):
        p = authorize(request)
        db, _, _, _ = state(request)
        db.set("notification_rules", body.model_dump())
        audit(request, p, "notifications.updated")
        return {"ok": True}

    @r.post("/api/notifications/test")
    async def notification_test(request: Request):
        p = authorize(request)
        db, box, cfg, _ = state(request)
        if not db.get("telegram_token") or not db.get("integration", {}).get("telegram_chat_id"):
            raise HTTPException(409, "Сначала настройте bot token и chat ID")
        if not db.hit("telegram-test:" + p["id"], 2, 60):
            raise HTTPException(429, "Повторите позже")
        await notify(db, box, cfg, "Тест GhostFleet 1.1 · канал уведомлений", category="test")
        return db.get("notification_health", {"ok": False, "message": "Нет подтверждения доставки"})

    @r.get("/api/capabilities")
    async def capabilities(request: Request):
        p = authorize(request)
        _, _, cfg, _ = state(request)
        return {
            "permissions": p["permissions"],
            "anti_sharing": "observe",
            "automatic_bans": False,
            "demo": cfg.demo,
            "features": [
                "staff-rbac",
                "service-tokens",
                "cloudflare-dns",
                "hwid-observation",
                "install-profiles",
                "config-versions",
                "node-tuning",
                "telegram-rules",
            ],
        }

    return r
