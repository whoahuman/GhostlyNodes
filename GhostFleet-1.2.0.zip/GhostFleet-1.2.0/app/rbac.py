"""Server-side capabilities. Unknown API paths are denied, never granted by UI visibility."""

from __future__ import annotations

ALL = {
    "nodes.read",
    "nodes.operate",
    "nodes.install",
    "nodes.tune",
    "jobs.read",
    "configs.read",
    "configs.write",
    "configs.secret",
    "users.read",
    "users.operate",
    "users.policy",
    "dns.read",
    "dns.write",
    "dns.manage",
    "staff.read",
    "staff.write",
    "access.write",
    "tokens.manage",
    "settings.read",
    "settings.write",
    "audit.read",
}
ROLES = {
    "owner": ALL,
    "admin": ALL - {"staff.write", "access.write", "tokens.manage", "configs.secret"},
    "operator": {
        "nodes.read",
        "nodes.operate",
        "jobs.read",
        "configs.read",
        "users.read",
        "users.operate",
        "audit.read",
    },
    "viewer": {"nodes.read", "jobs.read", "configs.read", "users.read"},
    "dns": {"nodes.read", "dns.read", "dns.write", "audit.read"},
}
SERVICE_SCOPES = {
    "nodes.read",
    "nodes.operate",
    "jobs.read",
    "users.read",
    "users.operate",
    "dns.read",
    "dns.write",
    "configs.read",
}


def permissions(role: str, custom: list | None = None) -> list[str]:
    base = ROLES.get(role, set())
    return sorted(base if custom is None else base & set(custom))


def path_permission(path: str, method: str) -> str | None:
    read = method in {"GET", "HEAD"}
    if path.startswith("/api/auth/"):
        return "authenticated"
    if path in {"/api/dashboard", "/api/nodes", "/api/nodes/export"}:
        return "nodes.read" if read else "nodes.install"
    if path == "/api/sync":
        return "nodes.operate"
    if path == "/api/nodes/probe" or path.endswith("/retry"):
        return "nodes.install"
    if path.startswith("/api/nodes/"):
        if path.endswith("/logs"):
            return "nodes.operate"
        if path.endswith("/config"):
            return "configs.read"
        if path.endswith("/actions"):
            return "nodes.operate"
        if path.endswith("/tuning"):
            return "nodes.tune" if not read else "nodes.read"
        return "nodes.read" if read else None
    if path.startswith("/api/jobs"):
        return "jobs.read"
    if path.startswith("/api/audit"):
        return "audit.read"
    if path.startswith("/api/settings"):
        return "settings.read" if read else "settings.write"
    if path == "/api/squads":
        return "settings.read"
    if path.startswith("/api/template"):
        if path.endswith("/preview"):
            return "configs.read"
        return "configs.secret" if read else "configs.write"
    if path.startswith("/api/staff"):
        return "staff.read" if read else "staff.write"
    if path.startswith("/api/service-accounts"):
        return "tokens.manage"
    if path.startswith("/api/access"):
        return "staff.read" if read else "access.write"
    if path.startswith("/api/cloudflare/settings"):
        return "dns.manage"
    if path.startswith("/api/cloudflare"):
        return "dns.read" if read else "dns.write"
    if path.startswith("/api/users/policy"):
        return "users.read" if read else "users.policy"
    if path.startswith("/api/users"):
        return "users.read" if read else "users.operate"
    if path.startswith("/api/install-profiles"):
        return "nodes.read" if read else "nodes.install"
    if path.startswith("/api/config-versions"):
        return "configs.secret" if read else "configs.write"
    if path.startswith("/api/notifications"):
        return "settings.read" if read else "settings.write"
    if path.startswith("/api/capabilities"):
        return "authenticated"
    return None
