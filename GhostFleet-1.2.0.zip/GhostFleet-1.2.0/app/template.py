from __future__ import annotations

import copy
import hashlib
import json
import re
import ssl
import warnings
from datetime import timezone
from functools import lru_cache
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import serialization
from cryptography.utils import CryptographyDeprecationWarning
from cryptography.x509.verification import PolicyBuilder, Store

from .schemas import COUNTRY_CODES

DEFAULT_TEMPLATE = Path(__file__).resolve().parents[1] / "templates/xray.example.json"


class TemplateError(ValueError):
    pass


def validate_template(config: dict, allow_placeholders: bool = False) -> None:
    try:
        _validate_template(config, allow_placeholders)
    except TemplateError:
        raise
    except (ValueError, TypeError, AttributeError, KeyError) as e:
        raise TemplateError("Некорректная структура JSON: проверьте inbounds, outbounds и routing") from e


def _validate_template(config: dict, allow_placeholders: bool = False) -> None:
    if len(json.dumps(config)) > 512_000:
        raise TemplateError("Шаблон больше 512 КБ")
    inbounds = config.get("inbounds")
    if not isinstance(inbounds, list) or not 1 <= len(inbounds) <= 20:
        raise TemplateError("Нужен список из 1–20 inbound")
    tags = set()
    for inbound in inbounds:
        if not isinstance(inbound, dict) or not isinstance(inbound.get("tag"), str):
            raise TemplateError("У каждого inbound должен быть строковый tag")
        tag = inbound["tag"]
        if tag in tags or not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", tag):
            raise TemplateError("Теги inbound должны быть уникальными и состоять из букв, цифр, '-' и '_'")
        tags.add(tag)
        if inbound.get("protocol") not in {"vless", "hysteria"}:
            raise TemplateError("Этот адаптер поддерживает VLESS gRPC и Hysteria2")
        stream = inbound.get("streamSettings", {})
        security = stream.get("security")
        # REALITY camouflage is only meaningful for VLESS: it needs a real TLS 1.3
        # handshake to mirror, which Hysteria2's own QUIC/TLS layer cannot reuse.
        is_reality = inbound.get("protocol") == "vless" and security == "reality"
        if stream.get("network") not in {"grpc", "hysteria"} or security not in {"tls", "reality"}:
            raise TemplateError("Для этого адаптера нужны TLS/REALITY + grpc/hysteria")
        if not is_reality and security != "tls":
            raise TemplateError("Hysteria2 требует TLS; REALITY поддерживается только для VLESS")
        if type(inbound.get("port")) is not int or inbound["port"] != 443:
            raise TemplateError("В этой версии адаптера пользовательский порт — 443 (TCP/UDP)")
        if inbound.get("settings", {}).get("clients", []) != []:
            raise TemplateError("clients должен быть пустым: пользователей добавляет Remnawave")
        if is_reality:
            _validate_reality_settings(stream.get("realitySettings"), allow_placeholders)
        else:
            certs = stream.get("tlsSettings", {}).get("certificates")
            if not isinstance(certs, list) or len(certs) != 1:
                raise TemplateError(
                    "Нужен один TLS-сертификат на inbound; он будет заменён сертификатом ноды"
                )
    outbounds = config.get("outbounds", [])
    if not isinstance(outbounds, list) or not outbounds:
        raise TemplateError("Нужны outbounds")
    out_tags = {o.get("tag") for o in outbounds if isinstance(o, dict)}
    if len(out_tags) != len(outbounds) or None in out_tags:
        raise TemplateError("У outbounds нужны уникальные теги")
    for rule in config.get("routing", {}).get("rules", []):
        if rule.get("outboundTag") and rule["outboundTag"] not in out_tags:
            raise TemplateError("routing ссылается на неизвестный outboundTag")
        if any(t not in tags for t in rule.get("inboundTag", [])):
            raise TemplateError("routing ссылается на неизвестный inboundTag")
    if not allow_placeholders and "REPLACE_WITH_" in json.dumps(config):
        raise TemplateError("Импортируйте свой конфиг: в примере ещё есть REPLACE_WITH_… для RU_BRIDGE")


def _is_placeholder(value, allow_placeholders: bool) -> bool:
    return allow_placeholders and isinstance(value, str) and value.startswith("REPLACE_WITH_")


def _validate_reality_settings(reality, allow_placeholders: bool = False) -> None:
    if not isinstance(reality, dict):
        raise TemplateError("Нужен realitySettings для REALITY inbound")
    dest = reality.get("dest")
    if not isinstance(dest, str):
        raise TemplateError("realitySettings.dest должен быть вида host:port — реальный HTTPS-сайт")
    if not _is_placeholder(dest, allow_placeholders) and not re.fullmatch(r"[a-z0-9.-]{1,253}:\d{1,5}", dest):
        raise TemplateError("realitySettings.dest должен быть вида host:port — реальный HTTPS-сайт")
    names = reality.get("serverNames")
    if not isinstance(names, list) or not 1 <= len(names) <= 4 or not all(isinstance(n, str) for n in names):
        raise TemplateError("realitySettings.serverNames должен быть непустым списком доменов")
    if not all(
        _is_placeholder(n, allow_placeholders) or re.fullmatch(r"[a-z0-9.-]{1,253}", n) for n in names
    ):
        raise TemplateError("realitySettings.serverNames должен быть непустым списком доменов")
    private_key = reality.get("privateKey")
    if not isinstance(private_key, str) or not 1 <= len(private_key) <= 100:
        raise TemplateError("realitySettings.privateKey обязателен (x25519, держите в секрете)")
    short_ids = reality.get("shortIds")
    if not isinstance(short_ids, list) or not short_ids or not all(isinstance(s, str) for s in short_ids):
        raise TemplateError("realitySettings.shortIds должен быть списком hex-строк длиной до 16 символов")
    if not all(
        _is_placeholder(s, allow_placeholders) or re.fullmatch(r"[0-9a-fA-F]{0,16}", s) for s in short_ids
    ):
        raise TemplateError("realitySettings.shortIds должен быть списком hex-строк длиной до 16 символов")
    if reality.get("show") not in (False, None):
        # "show" dumps the camouflaged handshake details to the Xray log; it exists for
        # debugging the REALITY feature itself and must never run enabled in production.
        raise TemplateError("realitySettings.show должен быть false в проде")
    if reality.get("xver") not in (0, 1, 2, None):
        raise TemplateError("realitySettings.xver должен быть 0, 1 или 2")


def render_config(
    template: dict, country: str, ordinal: int, cert: dict | None = None, preview: bool = False
) -> dict:
    validate_template(template, allow_placeholders=preview)
    if country not in COUNTRY_CODES or not 1 <= ordinal <= 9999:
        raise TemplateError("Некорректная страна или номер ноды")
    config = copy.deepcopy(template)
    prefix = f"{country.lower()}-{ordinal:02d}"
    mapping = {}
    for inbound in config["inbounds"]:
        old = inbound["tag"]
        match = re.fullmatch(r"([A-Za-z]{2})-\d{1,4}-(.+)", old)
        suffix = match.group(2) if match else old
        new = f"{prefix}-{suffix}"
        if len(new) > 64:
            raise TemplateError("Слишком длинный тег после подстановки страны")
        mapping[old] = new
        inbound["tag"] = new
        stream = inbound["streamSettings"]
        if stream.get("network") == "grpc":
            stream.setdefault("grpcSettings", {})["serviceName"] = f"{country.lower()}-{ordinal}"
        masq = stream.get("hysteriaSettings", {}).get("masquerade", {})
        if masq.get("type") == "file":
            masq["dir"] = "/var/www"
        # REALITY inbounds mirror a real third-party site's own certificate on the wire;
        # they never hold (or need) the node's own Let's Encrypt certificate.
        if cert and stream.get("security") == "tls":
            original = stream["tlsSettings"]["certificates"][0]
            options = {
                k: v
                for k, v in original.items()
                if k not in {"keyFile", "certificateFile", "key", "certificate"}
            }
            stream["tlsSettings"]["certificates"] = [
                {**options, "certificate": cert["certificate"], "key": cert["key"]}
            ]
    generated = [i["tag"] for i in config["inbounds"]]
    if len(set(generated)) != len(generated):
        raise TemplateError("Теги после замены страны не уникальны. Нужен один inbound каждого типа")
    for rule in config.get("routing", {}).get("rules", []):
        if "inboundTag" in rule:
            rule["inboundTag"] = [mapping[t] for t in rule["inboundTag"]]
    return config


def redact(value):
    if isinstance(value, dict):
        return {
            k: (
                "<REDACTED>"
                if k.lower() in {"password", "id", "privatekey", "secretkey", "token"}
                else ["<PRIVATE KEY OMITTED>"]
                if k == "key"
                else redact(v)
            )
            for k, v in value.items()
        }
    if isinstance(value, list):
        return [redact(v) for v in value]
    return value


@lru_cache(maxsize=1)
def system_trust_store() -> Store:
    context = ssl.create_default_context()
    roots = []
    for der in context.get_ca_certs(binary_form=True):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", CryptographyDeprecationWarning)
            root = x509.load_der_x509_certificate(der)
            valid_serial = root.serial_number > 0
        if valid_serial:
            roots.append(root)
    return Store(roots)


def parse_certificate(
    fullchain: str, private_key: str, domain: str, trusted_roots: list | None = None
) -> dict:
    if len(fullchain) > 100_000 or len(private_key) > 30_000:
        raise TemplateError("Слишком большой сертификат")
    try:
        chain = x509.load_pem_x509_certificates(fullchain.encode())
        if not 1 <= len(chain) <= 8:
            raise TemplateError("Некорректная длина TLS-цепочки")
        cert = chain[0]
        key = serialization.load_pem_private_key(private_key.encode(), password=None)
        cert_pub = cert.public_key().public_bytes(
            serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo
        )
        key_pub = key.public_key().public_bytes(
            serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo
        )
        if cert_pub != key_pub:
            raise TemplateError("TLS-ключ не соответствует сертификату")
        names = cert.extensions.get_extension_for_class(
            x509.SubjectAlternativeName
        ).value.get_values_for_type(x509.DNSName)
        valid_name = any(
            n == domain
            or (
                n.startswith("*.") and domain.split(".", 1)[-1] == n[2:] and domain.count(".") == n.count(".")
            )
            for n in names
        )
        if not valid_name:
            raise TemplateError("Сертификат не покрывает домен ноды")
        from datetime import datetime

        expires = cert.not_valid_after_utc
        if expires <= datetime.now(timezone.utc):
            raise TemplateError("TLS-сертификат истёк")
        if cert.not_valid_before_utc > datetime.now(timezone.utc):
            raise TemplateError("TLS-сертификат ещё не действителен")
        try:
            store = Store(trusted_roots) if trusted_roots is not None else system_trust_store()
            verifier = (
                PolicyBuilder()
                .store(store)
                .time(datetime.now(timezone.utc))
                .max_chain_depth(6)
                .build_server_verifier(x509.DNSName(domain))
            )
            verifier.verify(cert, chain[1:])
        except Exception as e:
            raise TemplateError(
                "TLS-цепочка не доверена системным CA. Self-signed сертификаты не публикуются"
            ) from e
        return {
            "certificate": fullchain.strip().splitlines(),
            "key": private_key.strip().splitlines(),
            "hash": hashlib.sha256(fullchain.encode()).hexdigest(),
            "expires": expires.timestamp(),
        }
    except TemplateError:
        raise
    except Exception as e:
        raise TemplateError("Не удалось проверить TLS-сертификат и ключ") from e


def replace_certificates(config: dict, managed_tags: set[str], cert: dict) -> dict:
    result = copy.deepcopy(config)
    found = set()
    for inbound in result.get("inbounds", []):
        if inbound.get("tag") not in managed_tags:
            continue
        found.add(inbound["tag"])
        stream = inbound.get("streamSettings", {})
        if stream.get("security") == "reality":
            # REALITY inbounds carry no certificate of ours to rotate; they mirror
            # whatever TLS certificate the camouflaged destination site presents.
            continue
        if stream.get("security") != "tls":
            raise TemplateError("Профиль изменён вручную: TLS не найден; нужна ручная проверка")
        options = stream.get("tlsSettings", {}).get("certificates", [{}])[0]
        options = {
            k: v for k, v in options.items() if k not in {"keyFile", "certificateFile", "key", "certificate"}
        }
        stream["tlsSettings"]["certificates"] = [
            {**options, "certificate": cert["certificate"], "key": cert["key"]}
        ]
    if found != managed_tags:
        raise TemplateError("Теги профиля изменены вручную; автосинхронизация сертификатов остановлена")
    return result
