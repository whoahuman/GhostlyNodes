from __future__ import annotations

import ipaddress
import json
import re
from urllib.parse import urlencode

import httpx


class CloudflareError(RuntimeError):
    pass


class Cloudflare:
    BASE = "https://api.cloudflare.com/client/v4"

    def __init__(self, token: str, transport=None):
        self.token, self.transport = token, transport

    async def request(self, method: str, path: str, payload=None):
        if not path.startswith("/") or ".." in path or path.startswith("//"):
            raise ValueError("Invalid Cloudflare path")
        try:
            async with httpx.AsyncClient(
                timeout=20, follow_redirects=False, trust_env=False, transport=self.transport
            ) as c:
                async with c.stream(
                    method,
                    self.BASE + path,
                    headers={"Authorization": "Bearer " + self.token, "Accept": "application/json"},
                    json=payload,
                ) as r:
                    if not 200 <= r.status_code < 300:
                        raise CloudflareError(
                            f"Cloudflare HTTP {r.status_code}. Проверьте token scopes/zone permissions"
                        )
                    data = bytearray()
                    async for chunk in r.aiter_bytes():
                        data.extend(chunk)
                        if len(data) > 2 * 1024 * 1024:
                            raise CloudflareError("Cloudflare ответ больше 2 МБ")
            parsed = json.loads(data)
            if parsed.get("success") is not True:
                raise CloudflareError(
                    "Cloudflare отклонил запрос. Подробности смотрите в своей Cloudflare панели"
                )
            return parsed
        except CloudflareError:
            raise
        except (httpx.HTTPError, ValueError, TypeError) as e:
            raise CloudflareError("Cloudflare недоступен/неверный JSON. Токен в ошибке не выводится") from e

    async def zones(self):
        result = []
        for page in range(1, 5):
            p = await self.request("GET", f"/zones?per_page=50&page={page}")
            result.extend({"id": z["id"], "name": z["name"], "status": z.get("status")} for z in p["result"])
            if page >= p.get("result_info", {}).get("total_pages", 1):
                break
        return result

    async def records(self, zone_id: str, name: str | None = None):
        self.validate_zone(zone_id)
        q = urlencode({"per_page": 100, **({"name": name} if name else {})})
        p = await self.request("GET", f"/zones/{zone_id}/dns_records?{q}")
        return [
            {
                "id": r["id"],
                "type": r["type"],
                "name": r["name"],
                "content": r["content"],
                "ttl": r["ttl"],
                "proxied": r.get("proxied", False),
            }
            for r in p["result"]
        ]

    async def upsert(self, zone_id: str, name: str, address: str, ttl: int, replace: bool):
        zones = await self.zones()
        zone = next((z for z in zones if z["id"] == zone_id), None)
        if not zone or not (name == zone["name"] or name.endswith("." + zone["name"])):
            raise CloudflareError("Домен не принадлежит выбранной зоне")
        kind = "A" if ipaddress.ip_address(address).version == 4 else "AAAA"
        existing = await self.records(zone_id, name)
        # Do not silently create conflicting records/dual-stack endpoints.
        if any(r["type"] not in {kind, "TXT"} for r in existing):
            raise CloudflareError("Есть конфликтующая CNAME/A/AAAA запись. Исправьте её явно в Cloudflare")
        current = [r for r in existing if r["type"] == kind]
        if len(current) > 1:
            raise CloudflareError("Несколько DNS-записей: автоматическая замена запрещена")
        body = {
            "type": kind,
            "name": name,
            "content": address,
            "ttl": ttl,
            "proxied": False,
            "comment": "Managed by GhostFleet",
        }
        if current:
            old = current[0]
            if old["content"] == address and not old["proxied"]:
                return {**old, "unchanged": True}
            if not replace:
                raise CloudflareError(
                    "Существующая запись отличается. Подтвердите replace; автоматической перезаписи нет"
                )
            p = await self.request("PUT", f"/zones/{zone_id}/dns_records/{old['id']}", body)
        else:
            p = await self.request("POST", f"/zones/{zone_id}/dns_records", body)
        r = p["result"]
        return {k: r.get(k) for k in ("id", "type", "name", "content", "ttl", "proxied")}

    @staticmethod
    def validate_zone(zone_id):
        if not re.fullmatch(r"[a-f0-9]{32}", zone_id):
            raise ValueError("Invalid zone ID")
