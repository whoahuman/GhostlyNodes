from __future__ import annotations

import asyncio
import csv
import hmac
import io
import json
import re
import secrets
import time
import uuid
from contextlib import asynccontextmanager, suppress

import pyotp
from fastapi import FastAPI, HTTPException, Query, Request, Response
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from . import __version__
from .config import ROOT, Config
from .db import Database
from .deployment import Services
from .monitor import monitor_loop, sync_nodes
from .remnawave import RemnawaveError, normalize_url
from .schemas import (
    DeployRequest,
    Login,
    NodeAction,
    OtpCode,
    PasswordChange,
    Probe,
    SettingsUpdate,
    TemplateInput,
    TemplatePreview,
)
from .security import (
    DUMMY_HASH,
    SecretBox,
    SecurityMiddleware,
    admin_label,
    authorize,
    check_password,
    client_ip,
    consume_second_factor,
    enrollment_qr,
    get_session,
    hash_password,
    ip_allowed,
    new_session,
    rate_ip,
    recovery_label,
    require_permission,
)
from .ssh import SSHError, agent_call, detect_country, probe_host, verify_dns
from .template import DEFAULT_TEMPLATE, TemplateError, redact, render_config, validate_template


def create_app(cfg: Config | None = None, background: bool = True) -> FastAPI:
    cfg = cfg or Config.from_env()
    db = Database(cfg.db_path)
    db.init()
    if cfg.demo and not cfg.key_path.exists():
        SecretBox.create(cfg.key_path)
    if not cfg.key_path.exists():
        raise RuntimeError(
            "Master key missing. Initialise using python -m app.cli init; never generate a replacement for an existing database."
        )
    box = SecretBox.read(cfg.key_path)
    if not db.get("instance_id"):
        db.set("instance_id", str(uuid.uuid4()))
    if not db.get("template"):
        db.set("template", box.encrypt(DEFAULT_TEMPLATE.read_text(), "setting:template"))
    services = Services(db, box, cfg)
    if cfg.demo:
        from .demo import seed_demo

        seed_demo(db, box)
    elif not db.one("SELECT id FROM admins WHERE id=1"):
        raise RuntimeError("Admin not initialised. Run python -m app.cli init on the server.")

    @asynccontextmanager
    async def lifespan(app):
        db.recover_jobs()
        task = asyncio.create_task(monitor_loop(services)) if background and not cfg.demo else None
        yield
        if task:
            task.cancel()
            with suppress(asyncio.CancelledError):
                await task
        await services.shutdown()

    app = FastAPI(
        title="GhostFleet",
        version=__version__,
        docs_url=None,
        redoc_url=None,
        openapi_url=None,
        lifespan=lifespan,
    )
    app.state.cfg, app.state.db, app.state.box, app.state.services = cfg, db, box, services
    app.add_middleware(SecurityMiddleware, cfg=cfg)

    @app.exception_handler(RequestValidationError)
    async def invalid_request(request, exc):
        # FastAPI's default includes the rejected input, which might be a password.
        errors = [{"field": ".".join(map(str, e["loc"])), "message": e["msg"]} for e in exc.errors()]
        return JSONResponse(status_code=422, content={"detail": "Проверьте поля формы", "errors": errors})

    from .cloudflare import CloudflareError

    @app.exception_handler(CloudflareError)
    @app.exception_handler(SSHError)
    @app.exception_handler(TemplateError)
    @app.exception_handler(RemnawaveError)
    async def service_error(request, exc):
        return JSONResponse(status_code=400, content={"detail": str(exc)})

    @app.get("/healthz")
    async def health():
        return {"status": "ok", "version": __version__}

    @app.get("/api/auth/me")
    async def me(request: Request):
        session = authorize(request, allow_setup=True)
        admin = db.one("SELECT totp_secret FROM admins WHERE id=?", (session["admin_id"],))
        return {
            "username": session["username"],
            "role": session["role"],
            "permissions": session["permissions"],
            "admin_id": session["admin_id"],
            "csrf": session["csrf"],
            "must_enroll": session["scope"] != "full",
            "totp_enabled": bool(admin and admin["totp_secret"]) or cfg.demo,
            "demo": cfg.demo,
            "version": __version__,
            "access_mode": cfg.mode,
            "idle_seconds": cfg.idle_seconds,
        }

    @app.post("/api/auth/login")
    async def login(body: Login, request: Request, response: Response):
        if cfg.demo:
            raise HTTPException(403, "В демо вход отключён; режим только на чтение")
        ip = client_ip(request)
        if not db.hit("login:" + rate_ip(ip), 5, 900) or not db.hit("login:global", 100, 900):
            raise HTTPException(429, "Слишком много попыток. Подождите 15 минут")
        admin = db.one("SELECT * FROM admins WHERE username=? AND active=1", (body.username,))
        encoded = admin["password_hash"] if admin else DUMMY_HASH
        matched = await check_password(encoded, body.password.get_secret_value())
        matched = bool(
            matched and admin and hmac.compare_digest(body.username.encode(), admin["username"].encode())
        )
        if matched and not ip_allowed(ip, json.loads(admin["allowed_cidrs"])):
            matched = False
        if not matched:
            db.audit("auth.failed", "Неверные реквизиты", actor="anonymous", ip=ip)
            raise HTTPException(401, "Неверный логин, пароль или одноразовый код")
        with db.transaction() as conn:
            current = dict(conn.execute("SELECT * FROM admins WHERE id=?", (admin["id"],)).fetchone())
            if (
                current["password_hash"] != encoded
                or not current["active"]
                or not ip_allowed(ip, json.loads(current["allowed_cidrs"]))
            ):
                raise HTTPException(401, "Реквизиты изменены. Войдите снова")
            if current["totp_secret"] and not consume_second_factor(conn, current, box, body.code):
                # The transaction commits no credential changes on a failed OTP.
                matched = False
        if not matched:
            db.audit("auth.failed", "Неверный или повторно использованный 2FA-код", actor="anonymous", ip=ip)
            raise HTTPException(
                401, "Неверный логин, пароль или одноразовый код. Код нельзя использовать повторно"
            )
        token, session = new_session(
            db,
            cfg,
            ip,
            request.headers.get("user-agent", ""),
            "full" if current["totp_secret"] else "setup",
            current["id"],
        )
        response.set_cookie(
            cfg.cookie_name,
            token,
            max_age=cfg.session_seconds,
            httponly=True,
            secure=cfg.secure_cookie,
            samesite="strict",
            path="/",
        )
        db.audit(
            "auth.login",
            "Требуется подключить 2FA" if session["scope"] == "setup" else "Успешный вход",
            admin["username"],
            ip,
        )
        return {
            "username": admin["username"],
            "csrf": session["csrf"],
            "must_enroll": session["scope"] == "setup",
        }

    @app.post("/api/auth/logout")
    async def logout(request: Request, response: Response):
        session = authorize(request, allow_setup=True)
        db.execute("DELETE FROM sessions WHERE id=?", (session["id"],))
        response.delete_cookie(
            cfg.cookie_name, path="/", secure=cfg.secure_cookie, httponly=True, samesite="strict"
        )
        db.audit("auth.logout", actor=session["username"], ip=client_ip(request))
        return {"ok": True}

    @app.post("/api/auth/activity")
    async def activity(request: Request):
        authorize(request, allow_setup=True)
        return {"ok": True}

    @app.post("/api/auth/totp/setup")
    async def totp_setup(request: Request):
        session = authorize(request, allow_setup=True)
        if not db.hit("totp-setup:" + session["id"], 6, 900):
            raise HTTPException(429, "Подождите перед повторной настройкой")
        with db.transaction() as conn:
            admin = dict(conn.execute("SELECT * FROM admins WHERE id=?", (session["admin_id"],)).fetchone())
            if admin["totp_secret"]:
                raise HTTPException(409, "2FA уже подключена. Для сброса используйте CLI на сервере")
            if admin["pending_totp"]:
                secret = box.decrypt(admin["pending_totp"], admin_label(session["admin_id"], "pending_totp"))
            else:
                secret = pyotp.random_base32()
                conn.execute(
                    "UPDATE admins SET pending_totp=? WHERE id=?",
                    (
                        box.encrypt(secret, admin_label(session["admin_id"], "pending_totp")),
                        session["admin_id"],
                    ),
                )
        return {"secret": secret, "qr": enrollment_qr(secret, session["username"])}

    @app.post("/api/auth/totp/confirm")
    async def totp_confirm(body: OtpCode, request: Request):
        session = authorize(request, allow_setup=True)
        if not db.hit("totp-confirm:" + session["id"], 5, 900):
            raise HTTPException(429, "Слишком много попыток 2FA")
        with db.transaction() as conn:
            admin = dict(conn.execute("SELECT * FROM admins WHERE id=?", (session["admin_id"],)).fetchone())
            if admin["totp_secret"] or not admin["pending_totp"]:
                raise HTTPException(409, "Запустите настройку 2FA")
            secret = box.decrypt(admin["pending_totp"], admin_label(session["admin_id"], "pending_totp"))
            otp = pyotp.TOTP(secret)
            counter = int(time.time()) // 30
            matched = next(
                (
                    c
                    for c in (counter, counter - 1, counter + 1)
                    if hmac.compare_digest(otp.generate_otp(c), body.code)
                ),
                None,
            )
            if matched is None:
                raise HTTPException(400, "Неверный код. Проверьте время на телефоне и сервере")
            codes = []
            for _ in range(10):
                raw = secrets.token_hex(10).upper()
                codes.append("-".join(raw[i : i + 5] for i in range(0, 20, 5)))
            conn.execute(
                "UPDATE admins SET totp_secret=?,pending_totp=NULL,totp_counter=?,recovery=? WHERE id=?",
                (
                    box.encrypt(secret, admin_label(session["admin_id"], "totp")),
                    matched,
                    json.dumps([box.digest(c, recovery_label(session["admin_id"])) for c in codes]),
                    session["admin_id"],
                ),
            )
            # Revoke other password-only enrollment sessions.
            conn.execute(
                "DELETE FROM sessions WHERE scope='setup' AND id!=? AND admin_id=?",
                (session["id"], session["admin_id"]),
            )
            conn.execute(
                "UPDATE sessions SET scope='full',elevated_at=? WHERE id=?", (time.time(), session["id"])
            )
        db.audit("auth.totp_enabled", actor=session["username"], ip=client_ip(request))
        return {"recovery_codes": codes}

    @app.post("/api/auth/password")
    async def change_password(body: PasswordChange, request: Request, response: Response):
        session = authorize(request)
        if not db.hit("password:" + session["id"], 5, 900):
            raise HTTPException(429, "Слишком много попыток")
        admin = db.one("SELECT * FROM admins WHERE id=?", (session["admin_id"],))
        if not await check_password(admin["password_hash"], body.old_password.get_secret_value()):
            raise HTTPException(400, "Неверные реквизиты")
        new_hash = await hash_password(body.new_password.get_secret_value())
        with db.transaction() as conn:
            current = dict(conn.execute("SELECT * FROM admins WHERE id=?", (session["admin_id"],)).fetchone())
            if not consume_second_factor(conn, current, box, body.code):
                raise HTTPException(400, "Неверный или уже использованный 2FA-код")
            conn.execute("UPDATE admins SET password_hash=? WHERE id=?", (new_hash, session["admin_id"]))
            conn.execute("DELETE FROM sessions WHERE admin_id=?", (session["admin_id"],))
        response.delete_cookie(cfg.cookie_name, path="/", secure=cfg.secure_cookie)
        db.audit("auth.password_changed", actor=session["username"], ip=client_ip(request))
        return {"ok": True, "reauthenticate": True}

    def template() -> dict:
        return json.loads(box.decrypt(db.get("template"), "setting:template"))

    def public_settings() -> dict:
        settings = db.get("integration", {})
        try:
            validate_template(template())
            ready_template = True
        except TemplateError:
            ready_template = False
        return {
            **settings,
            "api_token_configured": bool(db.get("api_token")),
            "telegram_configured": bool(db.get("telegram_token")),
            "template_ready": ready_template,
            "access_mode": cfg.mode,
            "public_url": cfg.public_url,
            "private_node_cidrs": [str(n) for n in cfg.private_node_cidrs],
            "api_allow_hosts": list(cfg.api_allow_hosts),
            "demo": cfg.demo,
        }

    @app.get("/api/settings")
    async def settings_get(request: Request):
        authorize(request)
        return public_settings()

    @app.put("/api/settings")
    async def settings_put(body: SettingsUpdate, request: Request):
        session = authorize(request)
        if db.one("SELECT id FROM jobs WHERE state IN ('queued','running') LIMIT 1"):
            raise HTTPException(409, "Дождитесь завершения заданий перед сменой подключения")
        try:
            url = normalize_url(body.remnawave_url, cfg)
        except ValueError as e:
            raise HTTPException(400, str(e)) from e
        if body.node_port in {22, 80, 443}:
            raise HTTPException(400, "API-порт ноды не должен совпадать с 22/80/443")
        values = body.model_dump(exclude={"api_token", "telegram_token", "clear_telegram"})
        values["remnawave_url"] = url
        tokens = {}
        previous_url = db.get("integration", {}).get("remnawave_url")
        if (
            previous_url
            and normalize_url(previous_url, cfg) != url
            and not (body.api_token and body.api_token.get_secret_value().strip())
        ):
            raise HTTPException(
                400,
                "При смене URL Remnawave введите новый API-токен. Старый токен нельзя пересылать другому серверу",
            )
        if body.api_token and body.api_token.get_secret_value().strip():
            value = body.api_token.get_secret_value().strip()
            if len(value) < 20 or re.search(r"\s", value):
                raise HTTPException(400, "Проверьте API-токен: без префикса Bearer и пробелов")
            tokens["api_token"] = box.encrypt(value, "setting:api_token")
        elif not db.get("api_token"):
            raise HTTPException(400, "Укажите API-токен Remnawave")
        if body.telegram_token and body.telegram_token.get_secret_value().strip():
            value = body.telegram_token.get_secret_value().strip()
            if not re.fullmatch(r"\d{5,15}:[A-Za-z0-9_-]{20,80}", value):
                raise HTTPException(400, "Проверьте Telegram Bot Token")
            tokens["telegram_token"] = box.encrypt(value, "setting:telegram_token")
        # Store public settings and secrets atomically.
        with db.transaction() as conn:
            for key, value in {"integration": values, **tokens}.items():
                conn.execute(
                    "INSERT INTO settings VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (key, json.dumps(value)),
                )
            if body.clear_telegram:
                conn.execute("DELETE FROM settings WHERE key='telegram_token'")
        db.audit(
            "settings.saved",
            "Секреты обновлены" if tokens else "Параметры обновлены",
            session["username"],
            client_ip(request),
        )
        return public_settings()

    @app.post("/api/settings/test")
    async def settings_test(request: Request):
        session = authorize(request)
        if not db.hit("api-test:" + session["id"], 6, 60):
            raise HTTPException(429, "Повторите проверку через минуту")
        api = services.api()
        metadata = await api.metadata()
        version = str(metadata.get("version", ""))
        if not version.startswith("3."):
            raise HTTPException(400, "Поддерживается Remnawave 3.x")
        nodes = await api.nodes()
        await api.secret_key()
        db.set("api_checked", {"ts": time.time(), "version": version})
        db.audit("api.checked", "Remnawave " + version, session["username"], client_ip(request))
        return {
            "ok": True,
            "version": version,
            "nodes_count": len(nodes),
            "keygen_access": True,
            "note": "Проверены чтение API и keygen. Права создания объектов проверяются при добавлении ноды.",
        }

    @app.get("/api/squads")
    async def squads(request: Request):
        authorize(request)
        if cfg.demo:
            return [
                {
                    "uuid": "d20dc1cc-7ef3-41b7-8183-4551cde25615",
                    "name": "Default-Squad",
                    "inbounds_count": 28,
                }
            ]
        return [
            {"uuid": s["uuid"], "name": s["name"], "inbounds_count": len(s.get("inbounds", []))}
            for s in await services.api().squads()
        ]

    @app.get("/api/template")
    async def template_get(request: Request):
        authorize(request)
        return {"config": template(), "contains_secrets": True}

    @app.put("/api/template")
    async def template_put(body: TemplateInput, request: Request):
        session = authorize(request)
        validate_template(body.config)
        from .versions import save_version

        save_version(db, box, body.config, "Шаблон", session["username"])
        db.set("template", box.encrypt(json.dumps(body.config, ensure_ascii=False), "setting:template"))
        db.audit(
            "template.saved",
            "Шаблон импортирован; содержимое в аудит не записывается",
            session["username"],
            client_ip(request),
        )
        return {"ok": True}

    @app.post("/api/template/preview")
    async def template_preview(body: TemplatePreview, request: Request):
        get_session(request) if cfg.demo else authorize(request)
        return {"config": redact(render_config(template(), body.country, body.ordinal, preview=True))}

    def next_number(country: str) -> int:
        row = db.one("SELECT MAX(ordinal) AS n FROM nodes WHERE country=? AND managed=1", (country,))
        ordinal = (row["n"] or 0) + 1
        while db.one("SELECT id FROM nodes WHERE slug=?", (f"{country.lower()}-{ordinal:02d}",)):
            ordinal += 1
        if ordinal > 9999:
            raise HTTPException(400, "Закончились номера нод для этой страны")
        return ordinal

    def node_public(n: dict) -> dict:
        now = time.time()
        data = json.loads(n["rw_data"])
        metrics = json.loads(n["host_metrics"])
        monitor = db.get("monitor", {})
        stale = (
            False
            if cfg.demo
            else (not monitor.get("online") or now - data.get("seen_at", 0) > cfg.monitor_seconds * 2 + 20)
        )
        if n["state"] in {"pending", "installing", "failed", "missing"}:
            status = n["state"]
        elif stale:
            status = "unknown"
        elif data.get("disabled"):
            status = "disabled"
        elif data.get("connecting"):
            status = "connecting"
        else:
            status = "online" if data.get("connected") else "offline"
        history = db.one(
            "SELECT AVG(connected)*100 AS uptime FROM samples WHERE node_id=? AND ts>?",
            (n["id"], now - 86400),
        )
        latest_job = db.one(
            "SELECT id,state,step,message FROM jobs WHERE node_id=? ORDER BY created DESC LIMIT 1", (n["id"],)
        )
        return {
            "id": n["id"],
            "remnawave_uuid": n["remnawave_uuid"],
            "name": n["name"],
            "slug": n["slug"],
            "country": n["country"],
            "address": n["address"],
            "domain": n["domain"],
            "node_port": n["node_port"],
            "ssh_port": n["ssh_port"],
            "ordinal": n["ordinal"],
            "managed": bool(n["managed"]),
            "install_profile": n.get("install_profile"),
            "tuning": json.loads(n.get("tuning") or "{}"),
            "agent_version": n.get("agent_version"),
            "status": status,
            "stale": stale,
            "state": n["state"],
            "notes": n["notes"],
            "profile_uuid": n["profile_uuid"],
            "cert_expiry": n["cert_expiry"],
            "last_cert_sync": n["last_cert_sync"],
            "created": n["created"],
            "fingerprint": json.loads(n["fingerprint"])["fingerprint"] if n.get("fingerprint") else None,
            "metrics": data,
            "host_metrics": metrics,
            "availability": history["uptime"] if history else None,
            "job": latest_job,
        }

    @app.get("/api/nodes")
    async def nodes_get(request: Request):
        authorize(request)
        return [node_public(n) for n in db.query("SELECT * FROM nodes ORDER BY country,slug LIMIT 2000")]

    @app.get("/api/nodes/export")
    async def nodes_export(request: Request):
        session = authorize(request)
        stream = io.StringIO(newline="")
        writer = csv.writer(stream)
        writer.writerow(["name", "country", "address", "domain", "status", "managed", "notes"])
        for row in db.query("SELECT * FROM nodes ORDER BY country,slug"):
            n = node_public(row)
            cells = [n[k] for k in ("name", "country", "address", "domain", "status", "managed", "notes")]
            writer.writerow(
                ["'" + str(v) if str(v).startswith(("=", "+", "-", "@", "\t", "\r")) else v for v in cells]
            )
        db.audit("inventory.exported", "CSV без SSH/API секретов", session["username"], client_ip(request))
        return Response(
            "\ufeff" + stream.getvalue(),
            media_type="text/csv; charset=utf-8",
            headers={"Content-Disposition": 'attachment; filename="ghostfleet-nodes.csv"'},
        )

    @app.get("/api/dashboard")
    async def dashboard(request: Request):
        authorize(request)
        now = time.time()
        nodes = [node_public(n) for n in db.query("SELECT * FROM nodes ORDER BY country,slug LIMIT 2000")]
        online = [n for n in nodes if n["status"] == "online"]
        chart_rows = db.query(
            "SELECT CAST(ts/900 AS INTEGER)*900 AS bucket,node_id,AVG(users) AS users,AVG(rx) AS rx,AVG(tx) AS tx FROM samples WHERE ts>? GROUP BY bucket,node_id ORDER BY bucket",
            (now - 86400,),
        )
        chart = {}
        for row in chart_rows:
            bucket = row["bucket"]
            if bucket not in chart:
                chart[bucket] = {"ts": bucket, "users": 0, "rx": 0, "tx": 0}
            for key in ("users", "rx", "tx"):
                chart[bucket][key] += row[key] or 0
        summary = {
            "total": len(nodes),
            "online": len(online),
            "offline": sum(n["status"] == "offline" for n in nodes),
            "attention": sum(n["status"] in {"offline", "failed", "missing", "unknown"} for n in nodes),
            "users_online": sum(n["metrics"].get("users_online") or 0 for n in online),
            "traffic_used": sum(n["metrics"].get("traffic_used") or 0 for n in nodes if not n["stale"]),
            "rx": sum(n["metrics"].get("network_rx") or 0 for n in online),
            "tx": sum(n["metrics"].get("network_tx") or 0 for n in online),
        }
        if nodes and not cfg.demo and not db.get("monitor", {}).get("online"):
            for key in ("online", "users_online", "traffic_used", "rx", "tx"):
                summary[key] = None
        return {
            "summary": summary,
            "nodes": nodes,
            "chart": list(chart.values()),
            "monitor": db.get("monitor", {}),
            "settings_ready": bool(db.get("api_token")),
            "template_ready": public_settings()["template_ready"],
            "recent_events": db.query("SELECT * FROM audit ORDER BY id DESC LIMIT 6"),
            "api_checked": db.get("api_checked", {}),
            "demo": cfg.demo,
        }

    @app.post("/api/sync")
    async def sync(request: Request):
        session = authorize(request)
        if not db.hit("sync:" + session["id"], 3, 60):
            raise HTTPException(429, "Подождите перед следующим опросом")
        status = await sync_nodes(services)
        if not status.get("online"):
            raise HTTPException(503, status["error"])
        return status

    @app.post("/api/nodes/probe")
    async def node_probe(body: Probe, request: Request):
        session = authorize(request)
        if not db.hit("probe:" + session["id"], 10, 60):
            raise HTTPException(429, "Не больше 10 SSH-проверок в минуту")
        host = await probe_host(body.address, body.ssh_port, cfg)
        dns = {"ok": False, "message": "Введите домен ноды с A/AAAA-записью"}
        if body.domain:
            try:
                ips = await verify_dns(body.domain, body.address)
                dns = {"ok": True, "addresses": ips, "message": "DNS указывает на ноду"}
            except SSHError as e:
                dns = {"ok": False, "message": str(e)}
        country = None
        if body.detect_country and db.get("integration", {}).get("geoip_enabled"):
            country = await detect_country(body.address)
        challenge_id = str(uuid.uuid4())
        db.execute(
            "INSERT INTO challenges VALUES(?,?,?,?,?,?,?)",
            (
                challenge_id,
                session["id"],
                body.address,
                body.ssh_port,
                host["host_key"],
                host["fingerprint"],
                time.time() + 600,
            ),
        )
        db.audit(
            "ssh.fingerprint_probed",
            f"{body.address}:{body.ssh_port}; без авторизации",
            session["username"],
            client_ip(request),
        )
        return {
            "challenge_id": challenge_id,
            "fingerprint": host["fingerprint"],
            "algorithm": host["algorithm"],
            "dns": dns,
            "country": country,
            "next_ordinal": next_number(country) if country else None,
            "verification_command": "sudo ssh-keygen -lf /etc/ssh/ssh_host_"
            + (
                "ed25519"
                if host["algorithm"] == "ssh-ed25519"
                else "ecdsa"
                if "ecdsa" in host["algorithm"]
                else "rsa"
            )
            + "_key.pub -E sha256",
        }

    def enqueue_deploy(body: DeployRequest, request: Request, session: dict, existing: dict | None = None):
        config = template()
        if body.config_version:
            require_permission(session, "configs.secret")
            version = db.one("SELECT cipher FROM config_versions WHERE id=?", (body.config_version,))
            if not version:
                raise HTTPException(404, "Версия конфига не найдена")
            config = json.loads(box.decrypt(version["cipher"], "config-version:" + body.config_version))
        validate_template(config)
        settings = db.get("integration", {})
        install_options = {}
        if body.install_profile:
            profile = db.one("SELECT data FROM install_profiles WHERE id=?", (body.install_profile,))
            if not profile:
                raise HTTPException(404, "Профиль установки не найден")
            install_options = json.loads(profile["data"])
            tune = install_options.get("tuning", {})
            if (
                tune.get("congestion", "keep") != "keep"
                or tune.get("qdisc", "keep") != "keep"
                or tune.get("egress_mbps") is not None
                or tune.get("disable_shaping")
            ):
                require_permission(session, "nodes.tune")
        if not db.get("api_token") or not all(
            settings.get(k) for k in ("remnawave_url", "email", "remnawave_ips", "manager_ips")
        ):
            raise HTTPException(400, "Заполните настройки Remnawave, email и IP обеих панелей")
        if db.one(
            "SELECT id FROM jobs WHERE state IN ('queued','running') AND node_id=?",
            (existing["id"] if existing else "",),
        ):
            raise HTTPException(409, "Для ноды уже выполняется задание")
        if len(db.query("SELECT id FROM jobs WHERE state IN ('queued','running')")) >= 5:
            raise HTTPException(409, "Очередь ограничена пятью заданиями")
        node_id = existing["id"] if existing else str(uuid.uuid4())
        job_id = str(uuid.uuid4())
        now = time.time()
        payload = {**body.secrets_payload(), "template": config, "install_options": install_options}
        encrypted = box.encrypt(json.dumps(payload), f"job:{job_id}")
        ordinal = existing["ordinal"] if existing else next_number(body.country)
        with db.transaction() as conn:
            maintenance = conn.execute("SELECT value FROM settings WHERE key='maintenance_until'").fetchone()
            if maintenance and json.loads(maintenance["value"]) > now:
                raise HTTPException(503, "Техническое обслуживание: очередь временно закрыта")
            challenge = conn.execute(
                "SELECT * FROM challenges WHERE id=? AND session_id=? AND expires>?",
                (body.challenge_id, session["id"], now),
            ).fetchone()
            if not challenge:
                raise HTTPException(400, "SSH-проверка истекла или уже использована. Выполните её ещё раз")
            if challenge["port"] == settings["node_port"]:
                raise HTTPException(400, "SSH-порт не должен совпадать с API-портом ноды")
            saved = json.dumps({"host_key": challenge["host_key"], "fingerprint": challenge["fingerprint"]})
            if existing:
                if (
                    challenge["address"] != existing["address"]
                    or body.domain != existing["domain"]
                    or body.country != existing["country"]
                ):
                    raise HTTPException(400, "При повторе нельзя менять IP, домен и страну существующей ноды")
                conn.execute(
                    "UPDATE nodes SET fingerprint=?,ssh_port=?,node_port=?,state='pending',updated=? WHERE id=?",
                    (saved, challenge["port"], settings["node_port"], now, node_id),
                )
            else:
                if conn.execute("SELECT id FROM nodes WHERE address=?", (challenge["address"],)).fetchone():
                    raise HTTPException(
                        409, "Этот адрес уже есть в панели. Для неудачной установки используйте «Повторить»"
                    )
                slug = f"{body.country.lower()}-{ordinal:02d}"
                conn.execute(
                    "INSERT INTO nodes(id,slug,name,country,ordinal,address,domain,node_port,ssh_port,fingerprint,managed,state,notes,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (
                        node_id,
                        slug,
                        slug.upper(),
                        body.country,
                        ordinal,
                        challenge["address"],
                        body.domain,
                        settings["node_port"],
                        challenge["port"],
                        saved,
                        1,
                        "pending",
                        body.notes,
                        now,
                        now,
                    ),
                )
            conn.execute("UPDATE nodes SET install_profile=? WHERE id=?", (body.install_profile, node_id))
            conn.execute("DELETE FROM challenges WHERE id=?", (body.challenge_id,))
            conn.execute(
                "INSERT INTO jobs(id,node_id,kind,state,message,payload_cipher,created,updated) VALUES(?,?,?,?,?,?,?,?)",
                (job_id, node_id, "deploy", "queued", "Ожидает запуска", encrypted, now, now),
            )
        db.audit("job.queued", f"deploy / {node_id}", session["username"], client_ip(request))
        services.spawn(job_id)
        return {"node_id": node_id, "job_id": job_id}

    @app.post("/api/nodes", status_code=202)
    async def node_create(body: DeployRequest, request: Request):
        session = authorize(request)
        return enqueue_deploy(body, request, session)

    @app.post("/api/nodes/{node_id}/retry", status_code=202)
    async def node_retry(node_id: str, body: DeployRequest, request: Request):
        session = authorize(request)
        node = db.one("SELECT * FROM nodes WHERE id=?", (node_id,))
        if not node or not node["managed"] or node["state"] != "failed":
            raise HTTPException(400, "Повтор доступен только для неудачной управляемой установки")
        return enqueue_deploy(body, request, session, node)

    @app.get("/api/nodes/{node_id}")
    async def node_details(node_id: str, request: Request):
        authorize(request)
        node = db.one("SELECT * FROM nodes WHERE id=?", (node_id,))
        if not node:
            raise HTTPException(404, "Нода не найдена")
        result = node_public(node)
        result["chart"] = db.query(
            "SELECT CAST(ts/900 AS INTEGER)*900 AS ts,AVG(users) AS users,AVG(rx) AS rx,AVG(tx) AS tx,AVG(connected)*100 AS availability FROM samples WHERE node_id=? AND ts>? GROUP BY CAST(ts/900 AS INTEGER) ORDER BY ts",
            (node_id, time.time() - 86400),
        )
        return result

    @app.get("/api/nodes/{node_id}/config")
    async def node_config(node_id: str, request: Request):
        session = authorize(request)
        node = db.one("SELECT * FROM nodes WHERE id=?", (node_id,))
        if cfg.demo and node:
            return {
                "config": redact(
                    render_config(template(), node["country"], node["ordinal"] or 1, preview=True)
                )
            }
        if not node or not node.get("config_cipher"):
            raise HTTPException(404, "Панель не хранит конфиг этой ноды")
        db.audit("config.viewed", node["slug"] + "; секреты скрыты", session["username"], client_ip(request))
        return {"config": redact(json.loads(box.decrypt(node["config_cipher"], f"node:{node_id}:config")))}

    @app.get("/api/nodes/{node_id}/logs")
    async def node_logs(node_id: str, request: Request):
        session = authorize(request)
        if cfg.demo:
            return {
                "logs": "Демонстрация: реальные логи появятся после установки ноды.\nSSH-пароли и приватные ключи здесь не отображаются."
            }
        if not db.hit("logs:" + session["id"], 6, 60):
            raise HTTPException(429, "Повторите запрос через минуту")
        node = db.one("SELECT * FROM nodes WHERE id=?", (node_id,))
        if not node or not node["managed"] or not node["management_key"]:
            raise HTTPException(400, "Логи доступны только для нод с ограниченным SSH-агентом")
        result = await agent_call(node, box, cfg, "logs")
        db.audit(
            "logs.viewed", node["slug"] + "; содержимое не сохранено", session["username"], client_ip(request)
        )
        return result

    @app.post("/api/nodes/{node_id}/actions", status_code=202)
    async def node_action(node_id: str, body: NodeAction, request: Request):
        session = authorize(request)
        node = db.one("SELECT * FROM nodes WHERE id=?", (node_id,))
        if not node:
            raise HTTPException(404, "Нода не найдена")
        if body.confirm != node["slug"]:
            raise HTTPException(400, "Для подтверждения введите идентификатор ноды")
        if not db.hit("action:" + session["id"], 12, 60):
            raise HTTPException(429, "Слишком много операций")
        if db.one("SELECT id FROM jobs WHERE node_id=? AND state IN ('queued','running')", (node_id,)):
            raise HTTPException(409, "Для этой ноды уже выполняется задание")
        if body.action in {"update", "sync-cert"}:
            require_permission(session, "nodes.install")
            if (
                not node["managed"]
                or not node.get("management_key")
                or node["state"] not in {"active", "waiting"}
            ):
                raise HTTPException(400, "Операция доступна только для установленной управляемой ноды")
            job_id = str(uuid.uuid4())
            payload = (
                {"image": db.get("integration", {}).get("node_image")} if body.action == "update" else {}
            )
            db.execute(
                "INSERT INTO jobs(id,node_id,kind,state,message,payload_cipher,created,updated) VALUES(?,?,?,?,?,?,?,?)",
                (
                    job_id,
                    node_id,
                    body.action,
                    "queued",
                    "Ожидает запуска",
                    box.encrypt(json.dumps(payload), f"job:{job_id}"),
                    time.time(),
                    time.time(),
                ),
            )
            services.spawn(job_id)
            db.audit(
                "node.action", f"{node['slug']} / {body.action}", session["username"], client_ip(request)
            )
            return {"job_id": job_id}
        if not node.get("remnawave_uuid"):
            raise HTTPException(400, "Нода ещё не зарегистрирована в Remnawave")
        await services.api().action(node["remnawave_uuid"], body.action, force=body.force)
        db.audit(
            "node.action",
            f"{node['slug']} / {body.action}" + (" / force" if body.action == "restart" and body.force else ""),
            session["username"],
            client_ip(request),
        )
        return {
            "ok": True,
            "note": "Команда принята Remnawave. Дождитесь следующего опроса для подтверждения статуса.",
        }

    @app.get("/api/jobs")
    async def jobs_get(request: Request):
        authorize(request)
        return db.query(
            "SELECT j.id,j.node_id,j.kind,j.state,j.step,j.message,j.created,j.updated,n.name,n.slug FROM jobs j JOIN nodes n ON n.id=j.node_id ORDER BY j.created DESC LIMIT 200"
        )

    @app.get("/api/jobs/{job_id}")
    async def job_get(job_id: str, request: Request):
        authorize(request)
        job = db.one(
            "SELECT id,node_id,kind,state,step,message,logs,created,updated FROM jobs WHERE id=?", (job_id,)
        )
        if not job:
            raise HTTPException(404, "Задание не найдено")
        job["logs"] = json.loads(job["logs"])
        return job

    @app.get("/api/audit")
    async def audit_get(request: Request, limit: int = Query(default=200, ge=1, le=1000)):
        authorize(request)
        return db.query("SELECT * FROM audit ORDER BY id DESC LIMIT ?", (limit,))

    from .extensions import extension_router

    app.include_router(extension_router())

    @app.get("/")
    async def index():
        return FileResponse(ROOT / "app/static/index.html")

    app.mount("/static", StaticFiles(directory=ROOT / "app/static"), name="static")
    return app


# uvicorn uses the factory so merely importing modules never initialises production state.
