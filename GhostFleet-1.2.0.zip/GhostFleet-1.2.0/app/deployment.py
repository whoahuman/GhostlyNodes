from __future__ import annotations

import asyncio
import hashlib
import json
import re
import shlex
import time
import uuid

import asyncssh

from .config import ROOT
from .notify import notify
from .remnawave import Remnawave, RemnawaveError
from .ssh import SSHError, agent_call, clean_remote_path, connect, new_management_key, verify_dns
from .template import TemplateError, parse_certificate, render_config, replace_certificates, validate_template
from .upstream import fetch_acme, fetch_installer


class Services:
    def __init__(self, db, box, cfg):
        self.db = db
        self.box = box
        self.cfg = cfg
        self.queue_lock = asyncio.Semaphore(1)
        self.tasks: set[asyncio.Task] = set()
        self.sync_lock = asyncio.Lock()
        self.maintenance_lock = asyncio.Lock()

    def api(self) -> Remnawave:
        settings = self.db.get("integration", {})
        token = self.db.get("api_token")
        if not settings.get("remnawave_url") or not token:
            raise RemnawaveError("Сначала настройте подключение к Remnawave")
        return Remnawave(settings["remnawave_url"], self.box.decrypt(token, "setting:api_token"), self.cfg)

    def spawn(self, job_id: str) -> None:
        task = asyncio.create_task(self.run_job(job_id), name=f"job:{job_id}")
        self.tasks.add(task)
        task.add_done_callback(self.tasks.discard)

    async def shutdown(self) -> None:
        for task in list(self.tasks):
            task.cancel()
        if self.tasks:
            await asyncio.gather(*self.tasks, return_exceptions=True)

    async def run_job(self, job_id: str) -> None:
        async with self.queue_lock:
            job = self.db.one("SELECT * FROM jobs WHERE id=?", (job_id,))
            if not job or job["state"] != "queued":
                return
            self.db.job_progress(job_id, 2, "Задание запущено", "running")
            try:
                params = json.loads(self.box.decrypt(job["payload_cipher"], f"job:{job_id}"))
                if job["kind"] == "deploy":
                    await self.deploy(job, params)
                elif job["kind"] == "update":
                    node = self.db.one("SELECT * FROM nodes WHERE id=?", (job["node_id"],))
                    self.db.job_progress(job_id, 25, "Загрузка проверенного образа и пересоздание контейнера")
                    await agent_call(node, self.box, self.cfg, "update", {"image": params["image"]})
                    self.db.job_progress(
                        job_id, 100, "Контейнер обновлён. Статус подтвердится следующим опросом", "completed"
                    )
                    self.db.audit("node.updated", node["slug"])
                elif job["kind"] == "tune":
                    node = self.db.one("SELECT * FROM nodes WHERE id=?", (job["node_id"],))
                    self.db.job_progress(
                        job_id, 30, "Создаём 90-секундный watchdog и применяем curated профиль"
                    )
                    result = await agent_call(node, self.box, self.cfg, "tune", params)
                    if result.get("pending"):
                        self.db.job_progress(
                            job_id, 75, "Проверяем повторный SSH-доступ перед подтверждением"
                        )
                        await agent_call(node, self.box, self.cfg, "health")
                        ack = await agent_call(
                            node, self.box, self.cfg, "tune-confirm", {"nonce": result["pending"]}
                        )
                        if not ack.get("confirmed"):
                            raise SSHError("Тюнинг не подтверждён; ожидается автоматический rollback")
                    self.db.execute("UPDATE nodes SET tuning=? WHERE id=?", (json.dumps(params), node["id"]))
                    self.db.job_progress(
                        job_id,
                        100,
                        "Профиль применён, SSH подтверждён. Проверьте data-plane тестовым клиентом",
                        "completed",
                    )
                    self.db.audit("node.tuned", node["slug"])
                elif job["kind"] == "sync-cert":
                    self.db.job_progress(job_id, 30, "Проверка сертификата на ноде")
                    node = self.db.one("SELECT * FROM nodes WHERE id=?", (job["node_id"],))
                    await self.sync_certificate(node, force=True)
                    self.db.job_progress(
                        job_id, 100, "TLS-сертификат проверен и синхронизирован", "completed"
                    )
                await notify(
                    self.db, self.box, self.cfg, f"Задание завершено: {job['kind']} · {job['node_id']}"
                )
            except asyncio.CancelledError:
                self.db.job_progress(
                    job_id,
                    0,
                    "Панель остановлена. Проверьте частичную установку перед повтором",
                    "interrupted",
                )
                if job["kind"] == "deploy":
                    self.db.execute(
                        "UPDATE nodes SET state='failed',updated=? WHERE id=?", (time.time(), job["node_id"])
                    )
                raise
            except Exception as e:
                safe = (
                    str(e)
                    if isinstance(e, (SSHError, TemplateError, RemnawaveError))
                    else "Внутренняя ошибка задания. Проверьте systemctl status ghostfleet и локальный журнал ноды; секреты в журнал панели не выводятся."
                )
                persisted = self.db.one("SELECT step FROM jobs WHERE id=?", (job_id,))
                self.db.job_progress(job_id, persisted["step"] if persisted else job["step"], safe, "failed")
                if job["kind"] == "deploy":
                    self.db.execute(
                        "UPDATE nodes SET state='failed',updated=? WHERE id=?", (time.time(), job["node_id"])
                    )
                self.db.audit("job.failed", f"{job['kind']} / {job['node_id']} / {type(e).__name__}")
                await notify(self.db, self.box, self.cfg, f"Ошибка задания {job['kind']}: {safe}")
            finally:
                # Installation credentials are never retained for monitoring or a retry.
                self.db.execute("UPDATE jobs SET payload_cipher=NULL WHERE id=?", (job_id,))

    def profile_name(self, node: dict) -> str:
        # Globally unique within Remnawave: do not reuse generic GF-DE-01 names.
        # 96-bit scoped suffix; all valid profile names fit the server's 30-char limit.
        scope = str(self.db.get("instance_id")) + ":" + node["id"]
        suffix = hashlib.sha256(scope.encode()).hexdigest()[:24]
        return "GF-" + suffix

    async def configure_profile(self, node: dict, config: dict) -> dict:
        api = self.api()
        if node.get("profile_uuid"):
            profile = await api.profile(node["profile_uuid"])
            if any(n.get("uuid") != node.get("remnawave_uuid") for n in profile.get("nodes", [])):
                raise RemnawaveError("Профиль используется другой нодой; не перезаписываю общий профиль")
            return await api.update_profile(node["profile_uuid"], config)
        name = self.profile_name(node)
        try:
            profile = await api.create_profile(name, config)
        except RemnawaveError as error:
            if error.status_code != 409 or error.path != "/config-profiles":
                raise
            # A POST can succeed while its response is lost. Only reclaim an exact scoped
            # match with identical configuration and explicit empty/current-owned node list.
            matches = [p for p in await api.profiles() if p.get("name") == name]
            if len(matches) != 1:
                raise RemnawaveError(
                    "HTTP 409 создания Config Profile. Scoped профиль не удалось однозначно найти; ничего не удалено"
                ) from error
            profile = await api.profile(matches[0]["uuid"])
            nodes = profile.get("nodes")
            same_nodes = isinstance(nodes, list) and (
                not nodes
                or bool(node.get("remnawave_uuid"))
                and all(isinstance(n, dict) and n.get("uuid") == node["remnawave_uuid"] for n in nodes)
            )
            if profile.get("name") != name or profile.get("config") != config or not same_nodes:
                raise RemnawaveError(
                    "HTTP 409: найден профиль, но его конфиг/принадлежность не совпадают. Чужой профиль не изменён"
                ) from error
        # Commit identity immediately, even if the following details/validation request fails.
        profile_uuid = str(uuid.UUID(profile["uuid"]))
        self.db.execute("UPDATE nodes SET profile_uuid=? WHERE id=?", (profile_uuid, node["id"]))
        node["profile_uuid"] = profile_uuid
        if not profile.get("inbounds"):
            profile = await api.profile(profile_uuid)
        return profile

    async def deploy(self, job: dict, params: dict) -> None:
        job_id = job["id"]
        node = self.db.one("SELECT * FROM nodes WHERE id=?", (job["node_id"],))
        settings = self.db.get("integration")
        api = self.api()
        template = params.pop("template")
        validate_template(template)
        self.db.execute("UPDATE nodes SET state='installing',updated=? WHERE id=?", (time.time(), node["id"]))
        self.db.job_progress(job_id, 5, "Проверка API, уникальности ноды и DNS")
        metadata = await api.metadata()
        if not str(metadata.get("version", "")).startswith("3."):
            raise RemnawaveError("Нужен Remnawave 3.x; автоматические изменения остановлены")
        remote_nodes = await api.nodes()
        if any(
            n.get("uuid") != node.get("remnawave_uuid")
            and (n.get("address") == node["address"] or n.get("name") == node["name"])
            for n in remote_nodes
        ):
            raise RemnawaveError(
                "В Remnawave уже существует другая нода с этим адресом или именем. Не перезаписываю её"
            )
        await verify_dns(node["domain"], node["address"])
        try:
            upstream = await fetch_installer()
            acme_archive = await fetch_acme()
        except Exception as e:
            raise SSHError(
                "Не удалось загрузить pinned Ghostly/acme.sh или SHA256 не совпал. Установка заблокирована"
            ) from e
        secret_key = await api.secret_key()
        if node.get("management_key"):
            private_key = self.box.decrypt(node["management_key"], f"node:{node['id']}:key")
            management_public = (
                asyncssh.import_private_key(private_key).export_public_key("openssh").decode().strip()
            )
        else:
            private_key, management_public = new_management_key()
            encrypted_key = self.box.encrypt(private_key, f"node:{node['id']}:key")
            self.db.execute("UPDATE nodes SET management_key=? WHERE id=?", (encrypted_key, node["id"]))
            node["management_key"] = encrypted_key
        approved = json.loads(node["fingerprint"])
        install_params = {
            "instance_id": self.db.get("instance_id"),
            "node_id": node["id"],
            "name": node["name"],
            "domain": node["domain"],
            "email": settings["email"],
            "node_port": node["node_port"],
            "ssh_port": node["ssh_port"],
            "remnawave_ips": settings["remnawave_ips"],
            "manager_ips": settings["manager_ips"],
            "node_image": params.get("install_options", {}).get("node_image") or settings["node_image"],
            "management_public_key": management_public,
            "secret_key": secret_key,
            "options": params.get("install_options", {}),
        }
        self.db.job_progress(job_id, 12, "SSH: проверка закреплённого host key и доставка адаптера")
        async with connect(node["address"], node["ssh_port"], approved["host_key"], params, self.cfg) as conn:
            uid_result = await conn.run("id -u", check=False, timeout=10)
            if uid_result.exit_status or not uid_result.stdout.strip().isdigit():
                raise SSHError("Не удалось определить права SSH-пользователя")
            is_root = uid_result.stdout.strip() == "0"
            # remote UUID128 path; mkdir -m 700 refuses collisions
            remote_dir = clean_remote_path("/tmp/gf-" + uuid.uuid4().hex)  # nosec B108
            mkdir = await conn.run("mkdir -m 700 -- " + shlex.quote(remote_dir), check=False, timeout=10)
            if mkdir.exit_status:
                raise SSHError("Не удалось создать защищённый временный каталог на ноде")
            try:
                files = {
                    "upstream.sh": upstream,
                    "acme.tar.gz": acme_archive,
                    "bootstrap.sh": (ROOT / "node/bootstrap.sh").read_bytes(),
                    "agent.py": (ROOT / "node/agent.py").read_bytes(),
                    "params.json": json.dumps(install_params).encode(),
                }
                async with conn.start_sftp_client() as sftp:
                    for name, content in files.items():
                        async with sftp.open(remote_dir + "/" + name, "wb") as file:
                            await file.write(content)
                        await sftp.chmod(remote_dir + "/" + name, 0o600)
                # Drop the panel's local reference to the node API shared key ASAP.
                install_params.clear()
                # discard the already-used runtime key, not a hardcoded credential
                secret_key = ""  # nosec B105
                command = "bash " + shlex.quote(remote_dir + "/bootstrap.sh")
                input_data = ""
                if not is_root:
                    sudo_check = await conn.run("sudo -n true", check=False, timeout=10)
                    if sudo_check.exit_status == 0:
                        command = "sudo -n -- " + command
                    else:
                        sudo_password = params.get("sudo_password") or params.get("password") or ""
                        if not sudo_password or "\n" in sudo_password or "\r" in sudo_password:
                            raise SSHError("Нужен пароль sudo или NOPASSWD sudo для SSH-пользователя")
                        command = "sudo -S -p '' -- " + command
                        input_data = sudo_password + "\n"
                process = await conn.create_process(command, input=input_data)

                reported_markers = set()

                async def drain(reader, markers: bool = False):
                    carry = ""
                    while chunk := await reader.read(8192):
                        if markers:
                            text = carry + chunk
                            for found in re.findall(r"(?:^|\n)GF_STEP ([234])(?:\r?\n|$)", text):
                                if found in reported_markers:
                                    continue
                                reported_markers.add(found)
                                stages = {
                                    "2": (20, "Подготовка ОС и Docker без перезаписи daemon.json"),
                                    "3": (35, "Ghostly: firewall, TLS-сертификат и Remnanode"),
                                    "4": (60, "Установка ограниченного SSH-агента и pinned-образа"),
                                }
                                step, message = stages[found]
                                self.db.job_progress(job_id, step, message)
                            carry = text[-32:]
                        # Raw installer output is deliberately discarded, not put in a job or audit log.

                drains = [
                    asyncio.create_task(drain(process.stdout, True)),
                    asyncio.create_task(drain(process.stderr)),
                ]
                try:
                    await asyncio.wait_for(process.wait_closed(), timeout=1800)
                    await asyncio.gather(*drains)
                finally:
                    for task in drains:
                        if not task.done():
                            task.cancel()
                    await asyncio.gather(*drains, return_exceptions=True)
                if process.exit_status != 0:
                    codes = {
                        72: "Неподдерживаемая ОС",
                        73: "Установка на ноде уже выполняется",
                        74: "На сервере найдена чужая Remnanode: перезапись запрещена",
                        75: "Изменился ключ подписи Docker — нужна проверка",
                        77: "На ноде нет Docker Compose v2",
                        78: "Сертификат не выпущен. Проверьте DNS и доступность TCP/80 из интернета",
                        79: "acme.sh не прошёл проверку целостности/установки",
                        80: "Контейнер remnanode не запущен. Проверьте docker compose и локальный журнал ноды",
                    }
                    hint = codes.get(
                        process.exit_status,
                        "Проверьте sudo, DNS, свободный TCP/80 и /var/log/ghostly-installer.log через собственный SSH",
                    )
                    raise SSHError(f"Установщик завершился с кодом {process.exit_status}. {hint}")
            finally:
                # bootstrap removes root-owned files itself; before bootstrap these belong to the SSH user.
                try:
                    await conn.run("rm -rf -- " + shlex.quote(remote_dir), check=False, timeout=10)
                except (asyncssh.Error, OSError):
                    pass
        self.db.job_progress(job_id, 70, "Проверка ограниченного SSH-ключа и TLS-сертификата")
        node = self.db.one("SELECT * FROM nodes WHERE id=?", (node["id"],))
        health = await agent_call(node, self.box, self.cfg, "health")
        if (
            health.get("instance_id") != self.db.get("instance_id")
            or health.get("node_id") != node["id"]
            or not health.get("installed")
        ):
            raise SSHError("SSH-агент не подтвердил принадлежность ноды этой панели")
        options = params.get("install_options", {})
        tuning = options.get("tuning", {})
        if tuning and (
            tuning.get("congestion", "keep") != "keep"
            or tuning.get("qdisc", "keep") != "keep"
            or tuning.get("egress_mbps") is not None
            or tuning.get("disable_shaping")
        ):
            result = await agent_call(node, self.box, self.cfg, "tune", tuning)
            if result.get("pending"):
                await agent_call(node, self.box, self.cfg, "health")
                ack = await agent_call(node, self.box, self.cfg, "tune-confirm", {"nonce": result["pending"]})
                if not ack.get("confirmed"):
                    raise SSHError("Тюнинг не подтверждён; watchdog вернёт параметры")
            self.db.execute(
                "UPDATE nodes SET tuning=?,agent_version='1.1.0' WHERE id=?", (json.dumps(tuning), node["id"])
            )
        pem = await agent_call(node, self.box, self.cfg, "certificates")
        cert = parse_certificate(pem["fullchain"], pem["private_key"], node["domain"])
        config = render_config(template, node["country"], node["ordinal"], cert=cert)
        self.db.job_progress(job_id, 80, "Создание Config Profile и назначение inbound в Remnawave")
        profile = await self.configure_profile(node, config)
        expected_tags = {i["tag"] for i in config["inbounds"]}
        actual_tags = {i["tag"] for i in profile.get("inbounds", [])}
        if actual_tags != expected_tags:
            raise RemnawaveError(
                "Remnawave не вернул все inbound, включая Hysteria2. Проверьте совместимость версии ядра и панели"
            )
        inbound_uuids = [i["uuid"] for i in profile["inbounds"]]
        if node.get("remnawave_uuid"):
            registered = await api.update_node(node["remnawave_uuid"], profile["uuid"], inbound_uuids)
        else:
            registered = await api.create_node(node, profile["uuid"], inbound_uuids)
            self.db.execute("UPDATE nodes SET remnawave_uuid=? WHERE id=?", (registered["uuid"], node["id"]))
            node["remnawave_uuid"] = registered["uuid"]
        self.db.execute(
            "UPDATE nodes SET config_cipher=?,inbound_uuids=?,cert_hash=?,cert_expiry=?,last_cert_sync=? WHERE id=?",
            (
                self.box.encrypt(json.dumps(config), f"node:{node['id']}:config"),
                json.dumps(inbound_uuids),
                cert["hash"],
                cert["expires"],
                time.time(),
                node["id"],
            ),
        )
        self.db.job_progress(job_id, 90, "Привязка выбранных Internal Squads и создание Hosts")
        # Serialise all read/merge/write squad operations performed by this panel.
        async with self.maintenance_lock:
            squads = settings.get("squad_uuids", [])
            await api.add_inbounds_to_squads(squads, inbound_uuids)
            self.db.execute("UPDATE nodes SET squad_uuids=? WHERE id=?", (json.dumps(squads), node["id"]))
            if settings.get("create_hosts"):
                host_ids = await api.create_hosts(node, profile, config, json.loads(node["host_uuids"]))
                self.db.execute(
                    "UPDATE nodes SET host_uuids=? WHERE id=?", (json.dumps(host_ids), node["id"])
                )
        await api.action(registered["uuid"], "restart")
        self.db.execute("UPDATE nodes SET state='waiting',updated=? WHERE id=?", (time.time(), node["id"]))
        self.db.job_progress(
            job_id,
            100,
            "Нода установлена и зарегистрирована. Ожидаем подтверждения online от Remnawave",
            "completed",
        )
        self.db.audit("node.deployed", f"{node['slug']} / {node['address']}; SSH-пароль удалён")

    async def sync_certificate(self, node: dict, force: bool = False) -> None:
        if not node.get("profile_uuid") or not node.get("config_cipher"):
            return
        async with self.maintenance_lock:
            pem = await agent_call(node, self.box, self.cfg, "certificates")
            cert = parse_certificate(pem["fullchain"], pem["private_key"], node["domain"])
            if not force and cert["hash"] == node.get("cert_hash"):
                self.db.execute(
                    "UPDATE nodes SET last_cert_sync=?,cert_expiry=? WHERE id=?",
                    (time.time(), cert["expires"], node["id"]),
                )
                return
            api = self.api()
            remote = await api.profile(node["profile_uuid"])
            if any(n.get("uuid") != node.get("remnawave_uuid") for n in remote.get("nodes", [])):
                raise RemnawaveError(
                    "TLS-профиль используется другими нодами; автоматическая синхронизация запрещена"
                )
            previous = json.loads(self.box.decrypt(node["config_cipher"], f"node:{node['id']}:config"))
            tags = {i["tag"] for i in previous["inbounds"]}
            updated = replace_certificates(remote["config"], tags, cert)
            await api.update_profile(node["profile_uuid"], updated)
            # The patch changes only certificates, never overwrites manual routing edits.
            self.db.execute(
                "UPDATE nodes SET config_cipher=?,cert_hash=?,cert_expiry=?,last_cert_sync=? WHERE id=?",
                (
                    self.box.encrypt(json.dumps(updated), f"node:{node['id']}:config"),
                    cert["hash"],
                    cert["expires"],
                    time.time(),
                    node["id"],
                ),
            )
            self.db.audit("certificate.synced", node["slug"])
