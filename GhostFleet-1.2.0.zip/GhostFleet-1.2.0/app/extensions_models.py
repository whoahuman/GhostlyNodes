from __future__ import annotations

import ipaddress
import re
from typing import Literal

from pydantic import Field, SecretStr, field_validator, model_validator

from .rbac import ALL, ROLES, SERVICE_SCOPES
from .schemas import IMAGE_PATTERN, NODE_IMAGE, StrictModel, cidr_list, domain_name


def networks(values: list[str], required=False) -> list[str]:
    if not values:
        if required:
            raise ValueError("Требуется непустой список IP/CIDR")
        return []
    return cidr_list(",".join(values)).split(",")


class Elevate(StrictModel):
    password: SecretStr = Field(min_length=1, max_length=256)
    code: str = Field(min_length=6, max_length=40)


class StaffCreate(StrictModel):
    username: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,64}$")
    password: SecretStr = Field(min_length=12, max_length=256)
    role: Literal["owner", "admin", "operator", "viewer", "dns"] = "viewer"
    permissions: list[str] | None = None
    allowed_cidrs: list[str] = Field(default_factory=list, max_length=40)

    @field_validator("allowed_cidrs")
    @classmethod
    def nets(cls, v):
        return networks(v)

    @field_validator("permissions")
    @classmethod
    def caps(cls, v):
        if v is not None and (len(v) > len(ALL) or set(v) - ALL):
            raise ValueError("Неизвестные права")
        return sorted(set(v)) if v is not None else None

    @model_validator(mode="after")
    def role_caps(self):
        if self.role == "owner" and self.permissions is not None:
            raise ValueError("Права владельца не урезаются")
        if self.permissions is not None and set(self.permissions) - ROLES[self.role]:
            raise ValueError("Права выше выбранной роли")
        return self


class StaffEdit(StrictModel):
    role: Literal["owner", "admin", "operator", "viewer", "dns"]
    permissions: list[str] | None = None
    active: bool = True
    allowed_cidrs: list[str] = Field(default_factory=list, max_length=40)

    @field_validator("allowed_cidrs")
    @classmethod
    def nets(cls, v):
        return networks(v)

    @model_validator(mode="after")
    def valid(self):
        if self.role == "owner" and self.permissions is not None:
            raise ValueError("Права владельца не урезаются")
        if self.permissions is not None and set(self.permissions) - ROLES[self.role]:
            raise ValueError("Права выше выбранной роли")
        return self


class AccessPolicy(StrictModel):
    cidrs: list[str] = Field(min_length=1, max_length=60)
    confirm: Literal["ALLOWLIST"]

    @field_validator("cidrs")
    @classmethod
    def nets(cls, v):
        return networks(v, True)


class ServiceCreate(StrictModel):
    name: str = Field(pattern=r"^[A-Za-z0-9_.-]{2,64}$")
    scopes: list[str] = Field(min_length=1, max_length=20)
    allowed_cidrs: list[str] = Field(min_length=1, max_length=40)
    days: int = Field(default=30, ge=1, le=365)

    @field_validator("allowed_cidrs")
    @classmethod
    def nets(cls, v):
        return networks(v, True)

    @field_validator("scopes")
    @classmethod
    def caps(cls, v):
        if set(v) - SERVICE_SCOPES:
            raise ValueError("Сервисам не выдаются права staff/access/secrets/bootstrap")
        return sorted(set(v))


class CloudSettings(StrictModel):
    token: SecretStr | None = Field(default=None, min_length=20, max_length=256)
    allowed_zones: list[str] = Field(default_factory=list, max_length=60)
    clear: bool = False

    @field_validator("allowed_zones")
    @classmethod
    def zones(cls, v):
        if any(not re.fullmatch(r"[a-f0-9]{32}", x) for x in v):
            raise ValueError("Zone ID: 32 hex символа")
        return sorted(set(v))


class DnsRecord(StrictModel):
    zone_id: str = Field(pattern=r"^[a-f0-9]{32}$")
    name: str = Field(max_length=253)
    address: str = Field(max_length=50)
    ttl: int = Field(default=300, ge=60, le=86400)
    replace: bool = False

    @field_validator("name")
    @classmethod
    def name_ok(cls, v):
        return domain_name(v)

    @field_validator("address")
    @classmethod
    def ip_ok(cls, v):
        return str(ipaddress.ip_address(v))


class SharingPolicy(StrictModel):
    enabled: bool = False
    threshold_devices: int = Field(default=3, ge=1, le=100)
    consecutive_samples: int = Field(default=2, ge=1, le=12)
    poll_seconds: int = Field(default=300, ge=300, le=3600)
    inspect_limit: int = Field(default=100, ge=10, le=500)
    telegram: bool = True
    mode: Literal["observe"] = "observe"
    exclusions: list[str] = Field(default_factory=list, max_length=200)


class UserOperation(StrictModel):
    action: Literal["enable", "disable", "reset-traffic", "hwid-limit"]
    confirm: str = Field(max_length=64)
    device_limit: int | None = Field(default=None, ge=1, le=100)


class TuneSettings(StrictModel):
    congestion: Literal["keep", "cubic", "bbr"] = "keep"
    qdisc: Literal["keep", "fq", "fq_codel"] = "keep"
    egress_mbps: int | None = Field(default=None, ge=10, le=100000)
    shaping_confirmed: bool = False
    disable_shaping: bool = False

    @model_validator(mode="after")
    def confirmed(self):
        if self.disable_shaping and self.egress_mbps is not None:
            raise ValueError("Нельзя одновременно включить и снять shaping")
        if self.disable_shaping and not self.shaping_confirmed:
            raise ValueError("Для снятия собственного shaping нужно подтверждение")
        if self.egress_mbps is not None and not self.shaping_confirmed:
            raise ValueError("Нужно явно подтвердить egress shaping; затрагивает интерфейс VPS")
        return self


class InstallProfile(StrictModel):
    name: str = Field(min_length=2, max_length=60)
    description: str = Field(default="", max_length=400)
    node_image: str = NODE_IMAGE
    tuning: TuneSettings = Field(default_factory=TuneSettings)
    fail2ban: bool = True
    flood: bool = True

    @field_validator("node_image")
    @classmethod
    def image(cls, v):
        if not IMAGE_PATTERN.fullmatch(v):
            raise ValueError("Только образ remnawave/node")
        return v


class NodeTune(StrictModel):
    confirm: str = Field(max_length=50)
    tuning: TuneSettings


class VersionSave(StrictModel):
    name: str = Field(min_length=2, max_length=80)
    config: dict


class NotificationRules(StrictModel):
    offline: bool = True
    recovery: bool = True
    tls: bool = True
    jobs: bool = True
    sharing: bool = True
    offline_samples: int = Field(default=2, ge=2, le=10)
