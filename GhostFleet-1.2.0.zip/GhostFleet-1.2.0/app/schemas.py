from __future__ import annotations

import ipaddress
import re
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, SecretStr, field_validator, model_validator

COUNTRY_CODES = set(
    "AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW XX".split()
)
NODE_IMAGE = "remnawave/node:3.4.1@sha256:0cdf386dd49f360fc885bb34bde21132e478e40f0deac62d616086ec0fa9257e"
IMAGE_PATTERN = re.compile(r"^remnawave/node:(?:[0-9]+\.[0-9]+\.[0-9]+|latest)(?:@sha256:[a-f0-9]{64})?$")


def domain_name(value: str) -> str:
    value = value.strip().rstrip(".").lower()
    try:
        value = value.encode("idna").decode("ascii")
    except UnicodeError as e:
        raise ValueError("Недопустимый домен") from e
    labels = value.split(".")
    if (
        len(value) > 253
        or len(labels) < 2
        or any(not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label) for label in labels)
    ):
        raise ValueError("Укажите FQDN, например pl-01.nodes.example.com")
    try:
        ipaddress.ip_address(value)
    except ValueError:
        return value
    raise ValueError("Для TLS нужен домен, а не IP")


def cidr_list(value: str) -> str:
    result = []
    for part in value.split(","):
        if not part.strip():
            continue
        net = ipaddress.ip_network(part.strip(), strict=False)
        if (
            net.prefixlen == 0
            or net.network_address.is_loopback
            or net.network_address.is_multicast
            or net.network_address.is_link_local
        ):
            raise ValueError("Нельзя разрешать /0, loopback, link-local или multicast")
        result.append(str(net))
    if not result:
        raise ValueError("Нужен хотя бы один IP/CIDR")
    return ",".join(result)


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Login(StrictModel):
    username: str = Field(min_length=1, max_length=64)
    password: SecretStr = Field(min_length=1, max_length=256)
    code: str = Field(default="", max_length=40)


class OtpCode(StrictModel):
    code: str = Field(min_length=6, max_length=6, pattern=r"^\d{6}$")


class PasswordChange(StrictModel):
    old_password: SecretStr = Field(min_length=1, max_length=256)
    new_password: SecretStr = Field(min_length=12, max_length=256)
    code: str = Field(min_length=6, max_length=40)


class SettingsUpdate(StrictModel):
    remnawave_url: str = Field(max_length=300)
    api_token: SecretStr | None = Field(default=None, max_length=10000)
    remnawave_ips: str = Field(max_length=1000)
    manager_ips: str = Field(max_length=1000)
    email: str = Field(max_length=254)
    base_domain: str = Field(default="", max_length=253)
    node_port: int = Field(default=2222, ge=1, le=65535)
    node_image: str = NODE_IMAGE
    geoip_enabled: bool = False
    create_hosts: bool = True
    squad_uuids: list[str] = Field(default_factory=list, max_length=50)
    telegram_token: SecretStr | None = Field(default=None, max_length=200)
    telegram_chat_id: str = Field(default="", max_length=40)
    clear_telegram: bool = False

    @field_validator("email")
    @classmethod
    def valid_email(cls, value):
        if not re.fullmatch(r"[A-Za-z0-9.!%+_-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,63}", value):
            raise ValueError("Проверьте email для Let's Encrypt")
        return value

    @field_validator("remnawave_ips", "manager_ips")
    @classmethod
    def valid_ips(cls, value):
        return cidr_list(value)

    @field_validator("base_domain")
    @classmethod
    def valid_domain(cls, value):
        return domain_name(value) if value else ""

    @field_validator("node_image")
    @classmethod
    def valid_image(cls, value):
        if not IMAGE_PATTERN.fullmatch(value):
            raise ValueError("Разрешён только remnawave/node:<version>[@sha256:<digest>]")
        return value

    @field_validator("squad_uuids")
    @classmethod
    def valid_squads(cls, values):
        import uuid

        return list(dict.fromkeys(str(uuid.UUID(v)) for v in values))

    @field_validator("telegram_chat_id")
    @classmethod
    def valid_chat(cls, value):
        if value and not re.fullmatch(r"-?\d{1,30}", value):
            raise ValueError("Chat ID должен быть числом")
        return value


class Probe(StrictModel):
    address: str = Field(max_length=50)
    ssh_port: int = Field(default=22, ge=1, le=65535)
    domain: str = Field(default="", max_length=253)
    detect_country: bool = False

    @field_validator("address")
    @classmethod
    def valid_ip(cls, value):
        return str(ipaddress.ip_address(value.strip().strip("[]")))

    @field_validator("domain")
    @classmethod
    def valid_domain(cls, value):
        return domain_name(value) if value else ""


class DeployRequest(StrictModel):
    install_profile: str | None = Field(default=None, pattern=r"^[a-f0-9-]{36}$")
    config_version: str | None = Field(default=None, pattern=r"^[a-f0-9-]{36}$")
    challenge_id: str = Field(pattern=r"^[a-f0-9-]{36}$")
    approve_host_key: Literal[True]
    username: str = Field(default="root", pattern=r"^[a-z_][a-z0-9_-]{0,31}$")
    password: SecretStr | None = Field(default=None, max_length=4096)
    private_key: SecretStr | None = Field(default=None, max_length=20000)
    key_passphrase: SecretStr | None = Field(default=None, max_length=4096)
    sudo_password: SecretStr | None = Field(default=None, max_length=4096)
    country: str = "XX"
    domain: str = Field(max_length=253)
    notes: str = Field(default="", max_length=500)

    @field_validator("country")
    @classmethod
    def valid_country(cls, value):
        value = value.upper().strip()
        if value not in COUNTRY_CODES:
            raise ValueError("Нужен ISO 3166-1 alpha-2 код страны")
        return value

    @field_validator("domain")
    @classmethod
    def valid_domain(cls, value):
        return domain_name(value)

    @model_validator(mode="after")
    def authentication_present(self):
        if not (self.password and self.password.get_secret_value()) and not (
            self.private_key and self.private_key.get_secret_value()
        ):
            raise ValueError("Укажите SSH-пароль либо приватный SSH-ключ")
        for field in (self.sudo_password, self.password if self.username != "root" else None):
            if field and "\n" in field.get_secret_value():
                raise ValueError("Пароль sudo не может содержать перенос строки")
        return self

    def secrets_payload(self) -> dict:
        result = self.model_dump(
            exclude={
                "challenge_id",
                "approve_host_key",
                "country",
                "domain",
                "notes",
                "install_profile",
                "config_version",
            }
        )
        return {k: v.get_secret_value() if isinstance(v, SecretStr) else v for k, v in result.items()}


class NodeAction(StrictModel):
    action: Literal["enable", "disable", "restart", "update", "sync-cert"]
    confirm: str = Field(max_length=50)
    force: bool = False


class TemplateInput(StrictModel):
    config: dict


class TemplatePreview(StrictModel):
    country: str = Field(default="DE", pattern=r"^[A-Z]{2}$")
    ordinal: int = Field(default=1, ge=1, le=9999)
