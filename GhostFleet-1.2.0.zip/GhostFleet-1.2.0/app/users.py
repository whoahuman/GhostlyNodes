from __future__ import annotations

import json
import time
import uuid

from .notify import notify
from .remnawave import RemnawaveError


def identity(raw: dict) -> str:
    if type(raw.get("id")) is int and raw["id"] > 0:
        return str(raw["id"])
    return str(uuid.UUID(raw["uuid"]))


def safe_user(raw: dict, now: float) -> dict:
    # subscriptionUrl/vlessUuid/ssPassword/trojanPassword/shortUuid never enter local cache or browser.
    traffic = raw.get("userTraffic") or {}
    data = {
        "identity": identity(raw),
        "username": str(raw.get("username", ""))[:64],
        "status": str(raw.get("status", "UNKNOWN"))[:24],
        "traffic_used": numeric(traffic.get("usedTrafficBytes", raw.get("usedTrafficBytes"))),
        "traffic_limit": numeric(raw.get("trafficLimitBytes")),
        "expires": str(raw.get("expireAt") or "")[:40],
        "online_at": str(traffic.get("onlineAt") or "")[:40],
        "hwid_limit": raw.get("hwidDeviceLimit") if type(raw.get("hwidDeviceLimit")) is int else None,
        "tag": str(raw.get("tag") or "")[:30],
        "seen_at": now,
    }
    return data


def numeric(value):
    if type(value) in {int, float} and 0 <= value < 10**21:
        return value
    return None


def masked_ip(value: str | None) -> str | None:
    import ipaddress

    try:
        ip = ipaddress.ip_address(value or "")
        return str(ipaddress.ip_network(f"{ip}/{24 if ip.version == 4 else 64}", strict=False))
    except ValueError:
        return None


async def observe_sharing(services, force=False):
    db, box, cfg = services.db, services.box, services.cfg
    policy = db.get("sharing_policy", {"enabled": False})
    state = db.get("sharing_state", {})
    if cfg.demo or not policy.get("enabled"):
        return state
    now = time.time()
    if not force and now - state.get("last_attempt", 0) < policy.get("poll_seconds", 300):
        return state
    state["last_attempt"] = now
    db.set("sharing_state", state)
    try:
        api = services.api()
        candidates = []
        limit = policy.get("inspect_limit", 100)
        for offset in range(0, limit, 100):
            response = await api.sharing_top(offset, min(100, limit - offset))
            batch = response.get("users")
            if not isinstance(batch, list):
                raise RemnawaveError("HWID API вернул неподдерживаемый формат")
            candidates.extend(batch)
            if len(batch) < min(100, limit - offset):
                break
        if len(candidates) > 500:
            raise RemnawaveError("Слишком большой HWID ответ")
        for raw in candidates:
            key = identity(raw)
            count = raw.get("devicesCount")
            if type(count) is not int or not 0 <= count <= 100000:
                continue
            username = str(raw.get("username", ""))[:64]
            ignored = key in policy.get("exclusions", []) or username in policy.get("exclusions", [])
            suspicious = count > policy.get("threshold_devices", 3) and not ignored
            before = db.one("SELECT * FROM user_observations WHERE user_uuid=?", (key,))
            # A long blind interval is not a consecutive observation.
            prev = (
                before["consecutive"]
                if before and now - before["last_seen"] < policy.get("poll_seconds", 300) * 2.5
                else 0
            )
            consecutive = prev + 1 if suspicious else 0
            flagged = int(consecutive >= policy.get("consecutive_samples", 2))
            notified = before["notified"] if before else 0
            if flagged and not notified:
                message = f"Антишейринг · наблюдение: {username}, зарегистрировано HWID: {count}. Это сигнал, не доказательство sharing. Автоблокировки нет."
                if policy.get("telegram", True):
                    await notify(db, box, cfg, message, category="sharing")
                db.audit("sharing.signal", f"{username}: {count} registered HWID; observe only")
                notified = 1
            elif not suspicious:
                notified = 0
            db.execute(
                """INSERT INTO user_observations(user_uuid,count,first_seen,last_seen,consecutive,flagged,notified)
                VALUES(?,?,?,?,?,?,?) ON CONFLICT(user_uuid) DO UPDATE SET count=excluded.count,last_seen=excluded.last_seen,
                consecutive=excluded.consecutive,flagged=excluded.flagged,notified=excluded.notified""",
                (key, count, before["first_seen"] if before else now, now, consecutive, flagged, notified),
            )
            # Minimal safe cache for signals not visited in the paginated users view.
            cached = db.one("SELECT data FROM user_cache WHERE uuid=?", (key,))
            if not cached:
                value = {
                    "identity": key,
                    "username": username,
                    "status": "UNKNOWN",
                    "traffic_used": None,
                    "traffic_limit": None,
                    "expires": "",
                    "online_at": "",
                    "hwid_limit": None,
                    "tag": "",
                    "seen_at": now,
                }
                db.execute("INSERT OR IGNORE INTO user_cache VALUES(?,?,?)", (key, json.dumps(value), now))
        state = {
            "online": True,
            "supported": True,
            "last_attempt": now,
            "last_success": now,
            "inspected": len(candidates),
            "coverage_limit": limit,
            "partial": len(candidates) >= limit,
            "mode": "observe",
        }
    except Exception:
        state = {
            **state,
            "online": False,
            "supported": False,
            "error": "HWID недоступен: проверьте capabilities/права токена. Нет оснований считать пользователей нарушителями.",
        }
    db.set("sharing_state", state)
    return state
