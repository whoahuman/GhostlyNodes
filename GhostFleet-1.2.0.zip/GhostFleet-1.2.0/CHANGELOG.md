# Изменения

## 1.2.0 — 2026-10-07

**Hotfix: `node restart` (и action endpoint в целом).** Remnawave's `POST
/nodes/{uuid}/actions/restart` requires a JSON body (`{"forceRestart": bool}`) and
replies `202` with an **empty** body on success. GhostFleet sent no body and treated
any empty/non-JSON success response as a connectivity error, so a correctly
authorized restart with healthy SSH keys still failed. `Remnawave.action()` now sends
the required body (with a new opt-in "force restart" checkbox in the UI) and
`Remnawave.request()` treats 202/204 empty bodies as success instead of a decode
error. Verified against the actual Remnawave 3.4.4 contract
(`libs/contract/commands/nodes/actions/restart.command.ts`) and covered end-to-end:
unit test on `Remnawave.action`, full mocked deploy-pipeline test, and a new
HTTP-level test hitting `POST /api/nodes/{id}/actions`.

**Node camouflage (DPI/РКН/ТСПУ probing).** Addressed the user's full active-probing
checklist item by item — see `docs/STEALTH.md` for the honest breakdown of what's
solved, what's mitigated, and what cannot be promised (TSPU-level behavioural traffic
analysis, client-side JA4/uTLS fingerprinting, full domain-less install). Shipped:
`templates/xray.reality.example.json` (VLESS gRPC REALITY, no Hysteria2/UDP by
default), `app/template.py` support for `security: "reality"` inbounds (validated
shape, certificates never substituted into REALITY inbounds, cert-sync skips them
safely), `scripts/gen-reality-keys.py` offline keypair generator,
`node/stealth-check.sh` read-only on-node self-audit. Also fixed a latent bug in the
RU-bridge REALITY outbound example: the public-key field was the deprecated
`password` alias instead of `publicKey`. 166 tests (was 153).

## 1.1.2 — 2026-10-06

Installer compatibility: optional access gateway auto/enable/skip. Missing/custom nginx preserves existing proxy/ACL and does not roll back the core upgrade by default. Explicit enable and recognised helper failure remain fail-closed. docs/GATEWAY-COMPAT-1.1.2.md.

## 1.1.1 — 2026-10-06

Hotfix Config Profiles HTTP409: scoped deterministic names (27 chars, instance+node UUID hash), create UUID persisted before optional details request, conservative exact-config/ownership lost-response recovery; HTTP409 diagnostics distinguish conflict from wrong token. Legacy profiles remain untouched. 144 tests. Quick update: docs/QUICK-UPDATE-1.1.1.md.

## 1.1.0 — 2026-10-06

Dark UI; schema2 multi-admin/RBAC, personal CIDR and fresh-MFA gates; short-lived scoped/IP-bound service tokens; Cloudflare A/AAAA DNS-only; dynamic nginx/app IP gateway without web-root; safe Remnawave users/HWID observation (no automatic bans); notification rules/test; install profiles; curated TCP/qdisc/TBF tuning with watchdog/ACK; encrypted config versions; new schema-aware rollback and diagnostics.

**Первое обновление 1.0→1.1: свежий installer, не старый update.sh.** Ноды не rebootstrap, old owner credentials/crypto preserved. Live infrastructure pilot still required.

## 1.0.0 — 2026-10-04

Первая версия GhostFleet: Remnawave v3 contract integration, Ghostly adapter, приватная установка systemd, русскоязычная UI, обязательная TOTP, temporary encrypted SSH credentials, pinned SSH trust, restricted node agent, индивидуальные Config Profiles/TLS/Hosts/Internal Squads, monitoring/jobs/audit, age backup/restore и CI.

Release не прошёл live E2E на инфраструктуре владельца. Перед массовым deployment нужен пилот на новом VPS и review security/операционных ограничений.
