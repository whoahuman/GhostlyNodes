# Антишейринг 1.1: shadow/observe, без автобанов

Ваш выбранный режим реализован буквально: счётчики HWID анализируются, отчёт/уведомления формируются, **worker никогда не вызывает disable/delete/reset/revoke пользователя**.

Источники: Remnawave 3.4 contracts `/users`, `/hwid/devices/{id}`, `/hwid/devices/top-users`. Новая версия API использует numeric id; adapter принимает UUID identity для старых совместимых responses, но фактическую minor-версию/права API нужно проверить на вашей панели. Недоступное/неподдерживаемое HWID API отображается как unknown/unavailable, не «нарушение».

## Какие сигналы доступны

Порог **зарегистрированных HWID**, например >3, должен сохраняться на 2 последовательных выборках. Политика: enable, threshold, confirmations, интервал ≥5 минут, top sample cap 10–500, исключения IDs/usernames, Telegram. Один alert при переходе в flagged, не на каждом poll. Длительный blind interval не считается последовательностью.

Выборка TOP-N **не весь аккаунт**, особенно при >500 пользователей. В UI указано inspected/partial/coverage limit. За пределами coverage нет достоверного «всё в порядке». При outage старые наблюдения stale, их нельзя интерпретировать как текущие события.

## Ограничения, важные для клиентов

- Registered HWID ≠ одновременно подключённые устройства и ≠ число людей.
- У пользователя может быть телефон, laptop, tablet, переустановленный клиент, семейный тариф.
- Один клиент может не передавать HWID, передавать нестабильный или поддельный HWID. Импорт/скопированный конфиг может обходить subscription request HWID.
- Два человека могут использовать одну NAT сеть/IP/HWID; один человек — много IPv6/мобильных IP. IP count не является доказательством sharing.
- Нет постоянного глобального live-IP/concurrency collector с нод в 1.1; не имитируем его count графиками и не обещаем полную защиту.

Raw subscriptionUrl/vlessUuid/trojan/ss passwords/shortUuid не кэшируются и не возвращаются frontend. Device fingerprints HMAC-псевдонимизированы, request IP показывается как /24 или /64 network. В Telegram — username+count+предупреждение, не raw HWID/IP/credentials.

## Ручные действия

С permissions users.operate доступны disable/enable/reset-traffic/индивидуальный hwid limit после подтверждения username. Это осознанное действие оператора, **не** автоматическое наказание за сигнал. Перед ограничением свяжитесь с пользователем и учитывайте тариф/количество разрешённых устройств.

Настоящий дальнейший антишейринг: opt-in authenticated node telemetry, bounded concurrency windows, privacy retention, доказательства/исключения, сначала shadow mode и только после измерения false positives — ограниченные reversible меры. См. ROADMAP.md.
