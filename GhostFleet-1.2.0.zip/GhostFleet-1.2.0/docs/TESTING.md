> Это отчёт 1.0. Актуальный release 1.1: [TESTING-1.1.md](TESTING-1.1.md).

# Проверки v1.0.0 — 2026-10-04

## Что реально выполнено

| Проверка | Результат |
|---|---|
| pytest на CPython 3.10.22 | 101 passed |
| pytest на CPython 3.13.14 | 101 passed |
| Установка universal hashed dev/runtime locks на Python 3.10 и 3.13, binary wheels | успешно; отдельные version markers для несовместимых dev dependencies |
| ruff check / format app, node, tests, scripts | clean |
| Python compileall app/node | успешно |
| bash -n + ShellCheck deploy/*.sh, node/bootstrap.sh | успешно |
| node --check app/static/app.js | успешно |
| Bandit app/node | 0 findings после узко документированных исключений; JSON в qa/bandit.json |
| pip-audit runtime lock | No known vulnerabilities found на момент проверки; JSON в qa/runtime-dependencies.json |
| Desktop read-only demo 1440px | dashboard, фильтр/поиск, карточка ноды, settings, template preview, add form; no JS/CSP errors |
| Demo 390px / 768px / 1440px | навигация по всем разделам, нет горизонтального page overflow и JS errors; table отдельно scrollable |
| One-shot browser production-mode local app | пароль → QR TOTP enrollment → 10 recovery codes → full dashboard → delayed-template navigation race guard → logout/revoked session; no page errors |

В pytest покрыты: auth/CSRF/Origin/cookies/session timeout/MFA replay/recovery, AES nonce/AAD binding, allowlist и SSRF, password validation без secret echo, шаблон/country/routing, TLS chain/name/key/expiry, metadata-deny/redirect rejection, реальные локальные TLS SNI+Host IP-pinning и SSH server host-key mismatch **до password auth**, fixed agent commands/image restrictions, encrypted temporary queue/challenge single-use, безопасный CSV, secrets write-only, URL change без пересылки старого API-токена, maintenance, interrupted/failed payload cleanup и progress, API-outage unknown status.

Полный deployment flow протестирован **через Remnawave contract mock + mocked SSH installer** в root и nonroot/NOPASSWD ветке: profile/node/Hosts/squad union, TLS embedding, country tags, no raw credentials in job logs, final waiting state и wipe payload. Это не запуск root bootstrap на настоящей ноде.

## Как повторить

```bash
python -m pip --isolated install --only-binary=:all: --require-hashes -r requirements-dev.txt
python -m pytest -q
ruff check app node tests scripts
ruff format --check app node tests scripts
bandit -r app node -c pyproject.toml
pip-audit --disable-pip --no-deps -r requirements.txt
python -m compileall -q app node
node --check app/static/app.js
bash -n deploy/*.sh node/bootstrap.sh
shellcheck deploy/*.sh node/bootstrap.sh
```

Опциональный browser smoke (не production dependency):

```bash
python -m pip install playwright
playwright install --with-deps chromium
python scripts/browser_smoke.py
```

Создаёт только временное локальное QA состояние и краткоживущий local server, не production service. Пароль внутри script — test-only, не рекомендуемый реальный пароль. Chromium использует --no-sandbox только в QA container; production приложение не запускает браузер. UI smoke для demo выполнен также отдельными локальными Playwright проверками; screenshots — синтетические данные, не live infrastructure.

GitHub CI matrix настроена, но запуск workflow в **вашем** репозитории ещё не происходил: загрузите исходники и дождитесь зелёного CI.

## Что НЕ проверено и обязательно для пилота

- Root panel installer на чистых реальных Ubuntu/Debian с systemd, nginx/certbot и actual DNS.
- Полный node bootstrap с Ghostly/ACME/Docker/iptables-nft/provider firewall на вашем VPS.
- Настоящий Remnawave server/API token/version, действующие Internal Squads/users/subscriptions.
- Тестовые клиенты VLESS gRPC / Hysteria2 TCP/UDP443 и реальный YouTube route через ваш RU bridge.
- Обновление контейнера и rollback на реальных образах; live certificate renewal/reload.
- Encrypted backup/restore на второй реальной машине, смена manager egress и восстановление node keys.
- Независимый penetration test, fuzzing всей API поверхности, нагрузочный тест и длительная эксплуатация.

**Пилот:** отдельный новый VPS → зафиксировать baseline firewall → проверить fingerprint через provider console → установить одну ноду → проверить закрытый NODE_PORT, оба протокола, Hosts/Squads/subscription, API-outage unknown, logs/privacy → backup/restore → только потом массовое добавление. Успех тестов и нулевой vulnerability scan не являются гарантией отсутствия логических уязвимостей/рисков окружения.
