# Быстро обновить сервер до 1.1.1 и исправить Config Profile HTTP 409

Это hotfix коллизий при `POST /api/config-profiles`. Старое глобальное имя `GF-DE-01` могло совпадать с прошлым профилем или потерянным ответом создания. 1.1.1 использует короткое scoped имя по instance+node UUID, сохраняет UUID **до** запроса деталей и при 409 восстанавливает только точное совпадение конфига/принадлежности. Чужие профили не удаляются и не обновляются. 409 не выдаётся за неверный token.

## Самый короткий путь: архив → сервер

Все команды выполняются **на сервере GhostFleet**, не на сервере ноды. Сохраните открытую SSH/recovery-консоль и дождитесь окончания running/queued jobs.

### 1. На своём компьютере

Скачайте `GhostFleet-1.1.1.zip`, отправьте на VPS (подставьте вашего SSH user и IP):

```bash
scp GhostFleet-1.1.1.zip YOUR_SSH_USER@PANEL_IP:~/
ssh YOUR_SSH_USER@PANEL_IP
```

### 2. На VPS: backup

Если уже есть age recipient, предпочтительно:

```bash
sudo bash /opt/ghostfleet/current/deploy/backup.sh --recipient age1ВАШ_PUBLIC_RECIPIENT
```

Без настроенного age — явная **root-only локальная страховка**, не off-site backup:

```bash
sudo bash /opt/ghostfleet/current/deploy/backup.sh \
  --allow-plaintext \
  --output "/var/backups/ghostfleet/before-1.1.1-$(date +%Y%m%d-%H%M%S).tar.gz"
```

Plaintext архив содержит DB и master key вместе: не загружать в GitHub/чат/облако, не делать world-readable. Позже замените шифрованным off-site backup. Installer также делает свой pre-update snapshot.

### 3. Распаковать и обновить СВЕЖИМ installer

```bash
sudo apt-get update -qq
sudo apt-get install -y unzip

mkdir -p ~/ghostfleet-updates
unzip ~/GhostFleet-1.1.1.zip -d ~/ghostfleet-updates
cd ~/ghostfleet-updates/GhostFleet-1.1.1

# Проверить, что файлы архива не повреждены
sha256sum -c SHA256SUMS

# Сохраняет текущий HTTPS/allowlist/port, password/TOTP/tokens/node keys
sudo bash deploy/install.sh --upgrade --source "$PWD"
```

Не удалять `/var/lib/ghostfleet`, не менять `master.key`, не запускать новую чистую установку. Для перехода 1.0→1.1.1 **не** использовать старый update.sh: нужен новый schema-aware rollback.

### 4. Проверить

```bash
sudo ghostfleet check
sudo systemctl status ghostfleet --no-pager
sudo bash /opt/ghostfleet/current/deploy/check.sh
```

Откройте прежний HTTPS-домен, Ctrl+F5/обновление без cache, войдите прежним password+свежим TOTP. При schema1→2 сессии завершаются — нормально.

Откройте проблемную ноду → **Повторить установку**, заново SSH probe/fingerprint и credentials. Повторяйте имеющуюся failed ноду, не добавляйте ещё одну с тем же IP. Hotfix создаст индивидуальный новый профиль, не тронет старый `GF-DE-01`. Retry всё ещё может повторно вызвать owned bootstrap — это не API-only repair command; не выполнять поверх сервера с чужой установкой.

## Через собственный GitHub

Загрузите содержимое 1.1.1 в свой repo, получите SHA. На VPS из свежего checkout:

```bash
git fetch origin
git checkout YOUR_NEW_COMMIT_SHA
sudo bash deploy/install.sh --upgrade \
  --repo https://github.com/YOUR_LOGIN/YOUR_REPO.git \
  --ref YOUR_NEW_COMMIT_SHA
```

В private repo clone/fetch как обычный пользователь своим deploy key, install с `--source "$PWD"`. Не вставляйте PAT/password в URL. Не передавайте `--mode tunnel` при update своей HTTPS allowlist панели: существующая схема сохраняется.

## Если update остановился на nginx gateway

Стандартный файл должен быть `/etc/nginx/sites-available/ghostfleet`. Custom proxy / изменённая nginx схема автоматически не переписывается; installer откажется и откатит code+DB/env. Не отключайте allowlist вслепую. Пришлите конкретную ошибку **без env/token/keys**, изучите `UPGRADE-1.1.md` / `RBAC.md`.

## Если 409 остался

Нужны endpoint+полный safe message+version и этап job. Hotfix покрывает name collision/lost detail response, а не все возможные 409 от backend/reverse proxy. Existing UUID/profiles shared foreign nodes не перезаписываются. API token не перевыпускайте просто из-за 409; authentication обычно 401/403.

144 pytest passed в sandbox, включая conflict recovery, UUID checkpoint и отказ touching чужих профилей. Ваш VPS/настоящий API не использовались для live validation. Старые unused generic профили можно разбирать отдельно в Remnawave, только проверив отсутствие nodes/Hosts/Squads dependencies; hotfix не удаляет их автоматически.
