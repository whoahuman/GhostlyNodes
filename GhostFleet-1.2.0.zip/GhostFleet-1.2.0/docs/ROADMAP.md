# Дорожная карта GhostFleet — профессиональное развитие

Идеи, которые **ещё не реализованы**, отдельно от функций 1.1. Развиваем слоями, сначала наблюдение и управляемые изменения, не «50 опасных root переключателей».

## Что уже вошло в 1.1

Dark UI по референсу; multi-admin/RBAC/individual IP; ограниченные API service accounts; dynamic nginx/app allowlist; Cloudflare A/AAAA DNS-only; safe user view/manual ops; HWID observe/Telegram; install presets с базовым TCP/qdisc/TBF; watchdog confirmation; encrypted config versions; миграция/rollback и local diagnostics.

## Ближайшие релизы — максимальная отдача

| Функция | Что даст | Риски / prerequisite | Приоритет |
|---|---|---|---|
| **Drain / maintenance ноды** | Убрать из выдачи новых подключений, дождаться падения нагрузки, затем update/restart | subscriptions/Hosts propagation, existing sessions handling, правильное resume | P0 |
| **Preflight wizard** | Перед bootstrap проверить DNS/ports/OS/disk/sudo/firewall/agent/backend capabilities, показать exact plan | SSH credentials только после pin, без destructive probe | P0 |
| **Config diff + validation** | Сравнить current/desired, Xray dry-run, список затрагиваемых users/inbounds, approve | remote parser/core version, secrets redaction | P0 |
| **Canary deployment** | Одна тестовая нода/сквад, e2e client check, затем controlled rollout | отдельные test users, secrets vault, fail-stop batching | P0 |
| **Node health независимыми пробами** | Отличить API-down от server/node/core/tcp443/udp443/DNS | минимум 2 точки/страны, probe trust, rate limits | P0 |
| **Управляемый agent update** | Обновления stdlib агента без rebootstrap и root password повторно | signed manifest, privileged updater с точным allowlist, rollback; не arbitrary source URL | P0 |
| **Projects / node groups / resource RBAC** | Делегировать сотруднику только конкретные ноды/страны/проект | server-side resource filter на каждый endpoint/summary/job | P0 |
| **Webhook уведомления** | Telegram+webhook, retries/delivery queue/ack/escalation | SSRF egress policy, signed body, limited secrets, дедупликация | P1 |

## Антишейринг и пользователи

1. **Живые concurrency windows** на нодах: opt-in сбор только необходимых connection metadata; общий лимит по всем нодам, не только на одном сервере.
2. **Стабильная IPv6/NAT агрегация**: /64, grace periods мобильной смены сети, исключения family/business/roaming; IP signal never proof.
3. **HWID lifecycle**: возраст устройства, повторная установка, смена client app, last-seen, self-service removal с cooldown.
4. **Risk explanation**, а не чёрный score: какие наблюдения, где partial coverage и blind intervals, почему сработало, кто проверил.
5. **Shadow-policy simulator**: прогнать proposed thresholds по истории без изменений, оценить false positives и какие пользователи пострадают.
6. **Reversible enforcement** после пилота: предупреждение → temporary session limit → manual approval → timed unblock, не permanent ban с первого IP.
7. **User-level exceptions и тарифы устройств**: персональные allowlists/лимиты, семейные/командные тарифы, временное travel исключение.
8. **Subscription lifecycle**: expires in 3/7/14 days, quota70/90%, active but never-connected, onboarding funnels. Не выдавать active status за «платящий» без billing источника.
9. **Self-service device portal**: пользователь видит/отзывает свои устройства без доступа к инфраструктурной панели.
10. **Privacy retention**: pseudonymization, short-lived raw IP evidence, deletion/export controls, роли доступа. Не сохранять полный browsing/log history.

## Shaping и сетевой профессиональный тюнинг

11. **HTB data-plane + protected management class**: гарантированный минимум SSH/API, ограничение клиента по port/protocol. Current 1.1 TBF этого не делает.
12. **Ingress IFB**: отдельные in/out лимиты, автоматический interface capability detection, forbid double-shaping.
13. **Budget per protocol**: gRPC/Hysteria2/XHTTP независимо, fairness между users, защита от «один torrent забрал всё».
14. **MTU/MSS / PMTUD диагностика**: black-hole detection, measured path MTU, рекомендации, staged MSS clamp; не blindly set1450 всем.
15. **UDP health / socket buffers**: packets dropped, buffer pressure, provider UDP filtering, quota/drop counters и warnings.
16. **Measured kernel profiles**: BBR/CUBIC comparisons, RTT/p99/loss baseline, automatic rollback on regression, provider-specific validated presets.
17. **CPU/NUMA/IRQ diagnostics**: steal time, throttling, IRQ balance, CPU affinity; immutable bounded actions only, не arbitrary sysctl module.
18. **Adaptive capacity / load-aware placement**: online users + CPU/RAM/network + headroom, avoid overbooking, apply tested thresholds.
19. **Anti-DDoS escalation**: detect bursts, temporary targeted rules, provider integration, time-limited rules and recovery. Never blind ban NAT pools.
20. **Bandwidth quality history**: RTT/jitter/loss/throughput by country/operator, not just network-interface bytes.

## Мосты и маршрутизация

21. **Bridge inventory**: несколько RU/other exits, ownership, TLS/REALITY pins, health/probe history, encrypted credentials.
22. **Active/passive failover**: primary→backup, backoff/circuit breaker, recovery without flap, контроль цепочки hop/loop.
23. **Explicit fail-open/fail-closed**: если RU bridge упал, YouTube direct fallback либо block — выбор владельца и предупреждение privacy impact, не скрытый bypass.
24. **Routing rule composer**: geosite/domain/ip/protocol rules, order/conflicts, exceptions, preview exact JSON и regression tests.
25. **Rule packs с версиями**: YouTube/streaming/direct/private/block bundles, allowlist источников, signature/hash и diff перед импортом.
26. **Split egress by class**: YouTube через bridge, банки/geo-sensitive через country exit, остальное direct; e2e проверка resolved IP/location.
27. **Bridge chain loop guard**: max hops, запрещённые owner overlap, auto graph visualisation, no accidentally route into own inbound.
28. **DNS strategy per egress**: resolver health, bootstrap DNS pins, DoH/DoT, prevent route/DNS mismatch and leaks; сначала validate capability.
29. **Transport profiles**: gRPC/HY2/XHTTP/WS/REALITY selection only when core/client/subscription supports. Version compatibility matrix.

## Конфиги и GitOps

30. **Immutable desired-state generations**: every node generation+checksum, drift detection, remote edits never silently overwritten.
31. **Per-node overrides**: country/domain/listen/inbound enable/limits, bounded JSON pointers/schema; no unsafe string replacements.
32. **Approve / four eyes**: dangerous changes требуют второй owner, ticket/comment, audit immutable event chain.
33. **Scheduled rollouts**: batch size, concurrency, maintenance windows, pause/resume, abort thresholds, SSH restoration gate.
34. **End-to-end test user**: VLESS/HY2 subscription, DNS/TLS, traffic route/bridge test, no production user credential reuse.
35. **Signed profile catalog**: reviewed templates, bridge secrets references instead of baked values, hash pinned origin.
36. **Config export/import без secrets**: YAML/JSON declarative state + encrypted secret references, reviewed GitOps PR pipeline.

## Администрирование и эксплуатация

37. **Passkeys / WebAuthn и SSO**: человеческие accounts, device trust, break-glass owner и tested recovery.
38. **Fine-grained tokens / workload identities**: per-resource scope, short-lived exchanged tokens, signed webhooks, no permanent broad PAT.
39. **Session console**: own/admin sessions, last IP/UA/time, selective revocation, suspected takeover alert.
40. **External secrets vault**: envelope encryption/vault references/rotation with versioned rollback; local master.key remains a single-host trust boundary today.
41. **Encrypted automated off-site backups + restore drills**: scheduler, retention, integrity/success alerts, periodic disposable restore test. Private age identity off server.
42. **Prometheus/OpenTelemetry**: bounded-cardinality metrics, privacy-safe labels, exporter scopes, Grafana dashboards и alert SLO.
43. **Provider integrations**: create/rebuild/reboot VPS with idempotency, cost budget/explicit approval, firewall before exposure, no automatic paid infra creation.
44. **Incident timeline**: alerts, deploy generations, owner actions, vendor/API outage correlation, action runbooks; secrets scrubbed.
45. **Capacity/cost planning**: measured €/$ per TB/user/node from actual provider+billing data; не рисовать фальшивую выручку на screenshot style dashboard.

## Предлагаемый порядок

**1.2:** preflight + drain + session console + diff/drift + compatibility checks. Уменьшает ежедневные ошибки и облегчает установку.

**1.3:** bridge inventory/failover + routing composer + canary e2e tests. Без этого массовый config rollout слишком рискованный.

**1.4:** resource RBAC + multi-project + живые concurrency signals/shadow simulator + protected HTB shaping.

**Дальше:** reversible enforcement, GitOps approvals, external vault/SSO/provider automation. Не объединять их все в один непроверенный root upgrade.
