# Администраторы, сервисные аккаунты и IP-доступ

## Личные аккаунты

Владелец: `Команда и права → Добавить администратора`. Сотруднику нужен уникальный длинный пароль; он подключает свою TOTP при первом входе. Не используйте общий login/OTP всей команды.

| Роль | Назначение |
|---|---|
| owner | Полный контроль, команда/права/API-аккаунты/IP. Последний активный owner сохраняется |
| admin | Инфраструктура, integrations/DNS, пользователи, тюнинг; без изменения staff/access/tokens и чтения приватного шаблона |
| operator | Чтение и restart/enable/disable, ручные действия с пользователями; без bootstrap/tuning/token administration |
| viewer | Только ноды, users, jobs, redacted config |
| dns | Только чтение нод и DNS в явно разрешённых зонах |

Роль — верхний предел. Индивидуальные permissions флажки **только уменьшают** набор. Backend проверяет реальные API permissions; скрытое меню не является защитой. Resource scoping по отдельным project/node groups пока не реализовано — права действуют на текущую интеграцию панели, это пункт roadmap.

Смена role/permissions/IP/active отзывает sessions аккаунта. Последнего owner нельзя выключить/понизить; текущий owner не может лишить себя собственного IP-доступа. Создание/изменение staff, API accounts, Cloudflare token и global allowlist требуют свежей MFA: login с TOTP даёт 5 минут, затем UI предлагает password + новый TOTP/recovery code. Уже использованный код не принимается повторно.

Per-account allowed_cidrs дополнительно ограничивают login/session поверх глобального допуска. Пусто = только глобальные правила, не обход firewall. Для SSH-туннеля все browser requests имеют loopback IP; per-admin IP не отличает исходные ноутбуки — используйте VPN с отдельными адресами + собственные SSH keys.

## Service API accounts

`Сервисные аккаунты → Создать`. Обязательны:
- имя;
- curated scopes;
- непустой IP/CIDR allowlist без /0;
- срок 1–365 дней.

Токен `gfk_…` показывается один раз, в DB только SHA256 random secret. Храните в secret manager, передавайте **Authorization: Bearer** по HTTPS. Не URL/query/GitHub. Revocation действует сразу; last-used без значения токена доступен владельцу.

Доступные scopes: nodes.read/operate, jobs.read, users.read/operate, dns.read/write, configs.read (redacted). Не выдаются staff/access/tokens/settings/config secret/bootstrap/root tuning права; нет 2FA setup/change password или web login. Missing/expired/revoked/wrong IP token → 401; invalid Bearer никогда не fallback на browser cookie. API token не требует CSRF, но browser-cookie операции по-прежнему требуют exact Origin + CSRF.

Машинный токен — секрет, как password. CIDR/expiry не делают украденный token безопасным, если атакующий находится в разрешённой сети. После restore service accounts отзываются: создайте новые.

## Dynamic allowlist без root-панели

Для стандартного HTTPS allowlist/VPN nginx:

```bash
sudo bash /opt/ghostfleet/current/deploy/access-gateway.sh
```

Это одноразовый **root helper, выполняемый человеком/installer**, не привилегия web process. Он делает backup nginx/env, убирает статические allow/deny только из managed ghostfleet site, добавляет nginx `auth_request` к внутреннему IP-gate, создаёт random shared secret в root env, проверяет nginx, health, reload. При ошибке восстанавливает исходные файлы.

nginx admission subrequest передаёт настоящий `$remote_addr` как отдельный заголовок и внутренний random secret. `X-Forwarded-For` там фиксируется loopback, потому что endpoint принимает только loopback+secret; cookies/Authorization удаляются. External `/_ghostfleet_gate` запрещён директивой `internal`, `/internal/` даёт 404. Backend повторно применяет ту же global policy ко всем обычным запросам. Incoming client X-GhostFleet-* не становится доверенным.

В UI текущий реальный IP должен остаться разрешён. Пустой список, /0, loopback/multicast/linklocal запрещены. Меняются только admissions nginx/app, **не** provider firewall, SSH/VPN peers/security groups. Если provider ACL не пускает нового администратора, UI не сможет исправить её, и не должен.

Custom reverse proxy требует ручной reviewed gateway integration. Не добавляйте `forwarded-allow-ips '*'`/общий auth_request public endpoint и не раскрывайте gateway secret. Не открывайте uvicorn порт в интернет.

## CLI recovery

```bash
sudo ghostfleet reset-password --username ops.team
sudo ghostfleet reset-mfa --username ops.team
sudo ghostfleet revoke-sessions --username ops.team
sudo ghostfleet reset-access     # явное RESET-ACCESS, local root console only
```

reset-access возвращает global policy к env CIDR и восстанавливает owner id=1; не меняет внешнюю firewall ACL. Не используйте его, пока не проверены текущие процессы/сетевая схема. Потерю master key восстановление password не исправит.
