# Исправление обновления при custom nginx/proxy — 1.1.2

Симптом: update проходит build, backup, CLI check, health retries, затем падает на `Managed ghostfleet nginx/env files are required` и откатывается. Это не ошибка Remnawave API: новая optional IP-gateway функция раньше была обязательным шагом для каждого HTTPS allowlist/VPN.

1.1.2 отделяет core update от миграции proxy:

- `--access-gateway auto` (default): только узнаваемая standard managed nginx конфигурация переводится на gateway. Missing/custom proxy сохраняется как есть, upgrade продолжается с предупреждением.
- `--access-gateway skip`: helper вообще не запускается. Existing nginx/VPN/firewall/env IP policy не изменяются.
- `--access-gateway enable`: явно требовать gateway; неузнаваемая конфигурация — ошибка/rollback. Recognised managed helper failure остаётся fail-closed, не скрывается за успехом.

```bash
# Из свежего архива/checkout 1.1.2
sudo bash deploy/install.sh --upgrade --source "$PWD" --access-gateway skip
```

Это не отключает существующий allowlist/firewall и не открывает uvicorn публично. Но UI-редактирование global allowlist требует отдельно настроенного gateway; если его нет, API/страница остаются unavailable для этой функции. Не путайте global network permit с индивидуальными permissions/CIDR аккаунтов.

## Быстрый обход на уже скачанной 1.1.1

Только из распакованного 1.1.1, где update уже откатился:

```bash
python3 - <<'PY'
from pathlib import Path
p=Path('deploy/install.sh');s=p.read_text()
old='  bash "$NEW/deploy/access-gateway.sh"'
new='  say "IP-gateway пропущен; existing HTTPS/ACL не меняются"'
if s.count(old)!=1:raise SystemExit('Ожидаемый шаг не найден: ничего не изменено')
p.with_name('install.sh.before-gateway-fix').write_text(s)
p.write_text(s.replace(old,new,1))
PY
sudo bash deploy/install.sh --upgrade --source "$PWD"
```

Меняется только optional helper invocation. Version остаётся 1.1.1; источник install.sh намеренно изменён, поэтому старый internal SHA256SUMS для него уже не совпадает. Не отключаются security middleware/CIDR/MFA/TLS. Для дальнейших обновлений лучше reviewed 1.1.2 в своём GitHub.

Из вашего лога: pre-update snapshot `/var/backups/ghostfleet/pre-update-20261006193544` уже сохранён, restored sessions revoked. Не удаляйте state/master. Проверьте systemctl status; если новый retry падает — нужны последние строки, не secrets/raw env.

Sandbox checks cover only script logic/read-only predicates; live systemd/nginx/gateway на вашем VPS не выполнялись агентом.
