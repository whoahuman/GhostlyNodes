> 1.1.2: automatic gateway только для распознанного managed nginx. Custom/missing сохраняется; explicit `--access-gateway skip`. См. GATEWAY-COMPAT-1.1.2.md.

# Обновление установленной 1.0 → 1.1 без переустановки

**Для первого перехода используйте НОВЫЙ `deploy/install.sh` из 1.1, не старый `/opt/ghostfleet/current/deploy/update.sh`.** Старый 1.0 installer умеет вернуть code symlink, но не schema-2 DB. Новый возвращает согласованный snapshot DB/master/env/nginx/code при неуспешном запуске.

Ноды не переустанавливаются. Owner login/password/TOTP, instance/node UUID, API tokens, приватный RU bridge template и management keys сохраняются. Сессии отзываются при миграции: нужно войти заново. Никакие публичные IP, реальные credentials или автоматические root-действия в вашей инфраструктуре здесь не проверялись.

## Ваш вариант: Remnawave 3.4.x, HTTPS allowlist

1. Скопировать зашифрованный backup **вне VPS** (README / OPERATIONS). Убедиться, что queued/running jobs нет. Оставить открытой свою обычную SSH/recovery-консоль.
2. Загрузить содержимое архива 1.1 в свой GitHub, сохранить commit SHA.
3. На VPS клонировать/обновить checkout **свежего кода** как обычный пользователь. Не копировать state/master из архива и не выполнять init вручную поверх существующей базы.

```bash
# В своём исходном checkout, где git remote — ВАШ репозиторий
git fetch origin
git checkout NEW_COMMIT_SHA

# ИМЕННО свежий install.sh с новым rollback
sudo bash deploy/install.sh --upgrade \
  --repo https://github.com/YOUR_LOGIN/YOUR_REPO.git \
  --ref NEW_COMMIT_SHA

# Для private/local checkout вместо repo/ref:
# sudo bash deploy/install.sh --upgrade --source "$(pwd)"
```

Если установка из GitHub private — clone/fetch собственным deploy key как пользователь, потом `--source`. Не вставлять GitHub PAT в URL.

4. Установщик строит release, проверяет очередь, закрывает изменения, останавливает сервис, сохраняет pre-update snapshot, мигрирует schema 1→2, запускает/проверяет health. Для стандартного ghostfleet nginx allowlist/VPN конфигурация переводится на **dynamic access gateway**.
5. Войти своим прежним логином, паролем и новым TOTP-кодом. `Команда и права` покажет старого владельца id=1, `Allowlist` — прежние CIDR.

```bash
sudo bash /opt/ghostfleet/current/deploy/check.sh
sudo ghostfleet check
sudo systemctl status ghostfleet
```

## Что миграция делает, а чего не делает

- Перестраивает таблицу admins без single-id check; ваш старый администратор остаётся owner id=1.
- Добавляет admin_id/elevated_at в sessions; legacy сессии удаляет, чтобы они не получили чужие права.
- Сохраняет старые AAD `admin:totp`, `admin:pending_totp`, `recovery` для id=1. Новые аккаунты имеют отдельный AAD/id.
- Добавляет service accounts, safe user cache/HWID observations, install profiles, encrypted config versions.
- Не меняет Xray-профили уже установленных нод, bridge, subscription пользователей и их лимиты автоматически.
- Не расширяет firewall/security group/VPN/SSH. Dynamic allowlist работает на уровне nginx+приложения.
- Не обновляет старые node agents restricted SSH-ключом: ограничения ключа остаются реальными.

## Если nginx был доработан вручную

Автоматический helper принимает узнаваемый стандартный файл `/etc/nginx/sites-available/ghostfleet`. Если схема другая, он отказывается её переписывать. Обновление откатится; не удаляйте проверки. Сначала прочитайте `RBAC.md`, адаптируйте gateway блок в своём proxy вручную или оставьте статическую ACL и отключите auto gateway в своей reviewed installer копии. Тогда изменения allowlist через UI блокируются до появления подтверждённого gateway.

Default helper: `deploy/access-gateway.sh` — только root one-time operation с backup/nginx -t. Приложение всё время работает непривилегированно. Token для nginx внутренний, из root env, не возвращается в API.

## Старые ноды и тюнинг

Установленные ноды продолжают мониториться/перезапускаться старым агентом. UI тюнинга видит `capabilities`, а не придумывает их. Агент 1.0 не имеет tune/confirm.

Для обновления: перенести `node/agent.py` и `deploy/update-node-agent.sh` из reviewed pinned собственного release на **ноду**. Через свою обычную SSH/провайдерскую консоль:

```bash
# SHA256 берём из SHA256SUMS вашего reviewed release
sudo bash update-node-agent.sh \
  --source ./agent.py --sha256 EXACT_AGENT_SHA256
```

Сохраняет marker, authorized_keys, контейнер и TLS. Нужен собственный admin SSH, не restricted ключ GhostFleet. Новые ноды сразу получают 1.1 агент. Не запускайте panel installer на ноде.

## Аварийный откат

При неуспешном update новый installer автоматически восстанавливает snapshot и old symlink, очищает restored sessions/challenges, не создаёт новый master key. Snapshot root-only, **не encrypted** — это локальная страховка, не off-site backup.

Если процесс аварийно убит/диск неисправен — из SSH остановить сервис и восстановить конкретный pre-update snapshot DB/master/env/nginx + old release, удалить WAL/SHM, вернуть права, запустить old version. Нельзя просто переключить old code 1.0 поверх schema 2. Для штатного restore читайте `OPERATIONS.md`: format-1 архивы schema1/schema2 поддерживаются новым restore, service tokens после restore отзываются.

Откат приложения **не откатывает уже выполненные операции в Cloudflare/Remnawave/на нодах**. Их нужно проверять отдельно.
