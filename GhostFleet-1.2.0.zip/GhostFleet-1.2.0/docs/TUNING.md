# Профили установки и профессиональный тюнинг

## Реализовано в 1.1

В `Профили установки` создаётся repeatable preset:
- own `remnawave/node:version@sha256` image;
- fail2ban on/off и nft flood on/off (strict firewall остаётся);
- TCP congestion: keep/cubic/bbr;
- default qdisc: keep/fq/fq_codel;
- optional весь egress default интерфейса VPS — TBF cap, 10–100000 Mbit/s;
- explicit acknowledgement для shaping.

Профиль выбирается при новой установке. Без него старое безопасное поведение: pinned default image, защиты on, sysctls/qdisc untouched, shaping off. Image меняется **до** выполнения verified Ghostly entrypoint, не после использования mutable latest.

Установленные ноды: карточка операций → `Тюнинг / shaping`. Только owned managed agent с tune capability, permission nodes.tune, подтверждение slug. Agent 1.0 нужно обновить собственным admin SSH, не через обход restricted key.

## Safety protocol

1. Agent повторно validates exact JSON keys/enums/ranges; никакой shell, произвольный sysctl/path/interface или user argv не принимается.
2. Проверяет kernel congestion capability. Нет BBR → отказ **до изменений**, не silent fallback.
3. Выбирает default route interface системным fixed `ip -j route get`, не произвольную NIC из UI.
4. Refuses custom foreign root qdisc. Не перезаписывает чужой HTB/firewall/dedicated shaping.
5. Snapshot root0600 предыдущих sysctls/qdisc + собственных настроек; single pending transaction.
6. **До** изменений создаёт root systemd timer на 90 секунд. Если создать timer нельзя — изменений нет.
7. Применяет curated значения. Controller повторно проверяет pinned SSH health и подтверждает случайный nonce в пределах окна.
8. Нет SSH/ACK → watchdog возвращает snapshot. Confirmation удаляет pending и отменяет timer.

Это защищает от части lockout ошибок, но **не проверяет рабочесть VLESS/Hysteria2 клиента** и не является надёжной гарантией network health. После tune проверяйте data-plane, CPU, latency, потери и оба протокола. Snapshot/таймер и rollback сначала проверять на тестовом VPS вашей ОС.

## Чего не обещаем

TBF egress cap — **не per-user, не ingress, не гарантированная полоса, не billing**. Ограничивает также management SSH/API/ACME и трафик других сервисов VPS, поэтому нужны dedicated node + explicit ack. Min10 Mbit/s не спасает от всех ошибок/перегрузки. Core keep/qdisc keep не автоматически отключают ранее вручную настроенный чужой shaping: agent откажется его трогать.

BBR полезность зависит от RTT/loss/provider, а QUIC/Hysteria2 не превращается в TCP от смены tcp_congestion_control. qdisc default влияет на будущие интерфейсы/сокеты; kernel/provider может ограничивать возможности. Kernel modules/arbitrary commands/broad socket bufferring не включаются без проверки.

Для полного professional shaping следующий этап: HTB отдельная management priority class, ingress IFB, per-protocol/server budgets, capacity-aware drain, staged rollout и telemetry/e2e acceptance. Нельзя выдать безопасный универсальный sysctl набор по одному IP.

## Конфигурация и мосты

Редактор Xray — encrypted private template; импорт/preview как ранее, 30 encrypted versions, activate version только для будущих установок. Можно выбрать конкретную версию в форме ноды. Теги country/index/routing и TLS заменяются согласованно. Bridge credentials не сохраняются в репозитории/аудите.

Существующие node profiles не auto-overwritten, чтобы не потерять remote edits. Дальнейшие идеи bridge failover/egress pools/MTU/XHTTP — ROADMAP, а не выполненные функции этого архива.

Пустой rate означает «не изменять лимит», а не silent снятие ранее применённого shaping. Для снятия есть явный `disable_shaping` с подтверждением; агент принимает его только для собственного ранее зафиксированного TBF на той же NIC, не для чужого qdisc.
