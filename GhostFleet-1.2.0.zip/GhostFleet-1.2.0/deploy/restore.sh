#!/usr/bin/env bash
# Deliberate offline restore. Start with an installed, compatible GhostFleet release.
set -Eeuo pipefail
umask 077
ARCHIVE=""; IDENTITY=""; CONFIRM=""; TMP=""; STOPPED=0
help(){ cat <<'EOF'
sudo bash deploy/restore.sh --archive /path/backup.tar.gz.age --identity /path/identity.txt --confirm RESTORE
sudo bash deploy/restore.sh --archive /path/root-only-plain.tar.gz --confirm RESTORE

Restores the database, master key and environment. Replaces current users/settings.
Sessions and pending SSH passwords are revoked. Make a backup of current state first.
Do NOT restore somebody else's or an untrusted archive.
EOF
}
while (($#)); do
  case "$1" in --archive) ARCHIVE="${2:?}";shift 2;; --identity) IDENTITY="${2:?}";shift 2;; --confirm) CONFIRM="${2:?}";shift 2;; -h|--help) help;exit 0;; *) echo 'Unknown argument' >&2;exit 1;; esac
done
[[ $EUID -eq 0 && "$CONFIRM" == RESTORE && -f "$ARCHIVE" ]] || { help >&2;exit 1; }
getent passwd ghostfleet >/dev/null || { echo 'Install GhostFleet first' >&2;exit 1; }
TMP="$(mktemp -d /tmp/ghostfleet-restore.XXXXXXXX)"
cleanup(){ [[ -z "$TMP" ]] || rm -rf -- "$TMP"; if ((STOPPED));then echo 'Service remains stopped. Inspect state, then: systemctl start ghostfleet' >&2;fi; }
trap cleanup EXIT
if [[ "$ARCHIVE" == *.age ]]; then
  [[ -f "$IDENTITY" ]] || { echo 'An age identity file is required' >&2;exit 1; }
  age -d -i "$IDENTITY" -o "$TMP/input.tar.gz" "$ARCHIVE"
else cp -- "$ARCHIVE" "$TMP/input.tar.gz"; fi
python3 - "$TMP" <<'PY'
import hashlib,json,sqlite3,sys,tarfile
from pathlib import Path
p=Path(sys.argv[1]);allowed={'ghostfleet.sqlite3','master.key','environment.env','manifest.json'}
with tarfile.open(p/'input.tar.gz','r:gz') as archive:
    members=archive.getmembers()
    if len(members)!=4 or {m.name for m in members}!=allowed or any(not m.isfile() for m in members):
        raise SystemExit('Unsafe archive: unexpected files, links or paths')
    if sum(m.size for m in members)>2*1024**3:raise SystemExit('Archive too large')
    for m in members:
        with archive.extractfile(m) as src,(p/m.name).open('xb') as dst:
            while chunk:=src.read(1024*1024):dst.write(chunk)
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while chunk:=f.read(1024*1024):h.update(chunk)
    return h.hexdigest()
manifest=json.loads((p/'manifest.json').read_text())
if manifest.get('format')!=1 or manifest.get('schema') not in (1,2):raise SystemExit('Unsupported backup format/schema')
for name in allowed-{'manifest.json'}:
    if digest(p/name)!=manifest['files'].get(name):
        raise SystemExit('Checksum mismatch')
with sqlite3.connect(p/'ghostfleet.sqlite3') as c:
    if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise SystemExit('Invalid database')
    c.execute('DELETE FROM sessions');c.execute('DELETE FROM challenges')
    if c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='service_accounts'").fetchone():
        c.execute('UPDATE service_accounts SET active=0')
    c.execute("UPDATE nodes SET state='failed' WHERE id IN (SELECT node_id FROM jobs WHERE state IN ('queued','running'))")
    c.execute("UPDATE jobs SET state='interrupted' WHERE state IN ('queued','running')")
    c.execute('UPDATE jobs SET payload_cipher=NULL')
    c.execute("UPDATE settings SET value='0' WHERE key='maintenance_until'")
PY
# Avoid any stale WAL being replayed onto the restored database.
systemctl stop ghostfleet;STOPPED=1
install -m 0700 -o ghostfleet -g ghostfleet -d /var/lib/ghostfleet
rm -f /var/lib/ghostfleet/ghostfleet.sqlite3-wal /var/lib/ghostfleet/ghostfleet.sqlite3-shm
install -m 0600 -o ghostfleet -g ghostfleet "$TMP/ghostfleet.sqlite3" /var/lib/ghostfleet/ghostfleet.sqlite3
install -m 0400 -o ghostfleet -g ghostfleet "$TMP/master.key" /var/lib/ghostfleet/master.key
install -m 0640 -o root -g ghostfleet "$TMP/environment.env" /etc/ghostfleet/ghostfleet.env
(cd /opt/ghostfleet/current && runuser -u ghostfleet -- env -i HOME=/var/lib/ghostfleet PATH=/usr/bin:/bin /opt/ghostfleet/current/.venv/bin/python -m app.cli check)
systemctl start ghostfleet;STOPPED=0
printf 'Restored. Use the backup administrator password and 2FA.\nCheck that nginx / SSH tunnel match the restored PUBLIC_URL and port.\n'
