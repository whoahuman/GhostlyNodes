#!/usr/bin/env bash
# One-time root-owned nginx migration. The app never gains sudo or root file writes.
set -Eeuo pipefail
umask 077
SITE=/etc/nginx/sites-available/ghostfleet
ENV=/etc/ghostfleet/ghostfleet.env
[[ $EUID -eq 0 ]] || { echo 'Use sudo' >&2;exit 1; }
[[ -f "$SITE" && -f "$ENV" ]] || { echo 'Managed ghostfleet nginx/env files are required. Custom proxy: use docs/RBAC.md.' >&2;exit 1; }
MODE="$(sed -n 's/^GHOSTFLEET_MODE=//p' "$ENV")"
[[ "$MODE" == allowlist || "$MODE" == vpn ]] || { echo 'Gateway only applies to HTTPS allowlist/VPN.' >&2;exit 1; }
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/var/backups/ghostfleet/gateway-$STAMP"
install -m 0700 -d "$BACKUP"
cp "$SITE" "$BACKUP/nginx.conf";cp "$ENV" "$BACKUP/environment.env"
rollback(){
  local rc=$?
  if [[ $rc -ne 0 ]];then
    cp "$BACKUP/nginx.conf" "$SITE";cp "$BACKUP/environment.env" "$ENV"
    chown root:ghostfleet "$ENV";chmod 0640 "$ENV"
    if nginx -t >/dev/null 2>&1;then systemctl reload nginx 2>/dev/null || true;fi
    systemctl restart ghostfleet 2>/dev/null || true
    echo "Gateway update failed. Original nginx/env restored. Backup: $BACKUP" >&2
  fi
}
trap rollback EXIT
python3 - "$SITE" "$ENV" <<'PY'
import re,secrets,sys
from pathlib import Path
site,env=map(Path,sys.argv[1:]);config=site.read_text();text=env.read_text()
if 'proxy_pass http://127.0.0.1:' not in config or 'location = /api/auth/login' not in config or 'listen 443 ssl' not in config:
    raise SystemExit('Unrecognised/custom nginx config. No automatic edits; use the documented snippet.')
port=re.search(r'^GHOSTFLEET_PORT=(\d+)$',text,re.M)
if not port:raise SystemExit('Missing port')
match=re.search(r'^GHOSTFLEET_GATEWAY_TOKEN=([a-f0-9]{64})$',text,re.M)
token=match.group(1) if match else secrets.token_hex(32)
if not match:
    text=re.sub(r'^GHOSTFLEET_GATEWAY_TOKEN=.*\n?','',text,flags=re.M).rstrip()+f'\nGHOSTFLEET_GATEWAY_TOKEN={token}\n'
# Idempotent: never duplicate subrequest locations.
if '# GHOSTFLEET_DYNAMIC_ACCESS_V1' not in config:
    config=re.sub(r'^\s*(?:allow\s+[^;]+;|deny\s+all;)\s*$', '',config,flags=re.M)
    marker='    ssl_protocols TLSv1.2 TLSv1.3;'
    if marker not in config:raise SystemExit('Unsupported ssl_protocols section; manual gateway setup required')
    block=f'''
    # GHOSTFLEET_DYNAMIC_ACCESS_V1
    auth_request /_ghostfleet_gate;
    location = /_ghostfleet_gate {{
        internal;
        auth_request off;
        proxy_pass http://127.0.0.1:{port.group(1)}/internal/access-check;
        proxy_pass_request_body off;
        proxy_set_header Content-Length "";
        proxy_set_header Host $host;
        proxy_set_header Cookie "";
        proxy_set_header Authorization "";
        proxy_set_header X-Forwarded-For 127.0.0.1;
        proxy_set_header X-Real-IP 127.0.0.1;
        proxy_set_header X-GhostFleet-Peer $remote_addr;
        proxy_set_header X-GhostFleet-Gateway {token};
    }}
    location ^~ /internal/ {{ auth_request off; return 404; }}
'''
    config=config.replace(marker,marker+block,1)
# No reload until both config parsing and app's private token have been committed.
site.write_text(config);env.write_text(text)
PY
chown root:ghostfleet "$ENV";chmod 0640 "$ENV"
nginx -t
systemctl restart ghostfleet
PORT="$(sed -n 's/^GHOSTFLEET_PORT=//p' "$ENV")"
HOST="$(sed -n 's|^GHOSTFLEET_PUBLIC_URL=https://\([^/:]*\).*|\1|p' "$ENV")"
curl -fsS --retry 10 --retry-connrefused --retry-delay 1 --retry-max-time 30 --max-time 3 -H "Host: $HOST" "http://127.0.0.1:$PORT/healthz" >/dev/null
systemctl reload nginx
printf 'Dynamic nginx/application access enabled. Existing env CIDRs still apply until changed in UI.\nBackup: %s\nProvider firewall and SSH were not changed.\n' "$BACKUP"
