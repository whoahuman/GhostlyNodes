#!/usr/bin/env bash
# Run ON THE NODE through the owner's regular administrative SSH, never a restricted agent key.
set -Eeuo pipefail
umask 077
SOURCE="";EXPECTED=""
while (($#));do case "$1" in --source) SOURCE="${2:?}";shift 2;; --sha256) EXPECTED="${2:?}";shift 2;; *) echo 'Use: sudo bash update-node-agent.sh --source /path/agent.py --sha256 HASH' >&2;exit 1;;esac;done
[[ $EUID -eq 0 && -f /etc/ghostfleet-node.json && -f "$SOURCE" ]] || { echo 'Root on an existing owned GhostFleet node is required' >&2;exit 1; }
[[ "$EXPECTED" =~ ^[a-f0-9]{64}$ ]] || { echo 'Explicit SHA256 from your reviewed release is required' >&2;exit 1; }
[[ "$(sha256sum "$SOURCE" | cut -d ' ' -f 1)" == "$EXPECTED" ]] || { echo 'Agent hash mismatch' >&2;exit 1; }
python3 - "$SOURCE" <<'PY'
import ast,json,sys
from pathlib import Path
ast.parse(Path(sys.argv[1]).read_text())
meta=json.loads(Path('/etc/ghostfleet-node.json').read_text())
if not meta.get('instance_id') or not meta.get('node_id'):raise SystemExit('Invalid ownership marker')
PY
TARGET=/usr/local/lib/ghostfleet-node/agent.py
cp "$TARGET" "${TARGET}.pre-1.1.0"
install -m 0700 "$SOURCE" "$TARGET"
# The root authorised key force-command path remains unchanged. No new SSH permission is granted.
printf 'Agent updated. Metadata, keys, container image and TLS preserved.\nTest health from GhostFleet before tuning.\n'
