#!/usr/bin/env bash
# Read-only installation diagnostics. Never prints token/password/master key.
set -u
printf '=== GhostFleet local diagnostics (read-only) ===\n'
[[ ! -f /etc/os-release ]] || grep -E '^(PRETTY_NAME|ID|VERSION_ID)=' /etc/os-release
command -v python3 >/dev/null && python3 --version
command -v free >/dev/null && free -h
if command -v systemctl >/dev/null;then systemctl is-active ghostfleet 2>/dev/null || true;fi
if [[ -d /opt/ghostfleet/current ]];then printf 'Release: ';readlink -f /opt/ghostfleet/current;fi
ENV=/etc/ghostfleet/ghostfleet.env
if [[ -r "$ENV" ]];then
  grep -E '^GHOSTFLEET_(MODE|PORT|PUBLIC_URL|DEMO)=' "$ENV"
  if grep -q '^GHOSTFLEET_GATEWAY_TOKEN=' "$ENV";then echo 'Gateway: configured (value hidden)';else echo 'Gateway: not configured';fi
  PORT="$(sed -n 's/^GHOSTFLEET_PORT=//p' "$ENV")"
  HOST="$(sed -n 's|^GHOSTFLEET_PUBLIC_URL=https\?://\([^/:]*\).*|\1|p' "$ENV")"
  if [[ "$PORT" =~ ^[0-9]{1,5}$ && -n "$HOST" ]];then
    curl -fsS --max-time 5 -H "Host: $HOST" "http://127.0.0.1:$PORT/healthz" || true;echo
  fi
else echo 'Env is not readable; run sudo for complete local diagnostics.';fi
if [[ $EUID -eq 0 ]] && command -v nginx >/dev/null;then nginx -t;fi
printf '\nDoes not test your Remnawave/DNS/node credentials.\nReview output before sharing; public URL/IP metadata may be present.\n'
