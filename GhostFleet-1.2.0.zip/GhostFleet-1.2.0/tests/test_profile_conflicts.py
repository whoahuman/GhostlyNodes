from __future__ import annotations

import time
import uuid

import httpx
import pytest

from app.remnawave import Remnawave, RemnawaveError


def local_node(app):
    key = str(uuid.uuid4())
    now = time.time()
    app.state.db.execute(
        "INSERT INTO nodes(id,slug,name,country,ordinal,address,created,updated) VALUES(?,'de-01','DE-01','DE',1,'1.1.1.1',?,?)",
        (key, now, now),
    )
    return app.state.db.one("SELECT * FROM nodes WHERE id=?", (key,))


def test_profile_names_scoped_stable_and_fit_remnawave_limit(app):
    n = local_node(app)
    services = app.state.services
    name = services.profile_name(n)
    assert name == services.profile_name(n) and len(name) <= 30 and name != "GF-DE-01"
    app.state.db.set("instance_id", str(uuid.uuid4()))
    assert services.profile_name(n) != name
    assert services.profile_name({**n, "id": str(uuid.uuid4())}) != name


async def test_api_409_reports_conflict_not_bad_token(app):
    def handler(request):
        return httpx.Response(409, json={"message": "PRIVATE KEY MUST NOT BE ECHOED"})

    api = Remnawave(
        "https://panel.example.com", "TEST_ONLY_TOKEN", app.state.cfg, transport=httpx.MockTransport(handler)
    )
    with pytest.raises(RemnawaveError) as e:
        await api.create_profile("GF-test", {"inbounds": []})
    error = e.value
    assert error.status_code == 409 and error.path == "/config-profiles" and error.method == "POST"
    assert (
        "Конфликт" in str(error)
        and "PRIVATE KEY" not in str(error)
        and "Проверьте права API-токена" not in str(error)
    )


async def test_create_uuid_committed_before_failing_details_request(app):
    n = local_node(app)
    profile_id = str(uuid.uuid4())

    class API:
        calls = 0

        async def create_profile(self, name, config):
            self.calls += 1
            return {"uuid": profile_id}

        async def profile(self, key):
            raise RemnawaveError("Temporary GET failure")

    api = API()
    app.state.services.api = lambda: api
    with pytest.raises(RemnawaveError):
        await app.state.services.configure_profile(n, {"inbounds": []})
    assert (
        api.calls == 1
        and app.state.db.one("SELECT profile_uuid FROM nodes WHERE id=?", (n["id"],))["profile_uuid"]
        == profile_id
    )
    assert n["profile_uuid"] == profile_id


async def test_matching_unused_scoped_profile_is_recovered_without_patch_or_delete(app):
    n = local_node(app)
    name = app.state.services.profile_name(n)
    key = str(uuid.uuid4())
    config = {"inbounds": [{"tag": "de-01-grpc"}]}
    writes = []

    class API:
        async def create_profile(self, *args):
            writes.append("create")
            raise RemnawaveError("Conflict", status_code=409, method="POST", path="/config-profiles")

        async def profiles(self):
            return [{"uuid": key, "name": name}, {"uuid": str(uuid.uuid4()), "name": "GF-DE-01"}]

        async def profile(self, pid):
            return {
                "uuid": key,
                "name": name,
                "nodes": [],
                "config": config,
                "inbounds": [{"tag": "de-01-grpc"}],
            }

        async def update_profile(self, *args):
            writes.append("patch")
            raise AssertionError("Must not patch recovered profile")

    app.state.services.api = lambda: API()
    result = await app.state.services.configure_profile(n, config)
    assert result["uuid"] == key and writes == ["create"]
    assert app.state.db.one("SELECT profile_uuid FROM nodes WHERE id=?", (n["id"],))["profile_uuid"] == key


@pytest.mark.parametrize(
    "nodes,remote_config",
    [
        ([{"uuid": "another-node"}], {"inbounds": []}),
        ([{"name": "foreign-without-uuid"}], {"inbounds": []}),
        (None, {"inbounds": []}),
        ([], {"inbounds": [{"tag": "foreign"}]}),
    ],
)
async def test_conflict_never_takes_foreign_or_unproven_profile(app, nodes, remote_config):
    n = local_node(app)
    name = app.state.services.profile_name(n)
    key = str(uuid.uuid4())

    class API:
        async def create_profile(self, *args):
            raise RemnawaveError("Conflict", status_code=409, path="/config-profiles")

        async def profiles(self):
            return [{"uuid": key, "name": name}]

        async def profile(self, pid):
            return {"uuid": key, "name": name, "nodes": nodes, "config": remote_config, "inbounds": []}

        async def update_profile(self, *args):
            raise AssertionError("Must not touch foreign profile")

    app.state.services.api = lambda: API()
    with pytest.raises(RemnawaveError, match="не изменён"):
        await app.state.services.configure_profile(n, {"inbounds": []})
    assert app.state.db.one("SELECT profile_uuid FROM nodes WHERE id=?", (n["id"],))["profile_uuid"] is None
