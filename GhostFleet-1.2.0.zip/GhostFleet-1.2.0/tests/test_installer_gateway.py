"""One-shot read-only regression coverage: never runs a production/root installer."""

from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

import pytest

INSTALLER = Path(__file__).resolve().parents[1] / "deploy/install.sh"


@pytest.mark.parametrize("kind,expected", [("missing", 1), ("custom", 1), ("managed", 0), ("missing-env", 1)])
def test_gateway_auto_compatibility_preserves_unmanaged_proxy(tmp_path, kind, expected):
    script = INSTALLER.read_text()
    predicate = re.search(r"<<'PY_GATEWAY_COMPAT'\n(.*?)\nPY_GATEWAY_COMPAT", script, re.S)
    assert predicate
    site = tmp_path / "site"
    env = tmp_path / "env"
    if kind != "missing-env":
        env.write_text("GHOSTFLEET_MODE=allowlist\n")
    if kind == "custom":
        site.write_text("upstream custom_proxy {};\n")
    if kind in {"managed", "missing-env"}:
        site.write_text(
            "proxy_pass http://127.0.0.1:8088;\nlocation = /api/auth/login {\nlisten 443 ssl;\n    ssl_protocols TLSv1.2 TLSv1.3;\n"
        )
    result = subprocess.run(
        [sys.executable, "-c", predicate.group(1), str(site), str(env)], capture_output=True, check=False
    )
    assert result.returncode == expected
    assert not (tmp_path / "anything").exists()


def test_installer_has_explicit_skip_and_strict_enable():
    script = INSTALLER.read_text()
    assert "ACCESS_GATEWAY=auto" in script
    assert "--access-gateway)" in script
    assert '"$ACCESS_GATEWAY" == skip' in script
    assert '"$ACCESS_GATEWAY" == enable' in script
    assert script.index('"$ACCESS_GATEWAY" == skip') < script.index("PY_GATEWAY_COMPAT")
