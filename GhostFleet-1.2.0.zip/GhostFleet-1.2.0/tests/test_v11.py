from __future__ import annotations

import hashlib
import ipaddress
import json
import sqlite3
import time
from pathlib import Path

import httpx
import pyotp
import pytest

from app.cloudflare import Cloudflare, CloudflareError
from app.db import Database
from app.extensions_models import ServiceCreate, SharingPolicy, TuneSettings
from app.security import PASSWORD_HASHER, admin_label, new_session
from app.users import observe_sharing, safe_user


async def account_client(app, role="viewer", cidrs=None, custom=None):
    username = "test-" + role + "-" + str(time.time_ns())
    app.state.db.execute(
        "INSERT INTO admins(username,password_hash,role,permissions,allowed_cidrs) VALUES(?,?,?,?,?)",
        (
            username,
            PASSWORD_HASHER.hash("A test only member password 2026"),
            role,
            json.dumps(custom) if custom is not None else None,
            json.dumps(cidrs or []),
        ),
    )
    admin = app.state.db.one("SELECT * FROM admins WHERE username=?", (username,))
    token, session = new_session(
        app.state.db, app.state.cfg, "127.0.0.1", "GhostFleet tests", "full", admin["id"]
    )
    client = httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app, client=("127.0.0.1", 32000)),
        base_url="http://localhost:8088",
        headers={
            "Origin": app.state.cfg.public_url,
            "User-Agent": "GhostFleet tests",
            "X-CSRF-Token": session["csrf"],
        },
        cookies={app.state.cfg.cookie_name: token},
    )
    return client, admin


def test_schema_v1_migration_preserves_owner_ciphertext_and_revokes_legacy_sessions(tmp_path):
    file = tmp_path / "state.sqlite3"
    with sqlite3.connect(file) as c:
        c.executescript((Path(__file__).parent / "fixtures/schema-v1.sql").read_text())
        c.execute("INSERT INTO meta VALUES('schema','1')")
        c.execute(
            "INSERT INTO admins(id,username,password_hash,totp_secret,recovery) VALUES(1,'old-owner','old-hash','legacy-cipher','[\"legacy-recovery\"]')"
        )
        c.execute("INSERT INTO settings VALUES('template','\"original-encrypted-template\"')")
        c.execute("INSERT INTO sessions VALUES('old-token','csrf','full','127.0.0.1','ua',1,1)")
    db = Database(file)
    db.init()
    db.init()
    assert db.one("SELECT value FROM meta WHERE key='schema'")["value"] == "2"
    a = db.one("SELECT * FROM admins WHERE id=1")
    assert a["username"] == "old-owner" and a["role"] == "owner" and a["totp_secret"] == "legacy-cipher"
    assert json.loads(a["recovery"]) == ["legacy-recovery"]
    assert db.get("template") == "original-encrypted-template" and not db.query("SELECT * FROM sessions")
    db.execute("INSERT INTO admins(username,password_hash,role) VALUES('new-viewer','hash','viewer')")
    assert db.one("SELECT id FROM admins WHERE username='new-viewer'")["id"] == 2


async def test_staff_create_and_actual_server_permission_enforcement(app, authed):
    body = {"username": "observer", "password": "Long temporary test-only password", "role": "viewer"}
    r = await authed.post("/api/staff", json=body)
    assert r.status_code == 201 and body["password"] not in r.text
    assert r.json()["permissions"] == ["configs.read", "jobs.read", "nodes.read", "users.read"]
    viewer, a = await account_client(app, "viewer")
    try:
        assert (await viewer.get("/api/nodes")).status_code == 200
        assert (await viewer.get("/api/staff")).status_code == 403
        assert (await viewer.get("/api/template")).status_code == 403
        assert (await viewer.get("/api/settings")).status_code == 403
        assert (await viewer.post("/api/sync", json={})).status_code == 403
    finally:
        await viewer.aclose()


async def test_custom_permissions_only_reduce_role(app, authed):
    body = {
        "username": "bad-viewer",
        "password": "Long test-only member password",
        "role": "viewer",
        "permissions": ["staff.write"],
    }
    assert (await authed.post("/api/staff", json=body)).status_code == 422
    c, _ = await account_client(app, "operator", custom=["nodes.read"])
    try:
        assert (await c.get("/api/nodes")).status_code == 200
        assert (await c.get("/api/users")).status_code == 403
        assert (await c.post("/api/sync", json={})).status_code == 403
    finally:
        await c.aclose()


async def test_last_owner_cannot_disable_self(app, authed):
    r = await authed.patch("/api/staff/1", json={"role": "viewer", "active": False})
    assert r.status_code == 409
    assert app.state.db.one("SELECT role,active FROM admins WHERE id=1") == {"role": "owner", "active": 1}


async def test_disabled_staff_and_changed_permissions_revoke_sessions(app, authed):
    c, a = await account_client(app, "operator")
    try:
        assert (await c.get("/api/nodes")).status_code == 200
        r = await authed.patch("/api/staff/" + str(a["id"]), json={"role": "viewer", "active": False})
        assert r.status_code == 200
        assert (await c.get("/api/nodes")).status_code == 401
    finally:
        await c.aclose()


async def test_individual_ip_allowlist_is_enforced(app):
    c, _ = await account_client(app, "viewer", cidrs=["198.51.100.1/32"])
    try:
        assert (await c.get("/api/nodes")).status_code == 401
    finally:
        await c.aclose()


async def test_staff_mfa_is_bound_to_each_admin(app, authed):
    c, a = await account_client(app, "viewer")
    try:
        # Password-only session must enroll its own record, not owner's.
        app.state.db.execute("UPDATE sessions SET scope='setup' WHERE admin_id=?", (a["id"],))
        r = await c.post("/api/auth/totp/setup", json={})
        assert r.status_code == 200
        secret = r.json()["secret"]
        pending = app.state.db.one("SELECT pending_totp FROM admins WHERE id=?", (a["id"],))["pending_totp"]
        assert app.state.box.decrypt(pending, admin_label(a["id"], "pending_totp")) == secret
        assert app.state.db.one("SELECT pending_totp FROM admins WHERE id=1")["pending_totp"] is None
        r = await c.post("/api/auth/totp/confirm", json={"code": pyotp.TOTP(secret).now()})
        assert r.status_code == 200 and len(r.json()["recovery_codes"]) == 10
        r = await c.get("/api/auth/me")
        assert r.json()["totp_enabled"] is True and r.json()["role"] == "viewer"
        assert (await c.post("/api/sync", json={})).status_code == 403
    finally:
        await c.aclose()


async def test_sensitive_operations_require_recent_mfa(app, authed):
    app.state.db.execute("UPDATE sessions SET elevated_at=0")
    r = await authed.post(
        "/api/service-accounts",
        json={"name": "bot", "scopes": ["nodes.read"], "allowed_cidrs": ["198.51.100.1/32"]},
    )
    assert r.status_code == 428


async def test_service_token_scopes_ip_expiry_revocation_and_no_secret_list(app, authed):
    r = await authed.post(
        "/api/service-accounts",
        json={"name": "monitor", "scopes": ["nodes.read"], "allowed_cidrs": ["198.51.100.9/32"], "days": 2},
    )
    assert r.status_code == 201
    token = r.json()["token"]
    key = r.json()["id"]
    row = app.state.db.one("SELECT * FROM service_accounts WHERE id=?", (key,))
    assert row["token_hash"] == hashlib.sha256(token.encode()).hexdigest() and token not in json.dumps(row)
    assert token not in (await authed.get("/api/service-accounts")).text
    app.state.cfg.mode = "public"
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app, client=("198.51.100.9", 1234)),
        base_url="http://localhost:8088",
        headers={"Authorization": "Bearer " + token},
    ) as robot:
        assert (await robot.get("/api/nodes")).status_code == 200
        assert (await robot.get("/api/staff")).status_code == 403
        assert (await robot.get("/api/auth/me")).status_code == 403
        assert (await robot.post("/api/sync", json={})).status_code == 403
        app.state.db.execute("UPDATE service_accounts SET expires=0 WHERE id=?", (key,))
        assert (await robot.get("/api/nodes")).status_code == 401
        app.state.db.execute("UPDATE service_accounts SET expires=? WHERE id=?", (time.time() + 1000, key))
        assert (await authed.delete("/api/service-accounts/" + key)).status_code == 200
        assert (await robot.get("/api/nodes")).status_code == 401


async def test_invalid_bearer_never_falls_back_to_owner_cookie_without_csrf(app, authed):
    response = await authed.post(
        "/api/sync", json={}, headers={"Authorization": "Bearer gfk_invalid", "Origin": ""}
    )
    assert response.status_code == 401


@pytest.mark.parametrize(
    "scopes", [["staff.write"], ["access.write"], ["nodes.install"], ["configs.secret"], ["settings.write"]]
)
def test_machine_accounts_cannot_receive_sensitive_scopes(scopes):
    with pytest.raises(ValueError):
        ServiceCreate(name="bad-bot", scopes=scopes, allowed_cidrs=["1.1.1.1/32"])


async def test_dynamic_access_requires_gateway_and_no_self_lockout(app, authed):
    app.state.cfg.mode = "allowlist"
    app.state.cfg.allowed_cidrs = (ipaddress.ip_network("198.51.100.0/24"),)
    assert (
        await authed.put("/api/access", json={"cidrs": ["8.8.8.8/32"], "confirm": "ALLOWLIST"})
    ).status_code == 409
    app.state.cfg.gateway_token = "a" * 64
    assert (
        await authed.put("/api/access", json={"cidrs": ["8.8.8.8/32"], "confirm": "ALLOWLIST"})
    ).status_code == 200
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app, client=("198.51.100.10", 22)), base_url="http://localhost:8088"
    ) as denied:
        assert (await denied.get("/")).status_code == 403
    # Private edge endpoint cannot be forged from the internet or without its secret.
    assert (
        await authed.get("/internal/access-check", headers={"X-GhostFleet-Peer": "8.8.8.8"})
    ).status_code == 403
    assert (
        await authed.get(
            "/internal/access-check",
            headers={"X-GhostFleet-Gateway": "a" * 64, "X-GhostFleet-Peer": "8.8.8.8"},
        )
    ).status_code == 204
    assert (
        await authed.get(
            "/internal/access-check",
            headers={"X-GhostFleet-Gateway": "a" * 64, "X-GhostFleet-Peer": "9.9.9.9"},
        )
    ).status_code == 403


async def test_cloudflare_token_write_only_and_zone_binding(app, authed):
    token = "CF_TEST_ONLY_TOKEN_NOT_REAL_123456"
    r = await authed.put("/api/cloudflare/settings", json={"token": token, "allowed_zones": ["a" * 32]})
    assert r.status_code == 200 and token not in r.text
    assert token not in (await authed.get("/api/cloudflare/settings")).text
    assert token not in app.state.db.get("cloudflare_token")
    r = await authed.post(
        "/api/cloudflare/records",
        json={"zone_id": "b" * 32, "name": "node.example.com", "address": "1.1.1.1"},
    )
    assert r.status_code == 403


async def test_cloudflare_does_not_replace_foreign_record_or_enable_proxy():
    calls = []

    def handle(req):
        calls.append((req.method, req.url.path, json.loads(req.content) if req.content else {}))
        if req.url.path == "/client/v4/zones":
            result = [{"id": "a" * 32, "name": "example.com"}]
        elif req.method == "GET":
            result = [
                {
                    "id": "b" * 32,
                    "type": "A",
                    "name": "node.example.com",
                    "content": "9.9.9.9",
                    "ttl": 300,
                    "proxied": True,
                }
            ]
        else:
            result = {"id": "b" * 32, **json.loads(req.content)}
        return httpx.Response(200, json={"success": True, "result": result})

    cf = Cloudflare("TEST_ONLY_TOKEN", transport=httpx.MockTransport(handle))
    with pytest.raises(CloudflareError):
        await cf.upsert("a" * 32, "node.example.com", "1.1.1.1", 300, False)
    assert not any(c[0] == "PUT" for c in calls)
    result = await cf.upsert("a" * 32, "node.example.com", "1.1.1.1", 300, True)
    assert result["proxied"] is False and calls[-1][2]["proxied"] is False
    with pytest.raises(CloudflareError):
        await cf.upsert("a" * 32, "other-tenant.org", "1.1.1.1", 300, True)


async def test_cloudflare_redirect_and_error_body_not_echoed():
    cf = Cloudflare(
        "SECRET_TOKEN",
        transport=httpx.MockTransport(
            lambda req: httpx.Response(
                302, headers={"Location": "https://evil.example"}, text="SECRET TOKEN AND BODY"
            )
        ),
    )
    with pytest.raises(CloudflareError) as e:
        await cf.zones()
    assert "SECRET" not in str(e.value)


def test_user_sanitizer_never_exposes_subscription_credentials():
    raw = {
        "id": 10,
        "username": "test",
        "status": "ACTIVE",
        "vlessUuid": "VLESS_SECRET",
        "ssPassword": "SS_SECRET",
        "trojanPassword": "TROJAN_SECRET",
        "subscriptionUrl": "https://secret/sub",
        "userTraffic": {"usedTrafficBytes": 123},
        "hwidDeviceLimit": 3,
    }
    safe = safe_user(raw, time.time())
    assert safe["identity"] == "10" and safe["traffic_used"] == 123
    assert not any(
        secret in json.dumps(safe)
        for secret in ["VLESS_SECRET", "SS_SECRET", "TROJAN_SECRET", "https://secret/sub"]
    )


async def test_observation_never_bans_and_alerts_only_after_consecutive_samples(app, monkeypatch):
    policy = SharingPolicy(enabled=True, consecutive_samples=2).model_dump()
    app.state.db.set("sharing_policy", policy)

    class API:
        writes = 0

        async def sharing_top(self, start=0, size=100):
            return {"users": [{"id": 42, "username": "suspect", "devicesCount": 7}], "total": 1}

        async def user_action(self, *args):
            self.writes += 1
            raise AssertionError("Observe must never modify users")

    api = API()
    app.state.services.api = lambda: api
    messages = []

    async def fake_notify(*args, **kwargs):
        messages.append(args[3])

    monkeypatch.setattr("app.users.notify", fake_notify)
    await observe_sharing(app.state.services, True)
    assert not messages and app.state.db.one("SELECT flagged FROM user_observations")["flagged"] == 0
    await observe_sharing(app.state.services, True)
    await observe_sharing(app.state.services, True)
    assert len(messages) == 1 and api.writes == 0
    assert app.state.db.one("SELECT flagged FROM user_observations")["flagged"] == 1


async def test_observation_outage_does_not_invent_violations(app):
    app.state.db.set("sharing_policy", SharingPolicy(enabled=True).model_dump())

    class API:
        async def sharing_top(self, *args):
            raise RuntimeError("API down secret response")

    app.state.services.api = lambda: API()
    data = await observe_sharing(app.state.services, True)
    assert data["online"] is False and not app.state.db.query("SELECT * FROM user_observations")
    assert "secret response" not in json.dumps(data)


@pytest.mark.parametrize(
    "data",
    [
        {"egress_mbps": 1, "shaping_confirmed": True},
        {"egress_mbps": 100},
        {"congestion": "$(id)"},
        {"qdisc": "htb;sh"},
    ],
)
def test_tuning_refuses_unsafe_or_unconfirmed_values(data):
    with pytest.raises(ValueError):
        TuneSettings(**data)


async def test_config_versions_encrypted_and_activation_does_not_edit_nodes(app, authed, filled_template):
    r = await authed.post(
        "/api/config-versions", json={"name": "Before routing edit", "config": filled_template}
    )
    assert r.status_code == 201
    key = r.json()["id"]
    stored = app.state.db.one("SELECT * FROM config_versions WHERE id=?", (key,))
    assert "test-only-value" not in stored["cipher"]
    value = (await authed.get("/api/config-versions/" + key)).json()["config"]
    assert value == filled_template
    assert (await authed.post("/api/config-versions/" + key + "/activate", json={})).json()[
        "existing_nodes_changed"
    ] is False


@pytest.mark.parametrize(
    "payload",
    [
        {"congestion": "bbr;id"},
        {"qdisc": "$(sh)"},
        {"egress_mbps": 9, "shaping_confirmed": True},
        {"egress_mbps": 100, "shaping_confirmed": False},
        {"shell": "id"},
    ],
)
def test_root_agent_revalidates_tuning_payload(payload):
    from node.agent import validate_tune

    with pytest.raises(ValueError):
        validate_tune(payload)


async def test_old_agent_cannot_be_tuned_without_owner_upgrade(app, authed, monkeypatch):

    now = time.time()
    app.state.db.execute(
        "INSERT INTO nodes(id,slug,name,country,ordinal,address,managed,management_key,state,created,updated) VALUES('n','de-01','DE-01','DE',1,'1.1.1.1',1,'encrypted','active',?,?)",
        (now, now),
    )

    async def old(*args):
        return {"installed": True, "agent_version": "1.0.0"}

    monkeypatch.setattr("app.extensions.agent_call", old)
    response = await authed.post(
        "/api/nodes/n/tuning", json={"confirm": "de-01", "tuning": {"congestion": "bbr"}}
    )
    assert response.status_code == 409 and not app.state.db.query("SELECT * FROM jobs")


async def test_tuning_job_requires_ssh_health_and_ack(app, monkeypatch):
    now = time.time()
    db = app.state.db
    db.execute(
        "INSERT INTO nodes(id,slug,name,country,ordinal,address,managed,state,created,updated) VALUES('n','de-01','DE-01','DE',1,'1.1.1.1',1,'active',?,?)",
        (now, now),
    )
    payload = {"congestion": "cubic", "qdisc": "keep", "egress_mbps": None, "shaping_confirmed": False}
    db.execute(
        "INSERT INTO jobs(id,node_id,kind,state,message,payload_cipher,created,updated) VALUES('j','n','tune','queued','Queued',?,?,?)",
        (app.state.box.encrypt(json.dumps(payload), "job:j"), now, now),
    )
    calls = []

    async def fake(node, box, cfg, operation, payload=None):
        calls.append(operation)
        if operation == "tune":
            return {"pending": "a" * 32}
        if operation == "health":
            return {"installed": True}
        if operation == "tune-confirm":
            return {"confirmed": True}
        raise AssertionError(operation)

    monkeypatch.setattr("app.deployment.agent_call", fake)
    await app.state.services.run_job("j")
    job = db.one("SELECT * FROM jobs WHERE id='j'")
    assert job["state"] == "completed" and job["payload_cipher"] is None
    assert calls == ["tune", "health", "tune-confirm"]
    assert json.loads(db.one("SELECT tuning FROM nodes WHERE id='n'")["tuning"]) == payload


async def test_watchdog_not_confirmed_if_ssh_health_fails(app, monkeypatch):
    from app.ssh import SSHError

    now = time.time()
    db = app.state.db
    db.execute(
        "INSERT INTO nodes(id,slug,name,country,ordinal,address,state,created,updated) VALUES('n','de-01','DE-01','DE',1,'1.1.1.1','active',?,?)",
        (now, now),
    )
    db.execute(
        "INSERT INTO jobs(id,node_id,kind,state,message,payload_cipher,created,updated) VALUES('j','n','tune','queued','Queued',?,?,?)",
        (app.state.box.encrypt(json.dumps({"congestion": "cubic"}), "job:j"), now, now),
    )
    calls = []

    async def fake(node, box, cfg, operation, payload=None):
        calls.append(operation)
        if operation == "tune":
            return {"pending": "b" * 32}
        raise SSHError("SSH lost; rollback watchdog still active")

    monkeypatch.setattr("app.deployment.agent_call", fake)
    await app.state.services.run_job("j")
    assert db.one("SELECT state FROM jobs WHERE id='j'")["state"] == "failed"
    assert calls == ["tune", "health"]
