from __future__ import annotations

import base64
import csv
import io
import json
import time
import uuid
from types import SimpleNamespace

import asyncssh
import httpx
import pytest

from app.monitor import normalize_node, sync_nodes
from app.remnawave import Remnawave
from app.schemas import NODE_IMAGE
from app.template import parse_certificate
from tests.test_templates import certificate


def integration(app, filled_template):
    settings = {
        "remnawave_url": "https://panel.example.com",
        "remnawave_ips": "1.1.1.1/32",
        "manager_ips": "8.8.8.8/32",
        "email": "admin@example.com",
        "node_port": 2222,
        "node_image": NODE_IMAGE,
        "create_hosts": True,
        "squad_uuids": ["00000000-0000-4000-8000-000000000009"],
        "base_domain": "nodes.example.com",
        "telegram_chat_id": "",
    }
    app.state.db.set("integration", settings)
    app.state.db.set("api_token", app.state.box.encrypt("test-only-api-token-123", "setting:api_token"))
    app.state.db.set("template", app.state.box.encrypt(json.dumps(filled_template), "setting:template"))
    return settings


def add_challenge(app, authed):
    session = app.state.db.one("SELECT id FROM sessions")
    key = asyncssh.generate_private_key("ssh-ed25519")
    challenge = str(uuid.uuid4())
    app.state.db.execute(
        "INSERT INTO challenges VALUES(?,?,?,?,?,?,?)",
        (
            challenge,
            session["id"],
            "1.1.1.1",
            22,
            key.export_public_key("openssh").decode(),
            key.get_fingerprint("sha256"),
            time.time() + 600,
        ),
    )
    return {
        "challenge_id": challenge,
        "approve_host_key": True,
        "username": "root",
        "password": "SSH-TEST-PASSWORD-NOT-REAL",
        "country": "DE",
        "domain": "de-01.nodes.example.com",
    }


async def test_settings_secrets_are_write_only_and_encrypted(app, authed):
    marker = "test-only-API-secret-never-echo"
    body = {
        "remnawave_url": "https://panel.example.com",
        "api_token": marker,
        "remnawave_ips": "1.1.1.1",
        "manager_ips": "8.8.8.8",
        "email": "admin@example.com",
    }
    response = await authed.put("/api/settings", json=body)
    assert response.status_code == 200 and marker not in response.text
    assert response.json()["api_token_configured"] is True
    assert marker not in app.state.db.get("api_token")
    before = app.state.db.get("api_token")
    body["api_token"] = None
    assert (await authed.put("/api/settings", json=body)).status_code == 200
    assert app.state.db.get("api_token") == before
    assert marker not in (await authed.get("/api/settings")).text


async def test_unfilled_bridge_blocks_deployment(app, authed):
    assert (
        await authed.post(
            "/api/nodes",
            json={
                "challenge_id": str(uuid.uuid4()),
                "approve_host_key": True,
                "username": "root",
                "password": "test",
                "country": "DE",
                "domain": "node.example.com",
            },
        )
    ).status_code == 400
    assert not app.state.db.query("SELECT * FROM jobs")


async def test_queue_credentials_encrypted_and_challenge_single_use(
    app, authed, filled_template, monkeypatch
):
    integration(app, filled_template)
    monkeypatch.setattr(app.state.services, "spawn", lambda *a: None)
    body = add_challenge(app, authed)
    response = await authed.post("/api/nodes", json=body)
    assert response.status_code == 202
    job = app.state.db.one("SELECT * FROM jobs")
    assert body["password"] not in job["payload_cipher"]
    decoded = app.state.box.decrypt(job["payload_cipher"], "job:" + job["id"])
    assert json.loads(decoded)["password"] == body["password"]
    assert body["password"] not in job["logs"] and body["password"] not in job["message"]
    assert (await authed.post("/api/nodes", json=body)).status_code == 400


async def test_maintenance_blocks_changes_but_not_reads(app, authed):
    app.state.db.set("maintenance_until", time.time() + 100)
    assert (await authed.get("/api/dashboard")).status_code == 200
    assert (await authed.post("/api/sync", json={})).status_code == 503
    assert (await authed.post("/api/auth/activity", json={})).status_code == 200


async def test_api_failure_preserves_known_status_and_marks_unknown(app, authed):
    now = time.time()
    node_id = str(uuid.uuid4())
    app.state.db.execute(
        "INSERT INTO nodes(id,remnawave_uuid,slug,name,country,ordinal,address,rw_data,state,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        (
            node_id,
            node_id,
            "de-01",
            "DE-01",
            "DE",
            1,
            "1.1.1.1",
            json.dumps({"connected": True, "seen_at": now}),
            "imported",
            now,
            now,
        ),
    )
    app.state.db.set("monitor", {"online": True, "last_success": now})

    class OfflineAPI:
        async def nodes(self):
            raise RuntimeError("API outage with a test secret")

    app.state.services.api = lambda: OfflineAPI()
    status = await sync_nodes(app.state.services)
    assert status["online"] is False and status["last_success"] == now
    assert json.loads(app.state.db.one("SELECT rw_data FROM nodes")["rw_data"])["connected"] is True
    dashboard = (await authed.get("/api/dashboard")).json()
    assert dashboard["nodes"][0]["status"] == "unknown"
    assert dashboard["summary"]["users_online"] is None and dashboard["summary"]["online"] is None
    assert "test secret" not in status["error"]


def test_only_safe_numeric_fields_saved_from_remnawave():
    raw = {
        "isConnected": True,
        "usersOnline": "NaN",
        "trafficUsedBytes": "Infinity",
        "lastStatusMessage": "A PRIVATE KEY",
        "configProfile": {"privateKey": "secret"},
        "system": {"info": {"memoryTotal": 100}, "stats": {"memoryUsed": 40}},
    }
    safe = normalize_node(raw, time.time())
    assert safe["users_online"] is None and safe["traffic_used"] is None
    assert "PRIVATE KEY" not in json.dumps(safe) and "privateKey" not in json.dumps(safe)


async def test_csv_formula_injection_neutralized(app, authed):
    now = time.time()
    app.state.db.execute(
        "INSERT INTO nodes(id,slug,name,country,ordinal,address,notes,created,updated) VALUES('node','node-01','=HYPERLINK(test)','DE',1,'1.1.1.1','@danger',?,?)",
        (now, now),
    )
    response = await authed.get("/api/nodes/export")
    data = list(csv.reader(io.StringIO(response.text.lstrip("\ufeff"))))
    assert data[1][0].startswith("'=") and data[1][-1].startswith("'@")
    assert "password" not in response.text.lower()


@pytest.mark.parametrize("nonroot", [False, True])
async def test_full_deployment_pipeline_with_contract_mock_and_ephemeral_credentials(
    app, authed, filled_template, monkeypatch, nonroot
):
    settings = integration(app, filled_template)
    services = app.state.services
    monkeypatch.setattr(services, "spawn", lambda *a: None)
    body = add_challenge(app, authed)
    response = await authed.post("/api/nodes", json=body)
    assert response.status_code == 202
    job_id = response.json()["job_id"]
    node_id = response.json()["node_id"]
    root_chain, private_key, root = certificate(body["domain"])
    calls = []
    profiles = {}
    remote_nodes = []
    hosts = []
    squad_inbounds = ["00000000-0000-4000-8000-000000000008"]
    secret_key = base64.b64encode(b"TEST ONLY NODE MTLS PAYLOAD NOT REAL").decode()

    def handler(request):
        method, path = request.method, request.url.path.removeprefix("/api")
        payload = json.loads(request.content) if request.content else {}
        calls.append((method, path, payload))
        if path == "/system/metadata":
            result = {"version": "3.4.4"}
        elif path == "/keygen":
            result = {"secretKey": secret_key}
        elif path == "/nodes" and method == "GET":
            result = remote_nodes
        elif path == "/config-profiles" and method == "POST":
            profile_id = str(uuid.uuid4())
            config = payload["config"]
            inbounds = [{"uuid": str(uuid.uuid4()), "tag": i["tag"]} for i in config["inbounds"]]
            result = {"uuid": profile_id, "config": config, "inbounds": inbounds, "nodes": []}
            profiles[profile_id] = result
        elif path == "/nodes" and method == "POST":
            assert payload["configProfile"]["activeInbounds"]
            result = {"uuid": str(uuid.uuid4()), **payload}
            remote_nodes.append(result)
        elif path.endswith("/actions/restart"):
            # Mirrors the real contract: forceRestart is a required body field,
            # and a successful restart replies 202 with an EMPTY body.
            assert payload == {"forceRestart": False}
            return httpx.Response(202)
        elif path.startswith("/internal-squads/") and method == "GET":
            result = {"uuid": settings["squad_uuids"][0], "inbounds": [{"uuid": i} for i in squad_inbounds]}
        elif path == "/internal-squads" and method == "PATCH":
            squad_inbounds[:] = payload["inbounds"]
            result = payload
        elif path == "/hosts" and method == "GET":
            result = hosts
        elif path == "/hosts" and method == "POST":
            result = {"uuid": str(uuid.uuid4()), **payload}
            hosts.append(result)
        else:
            raise AssertionError((method, path))
        return httpx.Response(200, json={"response": result})

    api = Remnawave(
        settings["remnawave_url"],
        "test-only-api-token-123",
        app.state.cfg,
        transport=httpx.MockTransport(handler),
    )
    services.api = lambda: api

    async def fake_dns(*a):
        return ["1.1.1.1"]

    async def fake_source():
        return b"test-only pinned script fixture"

    monkeypatch.setattr("app.deployment.verify_dns", fake_dns)
    monkeypatch.setattr("app.deployment.fetch_installer", fake_source)
    monkeypatch.setattr("app.deployment.fetch_acme", fake_source)
    monkeypatch.setattr(
        "app.deployment.parse_certificate", lambda c, k, d: parse_certificate(c, k, d, trusted_roots=[root])
    )
    uploaded = {}
    commands = []

    class File:
        def __init__(self, path):
            self.path = path

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            return None

        async def write(self, data):
            uploaded[self.path] = data

    class SFTP:
        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            return None

        def open(self, path, mode):
            return File(path)

        async def chmod(self, path, mode):
            assert mode == 0o600

    class Reader:
        def __init__(self, output):
            self.output = output

        async def read(self, size):
            result = self.output
            self.output = ""
            return result

    class Process:
        exit_status = 0
        stdout = Reader("GF_STEP 2\nGF_STEP 3\n" + body["password"] + "\nGF_STEP 4\nGF_DONE\n")
        stderr = Reader(secret_key)

        async def wait_closed(self):
            return None

    class Connection:
        async def run(self, command, **kwargs):
            commands.append(command)
            return SimpleNamespace(
                exit_status=0, stdout=("1000\n" if nonroot and command == "id -u" else "0\n")
            )

        def start_sftp_client(self):
            return SFTP()

        async def create_process(self, command, **kwargs):
            commands.append(command)
            return Process()

    from contextlib import asynccontextmanager

    @asynccontextmanager
    async def fake_connect(address, port, pin, credentials, cfg):
        assert address == "1.1.1.1" and credentials["password"] == body["password"]
        yield Connection()

    monkeypatch.setattr("app.deployment.connect", fake_connect)

    async def fake_agent(node, box, cfg, operation, payload=None):
        if operation == "health":
            return {"instance_id": app.state.db.get("instance_id"), "node_id": node_id, "installed": True}
        if operation == "certificates":
            return {"fullchain": root_chain, "private_key": private_key}
        raise AssertionError(operation)

    monkeypatch.setattr("app.deployment.agent_call", fake_agent)
    await services.run_job(job_id)
    job = app.state.db.one("SELECT * FROM jobs WHERE id=?", (job_id,))
    node = app.state.db.one("SELECT * FROM nodes WHERE id=?", (node_id,))
    assert job["state"] == "completed", job["message"]
    assert job["payload_cipher"] is None
    assert (
        body["password"] not in job["logs"]
        and secret_key not in job["logs"]
        and private_key not in job["logs"]
    )
    assert not any(body["password"] in c for c in commands)
    params = json.loads(next(data for path, data in uploaded.items() if path.endswith("/params.json")))
    assert params["secret_key"] == secret_key and body["password"] not in json.dumps(params)
    assert "management_private_key" not in params
    assert node["state"] == "waiting" and node["remnawave_uuid"] and node["profile_uuid"]
    assert private_key not in node["config_cipher"]
    assert len(hosts) == 2 and len(squad_inbounds) == 3
    assert all(h["sni"] == body["domain"] for h in hosts)
    profile = profiles[node["profile_uuid"]]
    assert [i["tag"] for i in profile["config"]["inbounds"]] == ["de-01-grpc", "de-01-hy2"]
    assert (
        profile["config"]["inbounds"][0]["streamSettings"]["tlsSettings"]["certificates"][0]["key"][0]
        == "-----BEGIN PRIVATE KEY-----"
    )


async def test_api_url_change_does_not_forward_existing_token(app, authed):
    original = {
        "remnawave_url": "https://panel.example.com",
        "api_token": "old-test-token-for-first-server",
        "remnawave_ips": "1.1.1.1",
        "manager_ips": "8.8.8.8",
        "email": "admin@example.com",
    }
    assert (await authed.put("/api/settings", json=original)).status_code == 200
    original["remnawave_url"] = "https://different.example.com"
    original["api_token"] = None
    assert (await authed.put("/api/settings", json=original)).status_code == 400
    assert app.state.db.get("integration")["remnawave_url"] == "https://panel.example.com/api"
    assert (
        app.state.box.decrypt(app.state.db.get("api_token"), "setting:api_token")
        == "old-test-token-for-first-server"
    )


async def test_failed_job_keeps_progress_clears_payload_and_discards_unexpected_exception(app):

    now = time.time()
    db = app.state.db
    db.execute(
        "INSERT INTO nodes(id,slug,name,country,ordinal,address,state,created,updated) VALUES('node','de-01','DE-01','DE',1,'1.1.1.1','queued',?,?)",
        (now, now),
    )
    db.execute(
        "INSERT INTO jobs(id,node_id,kind,state,message,payload_cipher,created,updated) VALUES('job','node','deploy','queued','Queued',?,?,?)",
        (app.state.box.encrypt(json.dumps({"password": "secret-only-in-cipher"}), "job:job"), now, now),
    )

    async def fail(job, params):
        db.job_progress("job", 60, "Installing restricted agent")
        raise RuntimeError("RAW PASSWORD MUST NEVER APPEAR IN JOB")

    app.state.services.deploy = fail
    await app.state.services.run_job("job")
    job = db.one("SELECT * FROM jobs WHERE id='job'")
    assert job["state"] == "failed" and job["step"] == 60 and job["payload_cipher"] is None
    assert "RAW PASSWORD" not in job["message"] and "RAW PASSWORD" not in job["logs"]


async def test_oversize_request_rejected_without_echo(app, client):
    marker = "THIS_MUST_NOT_BE_ECHOED"
    response = await client.post(
        "/api/auth/login",
        content=marker + "a" * (1024 * 1024),
        headers={"Content-Type": "application/json", "Origin": app.state.cfg.public_url},
    )
    assert response.status_code == 413 and marker not in response.text


async def test_restart_endpoint_succeeds_with_correct_permissions_and_keys(app, authed):
    # Regression test for the real-world bug report: an owner with correct
    # RBAC permissions and a healthy, key-managed node still got an error on
    # restart, because the backend requires a "forceRestart" body field that
    # was never sent, and/or chokes decoding Remnawave's empty 202 reply.
    now = time.time()
    app.state.db.execute(
        "INSERT INTO nodes(id,remnawave_uuid,slug,name,country,ordinal,address,managed,"
        "management_key,state,created,updated) VALUES"
        "('n','00000000-0000-4000-8000-000000000099','de-01','DE-01','DE',1,'1.1.1.1',1,"
        "'encrypted','active',?,?)",
        (now, now),
    )
    seen = []

    async def handler(request):
        body = json.loads(request.content) if request.content else None
        seen.append((request.method, request.url.path, body))
        return httpx.Response(202)

    api = Remnawave(
        "https://panel.example.com", "test-token", app.state.cfg, transport=httpx.MockTransport(handler)
    )
    app.state.services.api = lambda: api

    response = await authed.post("/api/nodes/n/actions", json={"action": "restart", "confirm": "de-01"})
    assert response.status_code == 202 and response.json()["ok"] is True
    assert seen == [
        ("POST", "/api/nodes/00000000-0000-4000-8000-000000000099/actions/restart", {"forceRestart": False})
    ]

    response = await authed.post(
        "/api/nodes/n/actions", json={"action": "restart", "confirm": "de-01", "force": True}
    )
    assert response.status_code == 202
    assert seen[-1][2] == {"forceRestart": True}
