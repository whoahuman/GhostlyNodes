from __future__ import annotations

import asyncio
import json

import httpx
import pytest
import pytest_asyncio

from app.config import Config
from app.db import Database
from app.main import create_app
from app.security import PASSWORD_HASHER, SecretBox, new_session

PASSWORD = "A test-only password phrase 2026"


@pytest.fixture
def app(tmp_path, monkeypatch):
    from app import security

    monkeypatch.setattr(security, "PASSWORD_WORKERS", asyncio.Semaphore(2))
    cfg = Config(
        data_dir=tmp_path / "state",
        public_url="http://localhost:8088",
        mode="tunnel",
        trusted_hosts={"localhost", "127.0.0.1"},
    )
    db = Database(cfg.db_path)
    db.init()
    SecretBox.create(cfg.key_path)
    db.execute(
        "INSERT INTO admins(id,username,password_hash) VALUES(1,?,?)",
        ("admin", PASSWORD_HASHER.hash(PASSWORD)),
    )
    return create_app(cfg, background=False)


@pytest_asyncio.fixture
async def client(app):
    transport = httpx.ASGITransport(app=app, client=("127.0.0.1", 32100))
    client = httpx.AsyncClient(
        transport=transport,
        base_url="http://localhost:8088",
        headers={"Origin": "http://localhost:8088", "User-Agent": "GhostFleet tests"},
    )
    yield client
    await client.aclose()
    await app.state.services.shutdown()


@pytest_asyncio.fixture
async def authed(app, client):
    token, session = new_session(app.state.db, app.state.cfg, "127.0.0.1", "GhostFleet tests", "full")
    client.cookies.set(app.state.cfg.cookie_name, token, domain="localhost.local", path="/")
    client.headers["X-CSRF-Token"] = session["csrf"]
    yield client


@pytest.fixture
def filled_template():
    from app.template import DEFAULT_TEMPLATE

    data = json.loads(DEFAULT_TEMPLATE.read_text())

    def replace(value):
        if isinstance(value, dict):
            return {k: replace(v) for k, v in value.items()}
        if isinstance(value, list):
            return [replace(v) for v in value]
        if isinstance(value, str) and value.startswith("REPLACE_WITH_"):
            return "test-only-value"
        return value

    return replace(data)


@pytest.fixture
def filled_reality_template():
    from app.template import DEFAULT_TEMPLATE

    data = json.loads((DEFAULT_TEMPLATE.parent / "xray.reality.example.json").read_text())
    reality = data["inbounds"][0]["streamSettings"]["realitySettings"]
    reality["privateKey"] = "sNq6cxQglOStXgswNP3WviC-EL-apXYcLnWybSUHt1c"
    reality["shortIds"] = ["b4ee3de3191be344"]
    bridge = data["outbounds"][1]["settings"]
    bridge["id"] = "00000000-0000-4000-8000-000000000000"
    bridge["address"] = "bridge.example.com"
    bridge_reality = data["outbounds"][1]["streamSettings"]["realitySettings"]
    bridge_reality["shortId"] = "0000000000000000"
    bridge_reality["publicKey"] = "yjnI4qiWpCIowEFrEztnTvQ4JhcsuAt_jI6PfFhsMgY"
    bridge_reality["serverName"] = "bridge.example.com"
    return data
