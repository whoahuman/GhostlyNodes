#!/usr/bin/env python3
"""Generate an Xray REALITY keypair + shortId, offline, with no third-party tools.

Usage:
    python3 scripts/gen-reality-keys.py

Prints a privateKey (put it in the server-side xray.json inbound — keep secret),
a publicKey (give it to clients, NOT secret), and a shortId (put in both, must
match). Output is equivalent to `xray x25519` + a random shortId; you do not
need the xray binary installed to run this.

This never talks to the network and never writes anything to disk.
"""
from __future__ import annotations

import base64
import secrets

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey


def b64url_nopad(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def main() -> None:
    private_key = X25519PrivateKey.generate()
    public_key = private_key.public_key()
    private_raw = private_key.private_bytes(
        serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption()
    )
    public_raw = public_key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    short_id = secrets.token_hex(8)  # 16 hex chars; shorter (e.g. 4-8 chars) also works

    print("privateKey (server xray.json realitySettings.privateKey, KEEP SECRET):")
    print(" ", b64url_nopad(private_raw))
    print()
    print("publicKey (give to clients / Remnawave Host 'fp'/'pbk' field, NOT secret):")
    print(" ", b64url_nopad(public_raw))
    print()
    print("shortId (put in server shortIds list AND client config, NOT secret):")
    print(" ", short_id)
    print()
    print("Pick a serverNames/dest target yourself — see docs/STEALTH.md for the trade-offs")
    print("before choosing one. Do not reuse this key across unrelated nodes/projects.")


if __name__ == "__main__":
    main()
