#!/usr/bin/env bash
# Root adapter for the pinned Ghostly installer. It never receives SSH passwords.
set -Eeuo pipefail
umask 077
export HOME=/root DEBIAN_FRONTEND=noninteractive
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
[[ "$HERE" =~ ^/tmp/gf-[a-f0-9]{32}$ ]] || { echo 'Invalid temporary directory' >&2; exit 70; }
[[ $EUID -eq 0 ]] || { echo 'root/sudo required' >&2; exit 71; }
exec 9>/run/ghostfleet-install.lock
flock -n 9 || { echo 'Another installation is running' >&2; exit 73; }
trap 'rm -rf -- "$HERE"' EXIT
# shellcheck disable=SC1091
. /etc/os-release
case "${ID}:${VERSION_ID}" in
  ubuntu:22.04|ubuntu:24.04|debian:12|debian:13) ;;
  *) echo 'Only Ubuntu 22.04/24.04 and Debian 12/13 are supported' >&2; exit 72 ;;
esac
# Refuse to take over somebody else's node or Docker configuration.
if [[ -e /opt/remnanode/.env && ! -f /etc/ghostfleet-node.json ]]; then
  echo 'Existing unmanaged Remnanode detected. Refusing to overwrite it.' >&2; exit 74
fi
printf 'GF_STEP 2\n'
apt-get update -qq
apt-get install -y -qq python3 ca-certificates curl gnupg openssl cron socat iproute2 procps >/dev/null
python3 - "$HERE" <<'PY'
import hashlib, json, os, re, shlex, sys
from pathlib import Path
p = Path(sys.argv[1]); payload = json.loads((p / 'params.json').read_text())
meta_path = Path('/etc/ghostfleet-node.json')
if meta_path.exists():
    old = json.loads(meta_path.read_text())
    if old.get('instance_id') != payload['instance_id'] or old.get('node_id') != payload['node_id']:
        raise SystemExit('Node belongs to a different control plane')
raw = (p / 'upstream.sh').read_bytes()
if hashlib.sha256(raw).hexdigest() != '372d67e2ae0432a1dbe7bd5cbb4238ad1e45c0c241cc8ab582730d676826f138':
    raise SystemExit('Upstream SHA256 mismatch')
image = payload['node_image']
if not re.fullmatch(r'remnawave/node:(?:[0-9]+\.[0-9]+\.[0-9]+|latest)(?:@sha256:[a-f0-9]{64})?', image):
    raise SystemExit('Invalid image')
if raw.count(b'image: remnawave/node:latest') != 1:
    raise SystemExit('Upstream changed: review adapter')
(p / 'upstream.sh').write_bytes(raw.replace(b'image: remnawave/node:latest', ('image: ' + image).encode()))
fields = {
    'DOMAIN': payload['domain'], 'LE_EMAIL': payload['email'],
    'NODE_PORT': str(payload['node_port']), 'PANEL_IPS': payload['remnawave_ips'],
    'SSH_PORT': str(payload['ssh_port']), 'GHOSTLY_SECRET_KEY': payload['secret_key'],
    'USE_FAIL2BAN': '1' if payload.get('options',{}).get('fail2ban',True) else '0',
    'USE_FLOOD': '1' if payload.get('options',{}).get('flood',True) else '0',
}
if not re.fullmatch(r'[A-Za-z0-9+/=_-]{20,10000}', fields['GHOSTLY_SECRET_KEY']):
    raise SystemExit('Invalid SECRET_KEY format')
if not re.fullmatch(r'[a-z0-9.-]{3,253}', fields['DOMAIN']):
    raise SystemExit('Invalid domain')
(p / 'vars.sh').write_text('\n'.join('export ' + k + '=' + shlex.quote(v) for k, v in fields.items()) + '\n')
os.chmod(p / 'vars.sh', 0o600)
meta = {k: payload[k] for k in ('instance_id','node_id','domain','node_image','name','manager_ips')}
meta['installed'] = False
meta_path.write_text(json.dumps(meta)); os.chmod(meta_path, 0o600)
PY
# shellcheck disable=SC1091
. "$HERE/vars.sh"

# Signed official Docker APT packages. Never overwrite daemon.json or restart an
# already-running Docker daemon just to change its logging settings.
if ! command -v docker >/dev/null 2>&1; then
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL --proto '=https' --tlsv1.2 "https://download.docker.com/linux/${ID}/gpg" -o "$HERE/docker.asc"
  FPR="$(gpg --show-keys --with-colons "$HERE/docker.asc" | awk -F: '$1=="fpr" {print $10; exit}')"
  [[ "$FPR" == '9DC858229FC7DD38854AE2D88D81803C0EBFCD88' ]] || { echo 'Docker signing key changed; review required' >&2; exit 75; }
  cp "$HERE/docker.asc" /etc/apt/keyrings/ghostfleet-docker.asc
  chmod 0644 /etc/apt/keyrings/ghostfleet-docker.asc
  ARCH="$(dpkg --print-architecture)"
  CODENAME="${VERSION_CODENAME:?}"
  [[ "$CODENAME" =~ ^[a-z]+$ && "$ARCH" =~ ^[a-z0-9]+$ ]] || exit 76
  printf 'deb [arch=%s signed-by=/etc/apt/keyrings/ghostfleet-docker.asc] https://download.docker.com/linux/%s %s stable\n' "$ARCH" "$ID" "$CODENAME" >/etc/apt/sources.list.d/ghostfleet-docker.list
  apt-get update -qq
  apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-compose-plugin >/dev/null
  systemctl enable --now docker >/dev/null
fi
docker compose version >/dev/null || { echo 'Docker Compose v2 is required' >&2; exit 77; }

# Fresh acme.sh installation is pinned too. Preserve an owner's existing ACME installation.
if [[ ! -x /root/.acme.sh/acme.sh ]]; then
  [[ "$(sha256sum "$HERE/acme.tar.gz" | awk '{print $1}')" == 'ddbe1bcbd1a44a2623a2af167ebdc678669e6e2eb396742f2d1d28e02dc14220' ]] || { echo 'acme.sh checksum mismatch' >&2; exit 79; }
  mkdir -m 0700 "$HERE/acme-source"
  tar -xzf "$HERE/acme.tar.gz" --strip-components=1 -C "$HERE/acme-source" --no-same-owner
  ( cd "$HERE/acme-source" && bash acme.sh --install --home /root/.acme.sh --accountemail "$LE_EMAIL" --auto-upgrade 0 )
  [[ -x /root/.acme.sh/acme.sh ]] || exit 79
fi
systemctl enable --now cron >/dev/null 2>&1 || true
printf 'GF_STEP 3\n'
# Shell arguments contain no secrets; GHOSTLY_SECRET_KEY is passed in the environment.
# Password SSH hardening is deliberately NOT enabled: never lock out an owner.
security_flags=()
if [[ "$USE_FAIL2BAN" == 1 ]]; then security_flags+=(--fail2ban); else security_flags+=(--no-fail2ban); fi
if [[ "$USE_FLOOD" == 1 ]]; then security_flags+=(--flood); else security_flags+=(--no-flood); fi
bash "$HERE/upstream.sh" --yes --reconfigure \
  --domain "$DOMAIN" --email "$LE_EMAIL" --acme standalone \
  --node-port "$NODE_PORT" --panel-ip "$PANEL_IPS" --ssh-port "$SSH_PORT" \
  --tcp-ports 80,443 --udp-ports 443 --strict "${security_flags[@]}" \
  --no-crowdsec --no-selfsteal --skip-selfsteal --skip-docker
unset GHOSTLY_SECRET_KEY

# The upstream script tolerates an ACME error. This adapter does not.
[[ -s /opt/remnanode/certs/fullchain.pem && -s /opt/remnanode/certs/privkey.key ]] || { echo 'TLS certificate was not issued. Check DNS and TCP/80.' >&2; exit 78; }
openssl x509 -in /opt/remnanode/certs/fullchain.pem -noout -checkend 3600 >/dev/null || exit 78
printf 'GF_STEP 4\n'
install -m 0700 -d /usr/local/lib/ghostfleet-node
install -m 0700 "$HERE/agent.py" /usr/local/lib/ghostfleet-node/agent.py
install -m 0755 -d /opt/ghostfleet-node/www
cat >/opt/ghostfleet-node/www/index.html <<'HTML'
<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Service available</title><body><h1>Service available</h1><p>This endpoint is operating normally.</p></body></html>
HTML
chmod 0644 /opt/ghostfleet-node/www/index.html
python3 - "$HERE" <<'PY'
import ipaddress, json, os, re, sys
from pathlib import Path
p = Path(sys.argv[1]); params = json.loads((p / 'params.json').read_text())
image = params['node_image']
if not re.fullmatch(r'remnawave/node:(?:[0-9]+\.[0-9]+\.[0-9]+|latest)(?:@sha256:[a-f0-9]{64})?', image):
    raise SystemExit('Invalid node image')
override = {'services': {'remnanode': {
    'image': image,
    'volumes': ['/opt/remnanode/certs:/ssl:ro', '/opt/remnanode/certs:/var/lib/remnawave/configs/xray/ssl:ro', '/opt/ghostfleet-node/www:/var/www:ro'],
    'logging': {'driver': 'json-file', 'options': {'max-size': '50m', 'max-file': '3'}},
    'ulimits': {'nofile': {'soft': 1048576, 'hard': 1048576}},
}}}
Path('/opt/remnanode/ghostfleet.override.json').write_text(json.dumps(override))
os.chmod('/opt/remnanode/ghostfleet.override.json', 0o600)
key = params['management_public_key']
if not re.fullmatch(r'ssh-ed25519 [A-Za-z0-9+/=]+', key):
    raise SystemExit('Invalid management public key')
ips = [ipaddress.ip_network(v.strip(), strict=False) for v in params['manager_ips'].split(',')]
if not ips or any(n.prefixlen == 0 or n.network_address.is_loopback or n.network_address.is_link_local for n in ips):
    raise SystemExit('Invalid manager IP allowlist')
marker = 'ghostfleet:' + params['instance_id'] + ':' + params['node_id']
if not re.fullmatch(r'ghostfleet:[a-f0-9-]{36}:[a-f0-9-]{36}', marker):
    raise SystemExit('Invalid key marker')
dir = Path('/root/.ssh'); target = dir / 'authorized_keys'
if dir.is_symlink() or target.is_symlink():
    raise SystemExit('Symlink in root authorized_keys path')
dir.mkdir(mode=0o700, exist_ok=True); os.chmod(dir, 0o700)
previous = target.read_text().splitlines() if target.exists() else []
previous = [line for line in previous if not line.rstrip().endswith(' ' + marker)]
options = 'restrict,from="' + ','.join(map(str, ips)) + '",command="/usr/bin/python3 /usr/local/lib/ghostfleet-node/agent.py"'
previous.append(options + ' ' + key + ' ' + marker)
target.write_text('\n'.join(previous) + '\n'); os.chmod(target, 0o600)
PY
cd /opt/remnanode
docker compose -f docker-compose.yml -f ghostfleet.override.json config -q
docker compose -f docker-compose.yml -f ghostfleet.override.json up -d
running=0
for _attempt in $(seq 1 15); do
  if [[ "$(docker inspect --format '{{.State.Running}}' remnanode 2>/dev/null || true)" == true ]]; then running=1; break; fi
  sleep 2
done
((running)) || { echo 'Remnanode container is not running' >&2; exit 80; }
python3 - <<'PY'
import json
from pathlib import Path
p=Path('/etc/ghostfleet-node.json'); d=json.loads(p.read_text()); d['installed']=True; p.write_text(json.dumps(d))
PY
printf 'GF_DONE\n'
