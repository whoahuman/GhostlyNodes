#!/usr/bin/env bash
# Read-only self-audit for a GhostFleet-managed node. Run it manually on the node
# (as root, or with sudo) to see roughly what an outside prober would see.
#
#   ssh root@your-node 'bash -s' < node/stealth-check.sh
#
# It changes NOTHING: no firewall rules, no service restarts, no file writes
# other than a temp scratch dir it cleans up. It is a diagnostic aid, not a
# guarantee — see docs/STEALTH.md for what is and is not checked here, and
# for the parts of active-probing resistance that no script can verify
# (state-level traffic analysis, volume/pattern fingerprinting, etc).
set -Eeuo pipefail

bold() { printf '\033[1m%s\033[0m\n' "$*"; }
ok()   { printf '  [OK]   %s\n' "$*"; }
warn() { printf '  [!!]   %s\n' "$*"; }
info() { printf '  [--]   %s\n' "$*"; }

bold "1) Listening ports (what is reachable from the internet)"
if command -v ss >/dev/null; then
  ss -Hltnp 2>/dev/null | awk '{print $4}' | sed 's/.*://' | sort -un | while read -r port; do
    case "$port" in
      443) info "tcp/443 — expected (VLESS/REALITY/Hysteria2)";;
      80)  warn "tcp/80 open — only needed transiently for Let's Encrypt; closing it between renewals reduces scan surface";;
      22|2222) info "tcp/$port — SSH-family; confirm it is allowlisted to your manager IP only (see below)";;
      *) warn "tcp/$port open and NOT one of the expected ports — investigate what is listening";;
    esac
  done
  ss -Hlunp 2>/dev/null | awk '{print $4}' | sed 's/.*://' | sort -un | while read -r port; do
    if [[ "$port" == 443 ]]; then
      info "udp/443 — Hysteria2/QUIC is active; this is UDP/QUIC fingerprintable by DPI. Remove it from your template if you do not need it"
    else
      warn "udp/$port open — unexpected UDP listener"
    fi
  done
else
  warn "ss not found; cannot enumerate listening ports"
fi

bold "2) NODE_PORT (Remnanode mTLS management) exposure"
if command -v ufw >/dev/null && ufw status 2>/dev/null | grep -q .; then
  ufw status | grep -E '2222|NODE_PORT' || info "no explicit NODE_PORT rule found via ufw status (may be filtered another way)"
else
  info "ufw not in use or not installed; verify your firewall layer restricts the management port to the Remnawave panel IP only"
fi

bold "3) TLS/HTTP answer on the main port (does probing it look like a real site?)"
if command -v openssl >/dev/null; then
  answer=$(echo | timeout 5 openssl s_client -connect 127.0.0.1:443 -servername "$(hostname -f 2>/dev/null || hostname)" 2>/dev/null | openssl x509 -noout -subject 2>/dev/null || true)
  if [[ -n "$answer" ]]; then
    warn "A certificate for THIS host was presented locally: $answer"
    warn "If this is also what a remote prober sees (not REALITY), your own domain's cert is visible on the wire — see docs/STEALTH.md on REALITY vs. own-cert TLS"
  else
    info "No parseable local certificate handshake captured (expected for REALITY — it will show the camouflaged dest's cert to a real client of its own, not to this loopback probe)"
  fi
else
  warn "openssl not found; cannot probe local TLS behaviour"
fi

bold "4) DNS / IP consistency (only relevant if you run the classic TLS template, not REALITY)"
if [[ -f /etc/ghostfleet-node.json ]] && command -v python3 >/dev/null; then
  python3 - <<'PY'
import json, socket, sys
try:
    meta = json.load(open('/etc/ghostfleet-node.json'))
except Exception:
    sys.exit(0)
domain = meta.get('domain')
if not domain:
    print('  [--]   no domain recorded (REALITY-only install, or domain-less by design)')
    sys.exit(0)
try:
    resolved = sorted(set(i[4][0] for i in socket.getaddrinfo(domain, None)))
    print(f"  [--]   {domain} currently resolves to: {', '.join(resolved)}")
    print('  [--]   confirm this matches the node\'s actual public IP as seen by Remnawave')
except Exception as e:
    print(f'  [!!]   could not resolve {domain}: {e}')
PY
else
  info "no /etc/ghostfleet-node.json or python3; skipping"
fi

bold "Summary"
info "This script only checks mechanical, verifiable signals. It cannot tell you whether"
info "a state-level DPI/SORM system with full traffic visibility will flag this node based"
info "on volume, timing, or behavioural patterns — nothing running on the node itself can."
