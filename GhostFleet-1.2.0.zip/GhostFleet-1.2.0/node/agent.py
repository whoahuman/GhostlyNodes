#!/usr/bin/env python3
"""Root-side, forced-command agent. No shell, SFTP, forwarding, PTY or arbitrary argv."""

from __future__ import annotations

import json
import os
import re

# forced-command agent; fixed argv, never shell=True
import subprocess  # nosec B404
import sys
import time
from pathlib import Path

META = Path("/etc/ghostfleet-node.json")
NODE = Path("/opt/remnanode")
IMAGE_PATTERN = re.compile(r"^remnawave/node:(?:[0-9]+\.[0-9]+\.[0-9]+|latest)(?:@sha256:[a-f0-9]{64})?$")


def run(args: list[str], timeout: int = 20, allow_nonzero: bool = False) -> str:
    result = subprocess.run(
        # internal fixed argv only; untrusted image is separately validated
        args,  # nosec B603
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
        env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "HOME": "/root"},
    )
    if result.returncode and not allow_nonzero:
        raise RuntimeError("Operation failed")
    return result.stdout[:200_000]


def cpu_ticks() -> tuple[int, int]:
    numbers = list(map(int, Path("/proc/stat").read_text().splitlines()[0].split()[1:9]))
    return sum(numbers), numbers[3] + numbers[4]


def metrics() -> dict:
    total, idle = cpu_ticks()
    time.sleep(0.25)
    total2, idle2 = cpu_ticks()
    cpu = 100 * (1 - (idle2 - idle) / max(1, total2 - total))
    memory = {}
    for line in Path("/proc/meminfo").read_text().splitlines():
        key, rest = line.split(":", 1)
        memory[key] = int(rest.split()[0]) * 1024
    disk = os.statvfs("/")
    disk_total = disk.f_blocks * disk.f_frsize
    disk_free = disk.f_bavail * disk.f_frsize
    stats = {
        "cpu_pct": round(max(0, min(100, cpu)), 1),
        "load": os.getloadavg()[0],
        "memory_total": memory.get("MemTotal", 0),
        "memory_available": memory.get("MemAvailable", 0),
        "disk_total": disk_total,
        "disk_used": disk_total - disk_free,
        "uptime": float(Path("/proc/uptime").read_text().split()[0]),
        "container_running": run(
            ["/usr/bin/docker", "inspect", "--format", "{{.State.Running}}", "remnanode"], allow_nonzero=True
        ).strip()
        == "true",
    }
    return stats


def certificates() -> dict:
    return {
        "fullchain": (NODE / "certs/fullchain.pem").read_text(),
        "private_key": (NODE / "certs/privkey.key").read_text(),
    }


def logs() -> dict:
    # fixed docker logs command, no user argv
    result = subprocess.run(  # nosec B603
        ["/usr/bin/docker", "logs", "--tail", "100", "--timestamps", "remnanode"],
        capture_output=True,
        text=True,
        timeout=20,
        check=False,
    )
    text = (result.stdout + result.stderr)[-100_000:]
    text = re.sub(
        r"-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----",
        "<PRIVATE KEY OMITTED>",
        text,
    )
    text = re.sub(r"(?i)(SECRET_KEY|password|token)\s*[=:]\s*[^\s,;]+", r"\1=<REDACTED>", text)
    return {"logs": text}


def update() -> dict:
    content = sys.stdin.read(65537)
    if len(content) > 65536:
        raise ValueError("Payload too large")
    data = json.loads(content)
    if (
        set(data) != {"image"}
        or not isinstance(data["image"], str)
        or not IMAGE_PATTERN.fullmatch(data["image"])
    ):
        raise ValueError("Invalid image")
    path = NODE / "ghostfleet.override.json"
    override = json.loads(path.read_text())
    previous_image = override["services"]["remnanode"]["image"]
    override["services"]["remnanode"]["image"] = data["image"]
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(override))
    os.chmod(temp, 0o600)
    os.replace(temp, path)
    compose = ["/usr/bin/docker", "compose", "-f", str(NODE / "docker-compose.yml"), "-f", str(path)]
    try:
        run([*compose, "pull", "remnanode"], timeout=600)
        run([*compose, "up", "-d", "remnanode"], timeout=120)
    except Exception:
        override["services"]["remnanode"]["image"] = previous_image
        temp.write_text(json.dumps(override))
        os.chmod(temp, 0o600)
        os.replace(temp, path)
        # A failed pull/start restores the previous desired image.
        run([*compose, "up", "-d", "remnanode"], timeout=120, allow_nonzero=True)
        raise
    metadata = json.loads(META.read_text())
    metadata["node_image"] = data["image"]
    META.write_text(json.dumps(metadata))
    os.chmod(META, 0o600)
    return {"updated": True, "image": data["image"]}


TUNE_DIR = Path("/var/lib/ghostfleet-node")
SYSCTLS = {
    "congestion": ("net.ipv4.tcp_congestion_control", Path("/proc/sys/net/ipv4/tcp_congestion_control")),
    "qdisc": ("net.core.default_qdisc", Path("/proc/sys/net/core/default_qdisc")),
}


def health():
    return {
        **json.loads(META.read_text()),
        "agent_version": "1.1.0",
        "capabilities": ["health", "metrics", "certificates", "logs", "update", "tune", "tune-confirm"],
    }


def read_payload():
    content = sys.stdin.read(65537)
    if len(content) > 65536:
        raise ValueError("Payload too large")
    data = json.loads(content)
    if not isinstance(data, dict):
        raise ValueError("JSON object required")
    return data


def validate_tune(data):
    if set(data) - {"congestion", "qdisc", "egress_mbps", "shaping_confirmed", "disable_shaping"}:
        raise ValueError("Unknown tuning option")
    if data.get("congestion", "keep") not in {"keep", "cubic", "bbr"} or data.get("qdisc", "keep") not in {
        "keep",
        "fq",
        "fq_codel",
    }:
        raise ValueError("Unsupported tuning setting")
    if data.get("disable_shaping") is True and (
        data.get("egress_mbps") is not None or data.get("shaping_confirmed") is not True
    ):
        raise ValueError("Disable shaping needs confirmation and no rate")
    rate = data.get("egress_mbps")
    if rate is not None and (
        type(rate) is not int or not 10 <= rate <= 100000 or data.get("shaping_confirmed") is not True
    ):
        raise ValueError("Shaping needs explicit confirmation and >=10 Mbit/s")
    return {
        "congestion": data.get("congestion", "keep"),
        "qdisc": data.get("qdisc", "keep"),
        "egress_mbps": rate,
        "shaping_confirmed": rate is not None or data.get("disable_shaping") is True,
        "disable_shaping": data.get("disable_shaping") is True,
    }


def tune_interface():
    for args in (
        ["/usr/sbin/ip", "-j", "route", "get", "1.1.1.1"],
        ["/usr/sbin/ip", "-j", "-6", "route", "get", "2606:4700:4700::1111"],
    ):
        try:
            route = json.loads(run(args))
            name = route[0]["dev"]
            if re.fullmatch(r"[A-Za-z0-9_.:-]{1,15}", name) and name != "lo":
                return name
        except (ValueError, KeyError, IndexError, RuntimeError):
            continue
    raise RuntimeError("Default egress interface unavailable")


def tc_state(iface):
    data = json.loads(run(["/usr/sbin/tc", "-j", "qdisc", "show", "dev", iface]))
    root = next((q for q in data if q.get("root")), {})
    return root.get("kind", "noqueue")


def tc_apply(iface, params):
    rate = params.get("egress_mbps")
    qdisc = params.get("qdisc", "keep")
    if params.get("disable_shaping"):
        run(["/usr/sbin/tc", "qdisc", "del", "dev", iface, "root"], allow_nonzero=True)
        if qdisc != "keep":
            run(["/usr/sbin/tc", "qdisc", "replace", "dev", iface, "root", qdisc])
    elif rate is not None:
        # Limit the WHOLE egress interface. No hidden per-user/ingress shaping claims.
        run(
            [
                "/usr/sbin/tc",
                "qdisc",
                "replace",
                "dev",
                iface,
                "root",
                "handle",
                "1:",
                "tbf",
                "rate",
                str(rate) + "mbit",
                "burst",
                "256kb",
                "latency",
                "50ms",
            ]
        )
    elif qdisc != "keep":
        run(["/usr/sbin/tc", "qdisc", "replace", "dev", iface, "root", qdisc])


def tune():
    data = validate_tune(read_payload())
    if not json.loads(META.read_text()).get("installed"):
        raise RuntimeError("Node not installed")
    if data["congestion"] == "keep" and data["qdisc"] == "keep" and data["egress_mbps"] is None:
        return {"unchanged": True, "settings": data}
    if data["congestion"] not in {
        "keep",
        *Path("/proc/sys/net/ipv4/tcp_available_congestion_control").read_text().split(),
    }:
        raise RuntimeError(
            "Requested TCP congestion algorithm is not available in this kernel; no changes made"
        )
    if not Path("/usr/bin/systemd-run").exists():
        raise RuntimeError("systemd rollback timer is required")
    TUNE_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    pending = TUNE_DIR / "pending.json"
    if pending.exists():
        raise RuntimeError("Previous tuning transaction still pending")
    iface = tune_interface()
    kind = tc_state(iface)
    previous = (
        json.loads((TUNE_DIR / "current.json").read_text()) if (TUNE_DIR / "current.json").exists() else None
    )
    if data.get("disable_shaping") and not (previous and previous.get("iface") == iface and kind == "tbf"):
        raise RuntimeError("Only GhostFleet's owned TBF shaping can be removed")
    if kind not in {"noqueue", "mq", "pfifo_fast", "fq", "fq_codel"} and not (
        previous and previous.get("iface") == iface and kind == "tbf"
    ):
        raise RuntimeError("Foreign/custom root qdisc detected; refused to overwrite")
    import secrets

    nonce = secrets.token_hex(16)
    snapshot = {
        "nonce": nonce,
        "created": time.time(),
        "iface": iface,
        "kind": kind,
        "previous": previous,
        "sysctls": {k: path.read_text().strip() for k, (_, path) in SYSCTLS.items()},
        "new": data,
    }
    prior = previous.get("settings", {}) if previous else {}
    effective = {
        "congestion": snapshot["sysctls"]["congestion"]
        if data["congestion"] == "keep"
        else data["congestion"],
        "qdisc": snapshot["sysctls"]["qdisc"] if data["qdisc"] == "keep" else data["qdisc"],
        "egress_mbps": None
        if data.get("disable_shaping")
        else (data["egress_mbps"] if data["egress_mbps"] is not None else prior.get("egress_mbps")),
        "disable_shaping": False,
    }
    effective["shaping_confirmed"] = effective["egress_mbps"] is not None
    snapshot["effective"] = effective
    pending.write_text(json.dumps(snapshot))
    os.chmod(pending, 0o600)
    # The root timer is created BEFORE changes. Loss of SSH cannot cancel automatic rollback.
    try:
        run(
            [
                "/usr/bin/systemd-run",
                "--quiet",
                "--collect",
                "--unit=ghostfleet-tune-rollback",
                "--on-active=90s",
                "/usr/bin/python3",
                "/usr/local/lib/ghostfleet-node/agent.py",
                "--rollback-tune",
            ]
        )
    except Exception:
        pending.unlink()
        raise
    try:
        for name, (sysctl, _path) in SYSCTLS.items():
            if data[name] != "keep":
                run(["/usr/sbin/sysctl", "-w", sysctl + "=" + data[name]])
        tc_apply(iface, data)
    except Exception:
        rollback_tune()
        raise
    return {
        "pending": nonce,
        "rollback_seconds": 90,
        "iface": iface,
        "settings": data,
        "confirm_required": True,
    }


def tune_confirm():
    data = read_payload()
    if set(data) != {"nonce"} or not re.fullmatch(r"[a-f0-9]{32}", str(data["nonce"])):
        raise ValueError("Invalid confirmation")
    path = TUNE_DIR / "pending.json"
    pending = json.loads(path.read_text())
    import hmac

    if not hmac.compare_digest(pending["nonce"], data["nonce"]) or time.time() - pending["created"] > 70:
        raise ValueError("Confirmation expired")
    (TUNE_DIR / "current.json").write_text(
        json.dumps({"iface": pending["iface"], "settings": pending.get("effective", pending["new"])})
    )
    os.chmod(TUNE_DIR / "current.json", 0o600)
    path.unlink()
    run(["/usr/bin/systemctl", "stop", "ghostfleet-tune-rollback.timer"], allow_nonzero=True)
    run(["/usr/bin/systemctl", "reset-failed", "ghostfleet-tune-rollback.service"], allow_nonzero=True)
    return {"confirmed": True, "settings": pending.get("effective", pending["new"])}


def rollback_tune():
    path = TUNE_DIR / "pending.json"
    if not path.exists():
        return {"rolled_back": False}
    pending = json.loads(path.read_text())
    iface = pending["iface"]
    if not re.fullmatch(r"[A-Za-z0-9_.:-]{1,15}", iface):
        raise ValueError("Invalid interface snapshot")
    for name, (sysctl, _) in SYSCTLS.items():
        value = pending["sysctls"][name]
        if not re.fullmatch(r"[a-z0-9_]{1,32}", value):
            raise ValueError("Invalid sysctl snapshot")
        run(["/usr/sbin/sysctl", "-w", sysctl + "=" + value])
    if pending.get("previous"):
        old = validate_tune(pending["previous"]["settings"])
        tc_apply(iface, old)
    else:
        run(["/usr/sbin/tc", "qdisc", "del", "dev", iface, "root"], allow_nonzero=True)
        if pending["kind"] in {"fq", "fq_codel", "pfifo_fast"}:
            run(
                ["/usr/sbin/tc", "qdisc", "replace", "dev", iface, "root", pending["kind"]],
                allow_nonzero=True,
            )
    path.unlink()
    return {"rolled_back": True}


def main() -> int:
    if os.geteuid() != 0:
        return 1
    if sys.argv[1:] == ["--rollback-tune"]:
        try:
            rollback_tune()
            return 0
        except Exception:
            return 1
    command = os.getenv("SSH_ORIGINAL_COMMAND", "")
    handlers = {
        "health": health,
        "metrics": metrics,
        "certificates": certificates,
        "logs": logs,
        "update": update,
        "tune": tune,
        "tune-confirm": tune_confirm,
    }
    if command not in handlers:
        print('{"error":"Command not allowed"}')
        return 1
    try:
        result = handlers[command]()
        print(json.dumps(result))
        return 0
    except Exception:
        # Never serialize exceptions containing command output or private keys.
        print('{"error":"Operation failed; inspect the node locally"}')
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
