from __future__ import annotations

import json
import math
import time
import uuid


def seed_demo(db, box) -> None:
    if db.get("demo_seeded"):
        # Keep a demo fresh across a process restart, but never run a network poll.
        db.set(
            "monitor",
            {
                "online": True,
                "last_success": time.time(),
                "checked": time.time(),
                "latency_ms": 142,
                "error": None,
            },
        )
        db.execute("UPDATE nodes SET updated=?", (time.time(),))
        for n in db.query("SELECT id,rw_data FROM nodes"):
            d = json.loads(n["rw_data"])
            d["seen_at"] = time.time()
            db.execute("UPDATE nodes SET rw_data=? WHERE id=?", (json.dumps(d), n["id"]))
        return
    now = time.time()
    country_nodes = [
        ("DE", 1),
        ("DE", 2),
        ("FI", 1),
        ("FR", 1),
        ("GB", 1),
        ("NL", 1),
        ("NL", 2),
        ("PL", 1),
        ("PL", 2),
        ("SE", 1),
        ("TR", 1),
        ("US", 1),
        ("US", 2),
        ("JP", 1),
    ]
    for i, (cc, ordinal) in enumerate(country_nodes):
        node_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, f"ghostfleet.demo.{cc}.{ordinal}"))
        status = (
            "offline"
            if (cc, ordinal) == ("PL", 2)
            else "disabled"
            if (cc, ordinal) == ("US", 2)
            else "online"
        )
        users = [186, 112, 87, 96, 65, 204, 133, 142, 0, 74, 51, 117, 0, 68][i]
        data = {
            "connected": status == "online",
            "disabled": status == "disabled",
            "connecting": False,
            "users_online": users,
            "traffic_used": (42 + 17 * i) * 1024**3,
            "memory_total": 4 * 1024**3,
            "memory_used": (0.25 + 0.035 * i) * 4 * 1024**3,
            "load1": 0.15 + i * 0.04,
            "cpus": 2,
            "network_rx": (i + 2) * 250000 if users else 0,
            "network_tx": (i + 1) * 900000 if users else 0,
            "uptime": 12 * 86400 + i * 4000,
            "node_version": "3.4.1",
            "xray_version": "demo",
            "seen_at": now,
        }
        host = {
            "cpu_pct": 7 + i * 3.1,
            "disk_total": 50 * 1024**3,
            "disk_used": (5 + i) * 1024**3,
            "seen_at": now,
        }
        slug = f"{cc.lower()}-{ordinal:02d}"
        db.execute(
            "INSERT INTO nodes(id,remnawave_uuid,slug,name,country,ordinal,address,domain,managed,state,rw_data,host_metrics,cert_expiry,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                node_id,
                node_id,
                slug,
                slug.upper(),
                cc,
                ordinal,
                f"203.0.113.{10 + i}",
                slug + ".nodes.example.com",
                1,
                "active",
                json.dumps(data),
                json.dumps(host),
                now + (21 + i) * 86400,
                now - 14 * 86400,
                now,
            ),
        )
        for t in range(96):
            stamp = now - (95 - t) * 900
            curve = 0.7 + 0.3 * math.sin(t / 10 - 1.5) + 0.08 * math.cos(t / 3 + i)
            count = round(users * max(0.25, curve))
            available = 0 if status == "offline" and t > 88 else 1
            db.execute(
                "INSERT INTO samples(node_id,ts,connected,users,rx,tx,memory_pct,load,latency) VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    node_id,
                    stamp,
                    available,
                    count,
                    data["network_rx"] * curve,
                    data["network_tx"] * curve,
                    30 + i * 2,
                    data["load1"],
                    142,
                ),
            )
    db.set(
        "integration",
        {
            "remnawave_url": "https://remnawave.example.com/api",
            "remnawave_ips": "198.51.100.10/32",
            "manager_ips": "198.51.100.11/32",
            "email": "admin@example.com",
            "base_domain": "nodes.example.com",
            "node_port": 2222,
            "geoip_enabled": False,
            "create_hosts": True,
            "squad_uuids": ["d20dc1cc-7ef3-41b7-8183-4551cde25615"],
            "telegram_chat_id": "",
            "node_image": "remnawave/node:3.4.1",
        },
    )
    db.set("api_token", box.encrypt("DEMO-NOT-A-REAL-TOKEN", "setting:api_token"))
    db.set("api_checked", {"ts": now, "version": "3.4.4"})
    db.set("monitor", {"online": True, "last_success": now, "checked": now, "latency_ms": 142, "error": None})
    for event, detail in [
        ("auth.login", "Демо: приватный доступ через SSH-туннель"),
        ("certificate.synced", "Демо: DE-01 · TLS-сертификат синхронизирован"),
        ("node.deployed", "Демо: NL-02 · нода зарегистрирована"),
        ("alert.opened", "Демо: PL-02 · Remnawave сообщил offline"),
        ("api.checked", "Демо: Remnawave 3.4.4 · соединение проверено"),
    ]:
        db.audit(event, detail, "demo", "127.0.0.1")
    from .template import DEFAULT_TEMPLATE

    safe_template = json.loads(DEFAULT_TEMPLATE.read_text())
    bridge = safe_template["outbounds"][1]
    bridge["settings"]["id"] = "00000000-0000-4000-8000-000000000000"
    bridge["settings"]["address"] = "bridge.example.com"
    bridge["streamSettings"]["realitySettings"].update(
        {
            "shortId": "0000000000000000",
            "password": "DEMO_PUBLIC_KEY_NOT_FOR_DEPLOYMENT".lower(),  # a dummy public key, not a secret
            "serverName": "bridge.example.com",
        }
    )
    db.set("template", box.encrypt(json.dumps(safe_template), "setting:template"))
    all_nodes = db.query("SELECT id,name FROM nodes ORDER BY slug")
    for index, (kind, state, message) in enumerate(
        [
            ("sync-cert", "completed", "Демо: TLS-сертификат проверен и синхронизирован"),
            ("deploy", "completed", "Демо: нода установлена и зарегистрирована"),
            ("update", "failed", "Демо: контейнер не обновлён, прежний образ сохранён"),
        ]
    ):
        job_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, "ghostfleet.demo.job." + str(index)))
        logs = [
            {"ts": now - 1200 + index * 60, "step": 5, "message": "Демо: проверка соединения"},
            {"ts": now - 900 + index * 60, "step": 100 if state == "completed" else 40, "message": message},
        ]
        db.execute(
            "INSERT INTO jobs(id,node_id,kind,state,step,message,logs,created,updated) VALUES(?,?,?,?,?,?,?,?,?)",
            (
                job_id,
                all_nodes[index]["id"],
                kind,
                state,
                100 if state == "completed" else 40,
                message,
                json.dumps(logs),
                now - 1200 + index * 60,
                now - 900 + index * 60,
            ),
        )
    db.set("demo_seeded", True)


def demo_users():
    from datetime import datetime, timedelta, timezone

    names = [
        "alex.mobile",
        "maria.home",
        "dmitry.work",
        "olga.travel",
        "nikita.dev",
        "ivan.family",
        "alex.mobile2",
        "anna.office",
        "max.tablet",
        "guest.team",
        "pavel.laptop",
        "test.client",
    ]
    statuses = [
        "ACTIVE",
        "ACTIVE",
        "ACTIVE",
        "DISABLED",
        "ACTIVE",
        "EXPIRED",
        "ACTIVE",
        "ACTIVE",
        "LIMITED",
        "ACTIVE",
        "ACTIVE",
        "ACTIVE",
    ]
    now = datetime.now(timezone.utc)
    return [
        {
            "identity": str(1001 + i),
            "username": name,
            "status": statuses[i],
            "traffic_used": int((8.4 + i * 3.18) * 1024**3),
            "traffic_limit": 100 * 1024**3,
            "expires": (now + timedelta(days=(i + 2) * 3)).isoformat(),
            "online_at": (now - timedelta(minutes=i * 4)).isoformat(),
            "hwid_limit": 3,
            "tag": "DEMO",
            "seen_at": now.timestamp(),
            "observation": {
                "count": 7 if i == 6 else 9 if i == 9 else (i % 3) + 1,
                "flagged": i in {6, 9},
                "last_seen": now.timestamp() - 80,
            },
        }
        for i, name in enumerate(names)
    ]
