> Дополнение 1.1.1: 144 pytest passed; 8 новых проверок scoped profile names, HTTP409, UUID checkpoint, reclaim exact matching profile, refusal foreign/unproven profiles.

# QA 1.1.0 — 2026-10-06

## Реально выполнено в sandbox

- **136 pytest passed**, отдельно на CPython 3.10.22 и 3.13.14.
- Legacy 101 regression tests + миграция schema1→2, сохранение old encrypted template/TOTP/recovery/id1 и отзыв legacy sessions.
- Реальный server-side RBAC, уменьшение custom rights, last-owner guard, inactive/per-user CIDR access, отдельный AAD/MFA второго администратора, fresh-MFA gates.
- Service token SHA256, no token readback, allowed IP/scopes/expiry/revocation, запрет auth/staff/bootstrap/secret grants; invalid Bearer не cookie fallback.
- Dynamic allowlist app guard + internal gate token/peer validation. Нет автоматической проверки реального nginx gateway на вашем VPS.
- Cloudflare mock contracts: no redirects/body echo, write-only token, zone binding, DNS-only, no silent foreign replacement.
- Safe user data excludes actual subscription credentials. HWID observation подтверждается последовательными samples, deduplicates alerts, **не банит**; outage не создаёт нарушения.
- Config version encryption и activation только будущего шаблона. Tune input validation повторяется на root agent; old-agent capability refusal; job требует health→nonce ACK, не подтверждает при SSH loss.
- Production-mode local browser smoke: password→TOTP QR→recovery→dashboard→navigation race→logout, без page errors.
- Chromium demo: все 15 разделов, 1600/768/390 widths, нет горизонтального page overflow/JS/CSP ошибок; таблицы отдельно scrollable.
- Ruff/lint/format app/node/tests/scripts, Python compile, JS syntax обоих scripts, Bash syntax, ShellCheck clean.
- Bandit app/node: **0 findings**; runtime hashed lock pip-audit: **No known vulnerabilities found** на момент проверки.

JSON scans: `docs/qa/bandit.json`, `docs/qa/runtime-dependencies.json`. Screenshots — синтетическая read-only demo, не инфраструктура владельца. No third-party secrets inside archive.

## Не выполнено — обязательный пилот

Ваш боевой 1.0→1.1 update, actual systemd/nginx/ACME/provider firewall, настоящий Remnawave token/точная 3.4 minor, Cloudflare реальные зоны, реальные node sysctls/tc/watchdog/UDP traffic, доставка Telegram и дисастер recovery на второй машине.

Отдельно проверить на disposable node: kernel support, default NIC, custom qdisc refusal, TBF load/cap, восстановление snapshot при намеренном SSH/ACK failure, отмену watchdog после успешного ACK, VLESS/HY2 client и bridge route. Current safety mechanism не заменяет e2e traffic test.

GitHub CI настроена, но run в вашем repo ещё не происходил. Нет независимого penetration test/fuzzing/длительного нагрузочного теста. Нулевой dependency scanner ≠ гарантированная безопасность.

## Команды

```bash
python -m pytest -q
ruff check app node tests scripts
ruff format --check app node tests scripts
bandit -r app node -c pyproject.toml
pip-audit --disable-pip --no-deps -r requirements.txt
python -m compileall -q app node
node --check app/static/app.js
node --check app/static/extensions.js
bash -n deploy/*.sh node/bootstrap.sh
shellcheck deploy/*.sh node/bootstrap.sh
# optional Playwright install, then
python scripts/browser_smoke.py
```

`docs/TESTING.md` описывает прошлый release 1.0, этот файл — актуальное дополнение. Before first schema update use the NEW installer, see UPGRADE-1.1.md.
