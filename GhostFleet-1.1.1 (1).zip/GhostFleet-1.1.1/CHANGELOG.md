# Изменения

## 1.1.1 — 2026-10-06

Hotfix Config Profiles HTTP409: scoped deterministic names (27 chars, instance+node UUID hash), create UUID persisted before optional details request, conservative exact-config/ownership lost-response recovery; HTTP409 diagnostics distinguish conflict from wrong token. Legacy profiles remain untouched. 144 tests. Quick update: docs/QUICK-UPDATE-1.1.1.md.

## 1.1.0 — 2026-10-06

Dark UI; schema2 multi-admin/RBAC, personal CIDR and fresh-MFA gates; short-lived scoped/IP-bound service tokens; Cloudflare A/AAAA DNS-only; dynamic nginx/app IP gateway without web-root; safe Remnawave users/HWID observation (no automatic bans); notification rules/test; install profiles; curated TCP/qdisc/TBF tuning with watchdog/ACK; encrypted config versions; new schema-aware rollback and diagnostics.

**Первое обновление 1.0→1.1: свежий installer, не старый update.sh.** Ноды не rebootstrap, old owner credentials/crypto preserved. Live infrastructure pilot still required.

## 1.0.0 — 2026-10-04

Первая версия GhostFleet: Remnawave v3 contract integration, Ghostly adapter, приватная установка systemd, русскоязычная UI, обязательная TOTP, temporary encrypted SSH credentials, pinned SSH trust, restricted node agent, индивидуальные Config Profiles/TLS/Hosts/Internal Squads, monitoring/jobs/audit, age backup/restore и CI.

Release не прошёл live E2E на инфраструктуре владельца. Перед массовым deployment нужен пилот на новом VPS и review security/операционных ограничений.
